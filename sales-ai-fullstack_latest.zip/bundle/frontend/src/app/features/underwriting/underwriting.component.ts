import {
  ChangeDetectionStrategy,
  Component,
  computed,
  inject,
  signal,
} from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { firstValueFrom } from 'rxjs';

import {
  ApiService,
  FinancialCheck,
  FinancialOptions,
  PlanName,
  UnderwritingChecksBundle,
} from '../../core/services/api.service';

@Component({
  selector: 'app-underwriting',
  standalone: true,
  imports: [CommonModule, FormsModule],
  changeDetection: ChangeDetectionStrategy.OnPush,
  templateUrl: './underwriting.component.html',
})
export class UnderwritingComponent {
  private readonly api = inject(ApiService);

  // ===== Shared state for Medical / Non-Medical sections (existing) =====
  protected readonly bundle = signal<UnderwritingChecksBundle | null>(null);
  protected readonly bundleLoading = signal<boolean>(true);
  protected readonly bundleError = signal<string | null>(null);

  protected readonly activeSection = signal<
    'financial' | 'medicalNonDisclosure' | 'medicalDisclosure' | 'nonMedical'
  >('financial');

  protected readonly sectionMeta = [
    { id: 'financial',            label: 'Financial',              short: 'Financial' },
    { id: 'medicalNonDisclosure', label: 'Medical · Non-Disclosure', short: 'Non-Disc.' },
    { id: 'medicalDisclosure',    label: 'Medical · Disclosure',   short: 'Disclosure' },
    { id: 'nonMedical',           label: 'Non-Medical',            short: 'Non-Med.' },
  ] as const;

  // ===== ★★★ NEW — Financial form workflow state ★★★ =====
  protected readonly options = signal<FinancialOptions | null>(null);

  /** Step 1 selections */
  protected readonly selectedPlan = signal<PlanName | ''>('');
  protected readonly selectedOccupation = signal<string>('');

  /** Step 2 selection */
  protected readonly selectedSuc = signal<string>('');

  /** Rows returned by GET /financial?plan=&occupation= */
  protected readonly financialRows = signal<FinancialCheck[]>([]);
  protected readonly financialLoading = signal<boolean>(false);
  protected readonly financialError = signal<string | null>(null);

  /** Unique SUC values across the rows — populates the SUC dropdown. */
  protected readonly availableSucs = computed<string[]>(() => {
    const seen = new Set<string>();
    const ordered: string[] = [];
    for (const r of this.financialRows()) {
      if (!seen.has(r.financialSuc)) {
        seen.add(r.financialSuc);
        ordered.push(r.financialSuc);
      }
    }
    return ordered;
  });

  /** Are both step-1 inputs complete? */
  protected readonly step1Complete = computed<boolean>(
    () => this.selectedPlan() !== '' && this.selectedOccupation() !== ''
  );

  /** Has the user picked a SUC band (step 2)? */
  protected readonly step2Complete = computed<boolean>(() => this.selectedSuc() !== '');

  /** Rows visible in the final table — filtered by the chosen SUC. */
  protected readonly visibleRows = computed<FinancialCheck[]>(() => {
    if (!this.step2Complete()) return [];
    const suc = this.selectedSuc();
    return this.financialRows().filter((r) => r.financialSuc === suc);
  });

  constructor() {
    void this.loadBundle();
    void this.loadOptions();
  }

  // -------- Step 1: select plan & occupation --------
  protected onPlanChange(value: string): void {
    this.selectedPlan.set(value as PlanName);
    this.resetDownstream();
    void this.fetchFinancialRowsIfReady();
  }

  protected onOccupationChange(value: string): void {
    this.selectedOccupation.set(value);
    this.resetDownstream();
    void this.fetchFinancialRowsIfReady();
  }

  // -------- Step 2: SUC selection --------
  protected onSucChange(value: string): void {
    this.selectedSuc.set(value);
  }

  // -------- Reset / back navigation --------
  protected resetWorkflow(): void {
    this.selectedPlan.set('');
    this.selectedOccupation.set('');
    this.resetDownstream();
  }

  private resetDownstream(): void {
    this.selectedSuc.set('');
    this.financialRows.set([]);
    this.financialError.set(null);
  }

  // -------- Data fetches --------
  private async loadOptions(): Promise<void> {
    try {
      const opts = await firstValueFrom(this.api.financialOptions());
      this.options.set(opts);
    } catch (err) {
      this.financialError.set(
        err instanceof Error ? err.message : 'Failed to load options'
      );
    }
  }

  private async fetchFinancialRowsIfReady(): Promise<void> {
    if (!this.step1Complete()) return;
    this.financialLoading.set(true);
    this.financialError.set(null);
    try {
      const rows = await firstValueFrom(
        this.api.listFinancial({
          plan: this.selectedPlan() as PlanName,
          occupation: this.selectedOccupation(),
        })
      );
      this.financialRows.set(rows);
    } catch (err) {
      this.financialError.set(
        err instanceof Error ? err.message : 'Failed to load requirements'
      );
    } finally {
      this.financialLoading.set(false);
    }
  }

  private async loadBundle(): Promise<void> {
    this.bundleLoading.set(true);
    this.bundleError.set(null);
    try {
      const b = await firstValueFrom(this.api.underwritingChecks());
      this.bundle.set(b);
    } catch (err) {
      this.bundleError.set(
        err instanceof Error ? err.message : 'Failed to load underwriting checks'
      );
    } finally {
      this.bundleLoading.set(false);
    }
  }

  protected retryBundle(): void {
    void this.loadBundle();
  }
}
