"""Underwriting Checks — four reference tables surfaced by the UI."""

from enum import Enum
from .chat import Base


class PlanName(str, Enum):
    """Top-level life-insurance product categories used to filter UW rules."""
    term = "Term"
    ulip = "ULIP"
    endowment = "Endowment"
    pension = "Pension"
    whole_life = "Whole Life"
    money_back = "Money Back"
    child_plan = "Child Plan"


class FinancialCheck(Base):
    """One row of the Financial table."""
    id: str
    plan_name: PlanName       # NEW — drives the Underwriting form workflow
    financial_suc: str        # e.g. "Up to ₹50 L"
    occupation_life_type: str # e.g. "Salaried · Class I"
    financial_requirement: str
    documents_list: list[str]


class FinancialOptions(Base):
    """Dropdown payload for the Underwriting form workflow."""
    plans: list[str]
    occupations: list[str]


class MedicalCheck(Base):
    """
    Shared shape for both Medical tables (disclosure / non-disclosure).
    'disclosure_type' distinguishes the two without duplicating the model.
    """
    id: str
    age_limit: str             # e.g. "18-35", "36-45"
    medical_suc: str           # e.g. "Up to ₹25 L"
    medical_requirements: list[str]   # e.g. ["MER", "ECG", "FBS", "HbA1c"]


class NonMedicalCheck(Base):
    id: str
    age_limit: str
    vmer_requirements: list[str]      # e.g. ["Yes", "Tele-MER follow-up"]


class UnderwritingChecksBundle(Base):
    """Single payload — frontend renders all four tables in one screen."""
    financial: list[FinancialCheck]
    medical_non_disclosure: list[MedicalCheck]
    medical_disclosure: list[MedicalCheck]
    non_medical: list[NonMedicalCheck]
