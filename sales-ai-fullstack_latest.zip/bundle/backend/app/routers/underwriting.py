"""Underwriting Checks endpoints."""

from fastapi import APIRouter, Depends, Query

from app.models import (
    FinancialCheck,
    FinancialOptions,
    PlanName,
    UnderwritingChecksBundle,
)
from app.services.store import Store, get_store

router = APIRouter(prefix="/api/underwriting", tags=["underwriting"])


@router.get("/checks", response_model=UnderwritingChecksBundle)
async def get_checks(
    store: Store = Depends(get_store),
) -> UnderwritingChecksBundle:
    """
    Full payload — all four reference tables. Used by the Medical & Non-Medical
    sections of the Underwriting screen. Financial rows are also included
    here for backward compatibility.
    """
    return await store.underwriting_checks()


# ★★★ NEW endpoints powering the Underwriting form workflow ★★★

@router.get("/financial-options", response_model=FinancialOptions)
async def financial_options(
    store: Store = Depends(get_store),
) -> FinancialOptions:
    """
    Returns the unique Plan names and Occupation / Life-Type values currently
    in the dataset — used to populate the first two dropdowns in the form.
    """
    return await store.financial_options()


@router.get("/financial", response_model=list[FinancialCheck])
async def list_financial(
    plan: PlanName | None = Query(None, description="Filter by plan name"),
    occupation: str | None = Query(None, description="Filter by occupation / life-type"),
    suc: str | None = Query(None, description="Filter by Financial SUC band"),
    store: Store = Depends(get_store),
) -> list[FinancialCheck]:
    """
    Filtered Financial-UW rows.

    Workflow expectation:
      • Step 1: user picks plan + occupation; client calls this endpoint with
        both → unique SUC values from the result populate the SUC dropdown.
      • Step 2: user picks a SUC; client filters its loaded list locally
        OR re-calls with all three filters to fetch just that row.
    """
    return await store.list_financial(plan=plan, occupation=occupation, suc=suc)
