import { Injectable, signal, computed } from '@angular/core';
import { Router, NavigationEnd } from '@angular/router';
import { filter } from 'rxjs';

export interface NavItem {
  id: string;
  label: string;
  description: string;
  route: string;
  icon: string;        // svg path (24x24 viewBox)
  badge?: string;
}

@Injectable({ providedIn: 'root' })
export class NavService {
  /** Sidebar drawer state */
  readonly isOpen = signal(false);

  /** Active route title (used by topbar) */
  readonly activeTitle = signal<string>('Product Recommendation & Comparison');

  readonly items: NavItem[] = [
    {
      id: 'assistant',
      label: 'Product Recommendation & Comparison',
      description: 'AI-powered guidance and side-by-side product analysis',
      route: '/assistant',
      icon:
        'M9 11.5a2.5 2.5 0 1 1 5 0 2.5 2.5 0 0 1-5 0Zm-6 7.75A7.25 7.25 0 0 1 10.25 12h3.5A7.25 7.25 0 0 1 21 19.25V21H3v-1.75ZM12 2 4 5v6c0 5 3.4 9.1 8 10 4.6-.9 8-5 8-10V5l-8-3Z',
      badge: 'AI',
    },
    {
      id: 'inventory',
      label: 'Sales Inventory',
      description: 'Manage active products & quote pipeline',
      route: '/inventory',
      icon:
        'M3 7l9-4 9 4-9 4-9-4Zm0 5 9 4 9-4M3 17l9 4 9-4',
    },
    {
      id: 'incentives',
      label: 'Incentives',
      description: 'Track commissions, bonuses & contests',
      route: '/incentives',
      icon:
        'M12 2v3m0 14v3M4.22 4.22l2.12 2.12m11.32 11.32 2.12 2.12M2 12h3m14 0h3M4.22 19.78l2.12-2.12M17.66 6.34l2.12-2.12M12 7a5 5 0 1 1 0 10 5 5 0 0 1 0-10Z',
    },
    {
      id: 'leads',
      label: 'Leads',
      description: 'Prospects, follow-ups & conversions',
      route: '/leads',
      icon:
        'M16 11a4 4 0 1 0-8 0 4 4 0 0 0 8 0Zm-12 9a8 8 0 0 1 16 0M17 3l2 2 4-4',
    },
  ];

  readonly activeItem = computed<NavItem | undefined>(() =>
    this.items.find((i) => i.route === this.currentRoute())
  );

  private currentRoute = signal<string>('/assistant');

  constructor(private router: Router) {
    this.router.events
      .pipe(filter((e): e is NavigationEnd => e instanceof NavigationEnd))
      .subscribe((e) => {
        this.currentRoute.set(e.urlAfterRedirects);
        const item = this.items.find((i) => i.route === e.urlAfterRedirects);
        if (item) this.activeTitle.set(item.label);
      });
  }

  open()   { this.isOpen.set(true);  }
  close()  { this.isOpen.set(false); }
  toggle() { this.isOpen.update((v) => !v); }

  navigate(item: NavItem) {
    this.router.navigateByUrl(item.route);
    this.close();
  }
}
