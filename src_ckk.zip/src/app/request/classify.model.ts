import { HttpClient, HttpErrorResponse, HttpHeaders } from '@angular/common/http';
import { Injectable, inject } from '@angular/core';
import { Observable, throwError } from 'rxjs';
import { catchError } from 'rxjs/operators';

/**
 * TypeScript types matching the backend JSON contract.
 *
 * POST http://127.0.0.1:8000/v1/classify
 *
 * Request body:  { "query": "string" }
 * Response body: { "category": "recommendation", "query": "string" }
 */

export type QueryCategory =
  | 'recommendation'
  | 'comparison'
  | 'information'
  | 'underwriting_document_ask'
  | 'incentive_ask'
  | 'unknown';

export interface ClassifyRequest {
  query: string;
}

export interface ClassifyResponse {
  category: QueryCategory;
  query: string;
}

@Injectable({ providedIn: 'root' })
export class ClassifierRequestor {
  private readonly http = inject(HttpClient);

  // Change to 'vi/classify' if that's really your path (not 'v1/classify').
  private readonly apiUrl = 'http://127.0.0.1:8000/v1/classify';

  /**
   * POST { query } → { category, query }
   */
  classify(query: string): Observable<ClassifyResponse> {
    // const body: ClassifyRequest = { query };
    const body = { "query": query }; 
    const headers = new HttpHeaders({
      'Content-Type': 'application/json',
      Accept: 'application/json',
    });

    return this.http
      .post<ClassifyResponse>(this.apiUrl, body, { headers })
      .pipe(catchError(this.handleError));
  }

  private handleError(err: HttpErrorResponse) {
    let message: string;
    if (err.status === 0) {
      // Network failure, CORS blocked, or backend down
      message = 'Cannot reach the API. Check that the backend is running and CORS is enabled.';
    } else if (err.error?.detail) {
      message = err.error.detail;
    } else {
      message = `HTTP ${err.status} ${err.statusText}`;
    }
    return throwError(() => new Error(message));
  }
}

