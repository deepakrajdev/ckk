import {
  ChangeDetectionStrategy,
  Component,
  ElementRef,
  ViewChild,
  AfterViewChecked,
  signal,
} from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import {
  ChatMessage,
  InsuranceProduct,
  QuickAction,
  UnderwritingDoc,
} from '../../core/models/chat.model';

import {
  ClassifyRequest,
  ClassifyResponse,
  ClassifierRequestor
} from '../../request/classify.model';


@Component({
  selector: 'app-chat',
  standalone: true,
  imports: [CommonModule, FormsModule],
  changeDetection: ChangeDetectionStrategy.OnPush,
  templateUrl: './chat.component.html',
})
export class ChatComponent implements AfterViewChecked {
  @ViewChild('scrollArea') private scrollArea!: ElementRef<HTMLDivElement>;

  protected draft = '';
  protected readonly isTyping = signal(false);
  protected readonly messages = signal<ChatMessage[]>(this.seed());

  protected readonly quickActions: QuickAction[] = [
    { id: 'q1', label: 'Compare term plans', icon: '📊', prompt: 'Compare top term insurance plans for a 35-year-old non-smoker with ₹1 Cr cover for 30 years.' },
    { id: 'q2', label: 'Best ULIP options',  icon: '📈', prompt: 'Show me the best ULIP options for long-term wealth creation.' },
    { id: 'q3', label: 'Underwriting checklist', icon: '📋', prompt: 'What documents are needed for underwriting a ₹2 Cr term plan?' },
    { id: 'q4', label: 'Rider explainer', icon: '🛡️', prompt: 'Explain critical illness and accidental death riders.' },
    { id: 'q5', label: 'Tax benefits 80C', icon: '💸', prompt: 'Summarise tax benefits under 80C and 10(10D) for life insurance.' },
    { id: 'q6', label: 'Pension plans',  icon: '🏦', prompt: 'Recommend pension plans for a 45-year-old.' },
  ];

  private autoScroll = true;

  // -------- Seed data ------------------------------------------------

  private seed(): ChatMessage[] {
    return [
      {
        id: 'm1',
        author: 'bot',
        timestamp: new Date(Date.now() - 60_000 * 3),
        content:
          "👋 Hi Rohan — I'm your sales co-pilot. Tell me about the prospect (age, income, dependents, goals) and I'll recommend the best fit, run comparisons, and pull the underwriting checklist.",
      },
      {
        id: 'm2',
        author: 'user',
        timestamp: new Date(Date.now() - 60_000 * 2),
        content:
          'Prospect: 35-year-old, non-smoker, salaried (₹18 LPA), 2 dependents. Wants ₹1 Cr cover for 30 years. Suggest term plans.',
      },
      {
        id: 'm3',
        author: 'bot',
        timestamp: new Date(Date.now() - 60_000),
        content:
          "Got it. Based on the profile, here are three strong term-plan matches — ranked by claim-settlement ratio, premium efficiency and rider flexibility:",
        attachment: { kind: 'product-cards', products: this.sampleProducts() },
      },
    ];
  }

  private sampleProducts(): InsuranceProduct[] {
    return [
      {
        id: 'p1', name: 'SecureLife Elite Term',
        carrier: 'HDFC Life', type: 'Term',
        coverage: '₹1 Cr', tenure: '30 yrs', premium: '₹12,400/yr',
        rating: 5, recommended: true,
        highlights: [
          '99.4% claim settlement ratio',
          'Free annual health check-up',
          'Critical illness rider available',
        ],
      },
      {
        id: 'p2', name: 'iProtect Smart',
        carrier: 'ICICI Pru', type: 'Term',
        coverage: '₹1 Cr', tenure: '30 yrs', premium: '₹13,100/yr',
        rating: 4,
        highlights: [
          'Return-of-premium option',
          'Terminal illness benefit',
          'Spouse cover add-on',
        ],
      },
    ];
  }

  private sampleUnderwriting(_productName: string): UnderwritingDoc[] {
    return [
      { id: 'd1', name: 'KYC — PAN + Aadhaar',  required: true,  description: 'Self-attested copies; e-KYC accepted via DigiLocker.' },
      { id: 'd2', name: 'Income proof',         required: true,  description: 'Latest 3 salary slips or Form 16 / ITR for last 2 years.' },
      { id: 'd3', name: 'Address proof',        required: true,  description: 'Utility bill, passport, or driving licence (≤ 3 months old).' },
      { id: 'd4', name: 'Medical examination',  required: true,  description: 'Full medicals at empanelled diagnostic centre — required for sum assured > ₹75 L.' },
      { id: 'd5', name: 'Financial questionnaire', required: false, description: 'Triggered if SA exceeds 25× annual income.' },
      { id: 'd6', name: 'NRI declaration',      required: false, description: 'Only if applicant is a non-resident Indian.' },
    ];
  }

  // -------- API interaction ---------------------------------------------
  private readonly classifier = new ClassifierRequestor();

  // -------- Interaction ---------------------------------------------

  send() {
    const text = this.draft.trim();
    if (!text) return;
    this.pushUser(text);
    this.draft = '';
    this.respond(text);
    this.classifier.classify(text).subscribe({
      next: (data: ClassifyResponse) => {
        // SUCCESS: Your response data is safely collected here!
        console.log('Backend response data:', data); 
      },
      error: (err) => {
        // FAILURE: Something went wrong with the API call
        console.error('Error fetching data:', err);
      }
    });
  }

  sendQuick(q: QuickAction) {
    this.pushUser(q.prompt);
    this.respond(q.prompt);
  }

  onEnter(e: Event) {
    const ev = e as KeyboardEvent;
    if (!ev.shiftKey) {
      ev.preventDefault();
      this.send();
    }
  }

  onAskUnderwriting(p: InsuranceProduct) {
    this.pushUser(`What underwriting documents are required for ${p.name}?`);
    this.isTyping.set(true);
    setTimeout(() => {
      this.isTyping.set(false);
      this.messages.update((all) => [
        ...all,
        {
          id: crypto.randomUUID(),
          author: 'bot',
          timestamp: new Date(),
          content:
            `Here's the underwriting checklist for ${p.name} (cover ${p.coverage}). Items in red are mandatory for issuance:`,
          attachment: {
            kind: 'underwriting',
            product: p.name,
            documents: this.sampleUnderwriting(p.name),
          },
        },
      ]);
    }, 900);
  }

  private pushUser(content: string) {
    this.messages.update((all) => [
      ...all,
      { id: crypto.randomUUID(), author: 'user', timestamp: new Date(), content },
    ]);
    this.autoScroll = true;
  }

  /** Demo response logic — replace with your real backend call */
  private respond(prompt: string) {
    this.isTyping.set(true);
    const p = prompt.toLowerCase();

    setTimeout(() => {
      this.isTyping.set(false);
      let msg: ChatMessage;

      if (p.includes('underwriting') || p.includes('document')) {
        msg = {
          id: crypto.randomUUID(), author: 'bot', timestamp: new Date(),
          content:
            'Here is the standard underwriting document checklist for a ₹2 Cr term plan. Mandatory items are highlighted:',
          attachment: { kind: 'underwriting', product: 'Term Plan · ₹2 Cr', documents: this.sampleUnderwriting('Term') },
        };
      } else if (p.includes('ulip')) {
        msg = {
          id: crypto.randomUUID(), author: 'bot', timestamp: new Date(),
          content:
            'For wealth creation with insurance cover, here are two ULIPs that consistently outperform their benchmark over 5 years:',
          attachment: {
            kind: 'product-cards',
            products: [
              { ...this.sampleProducts()[0], id: 'u1', name: 'Wealth Plus ULIP', carrier: 'Max Life', type: 'ULIP', premium: '₹50,000/yr', recommended: true,
                highlights: ['11.8% 5-yr CAGR (Balanced fund)', 'Loyalty additions from year 6', 'Unlimited fund switches'] },
              { ...this.sampleProducts()[1], id: 'u2', name: 'Smart Wealth Builder', carrier: 'TATA AIA', type: 'ULIP', premium: '₹50,000/yr',
                highlights: ['Top-ranked Multi-Cap fund', 'Wealth-boosters from year 10', 'Zero allocation charges'] },
            ],
          },
        };
      } else if (p.includes('compare') || p.includes('term') || p.includes('recommend')) {
        msg = {
          id: crypto.randomUUID(), author: 'bot', timestamp: new Date(),
          content: "Here are the strongest matches for that profile, ranked by suitability:",
          attachment: { kind: 'product-cards', products: this.sampleProducts() },
        };
      } else {
        msg = {
          id: crypto.randomUUID(), author: 'bot', timestamp: new Date(),
          content:
            "I can help with product comparison, premium illustrations, rider analysis, underwriting checklists and tax positioning. Share the prospect's age, income, dependents and goal — I'll take it from there.",
        };
      }
      this.messages.update((all) => [...all, msg]);
    }, 850);
  }

  // -------- Auto-scroll ---------------------------------------------

  ngAfterViewChecked(): void {
    if (this.autoScroll && this.scrollArea) {
      const el = this.scrollArea.nativeElement;
      el.scrollTop = el.scrollHeight;
      this.autoScroll = false;
    }
  }
}
