import { ChangeDetectionStrategy, Component, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

interface InventoryRow {
  id: string;
  name: string;
  carrier: string;
  type: 'Term' | 'ULIP' | 'Endowment' | 'Pension';
  status: 'Active' | 'Hot' | 'Paused';
  quotes: number;
  conversion: number; // %
}

@Component({
  selector: 'app-inventory',
  standalone: true,
  imports: [CommonModule, FormsModule],
  changeDetection: ChangeDetectionStrategy.OnPush,
  templateUrl: './inventory.component.html',
})
export class InventoryComponent {
  protected query = '';
  protected readonly filters = ['All', 'Term', 'ULIP', 'Endowment', 'Pension'] as const;
  protected readonly activeFilter = signal<(typeof this.filters)[number]>('All');

  protected readonly stats = [
    { label: 'Active products', value: '24', delta: '3 this week', deltaUp: true },
    { label: 'Quotes generated', value: '187', delta: '12.4%', deltaUp: true },
    { label: 'Conversion',       value: '28%', delta: '1.2%',  deltaUp: false },
    { label: 'Revenue (MTD)',    value: '₹4.6L', delta: '8.9%', deltaUp: true },
  ];

  private readonly rows: InventoryRow[] = [
    { id: 'i1', name: 'SecureLife Elite Term',    carrier: 'HDFC Life',    type: 'Term',     status: 'Hot',    quotes: 42, conversion: 34 },
    { id: 'i2', name: 'iProtect Smart',           carrier: 'ICICI Pru',    type: 'Term',     status: 'Active', quotes: 31, conversion: 29 },
    { id: 'i3', name: 'Wealth Plus ULIP',         carrier: 'Max Life',     type: 'ULIP',     status: 'Active', quotes: 18, conversion: 22 },
    { id: 'i4', name: 'Guaranteed Income Plus',   carrier: 'LIC',          type: 'Endowment',status: 'Active', quotes: 27, conversion: 18 },
    { id: 'i5', name: 'Smart Pension Pro',        carrier: 'SBI Life',     type: 'Pension',  status: 'Paused', quotes: 9,  conversion: 11 },
    { id: 'i6', name: 'Click 2 Protect Super',    carrier: 'HDFC Life',    type: 'Term',     status: 'Active', quotes: 22, conversion: 31 },
    { id: 'i7', name: 'Smart Wealth Builder',     carrier: 'TATA AIA',     type: 'ULIP',     status: 'Hot',    quotes: 16, conversion: 38 },
    { id: 'i8', name: 'Saral Jeevan Bima',        carrier: 'LIC',          type: 'Term',     status: 'Active', quotes: 22, conversion: 14 },
  ];

  protected readonly filtered = () => {
    const q = this.query.trim().toLowerCase();
    const f = this.activeFilter();
    return this.rows.filter(
      (r) =>
        (f === 'All' || r.type === f) &&
        (!q || r.name.toLowerCase().includes(q) || r.carrier.toLowerCase().includes(q))
    );
  };
}
