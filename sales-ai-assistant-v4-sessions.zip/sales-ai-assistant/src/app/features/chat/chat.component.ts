import {
  ChangeDetectionStrategy,
  Component,
  ElementRef,
  ViewChild,
  AfterViewChecked,
  HostListener,
  effect,
  inject,
  signal,
} from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import {
  ChatMessage,
  InsuranceProduct,
  QuickAction,
  UnderwritingDoc,
} from '../../core/models/chat.model';
import { ChatSessionsService } from '../../core/services/chat-sessions.service';
import { ChatSessionsComponent } from './chat-sessions/chat-sessions.component';

@Component({
  selector: 'app-chat',
  standalone: true,
  imports: [CommonModule, FormsModule, ChatSessionsComponent],
  changeDetection: ChangeDetectionStrategy.OnPush,
  templateUrl: './chat.component.html',
})
export class ChatComponent implements AfterViewChecked {
  @ViewChild('scrollArea') private scrollArea!: ElementRef<HTMLDivElement>;

  protected readonly sessionsSvc = inject(ChatSessionsService);

  protected draft = '';
  protected readonly isTyping = signal(false);

  /** Mobile sessions panel open/closed */
  protected readonly mobileSessionsOpen = signal(false);

  protected readonly quickActions: QuickAction[] = [
    { id: 'q1', label: 'Compare term plans',     icon: '📊', prompt: 'Compare top term insurance plans for a 35-year-old non-smoker with ₹1 Cr cover for 30 years.' },
    { id: 'q2', label: 'Best ULIP options',       icon: '📈', prompt: 'Show me the best ULIP options for long-term wealth creation.' },
    { id: 'q3', label: 'Underwriting checklist',  icon: '📋', prompt: 'What documents are needed for underwriting a ₹2 Cr term plan?' },
    { id: 'q4', label: 'Rider explainer',         icon: '🛡️', prompt: 'Explain critical illness and accidental death riders.' },
    { id: 'q5', label: 'Tax benefits 80C',        icon: '💸', prompt: 'Summarise tax benefits under 80C and 10(10D) for life insurance.' },
    { id: 'q6', label: 'Pension plans',           icon: '🏦', prompt: 'Recommend pension plans for a 45-year-old.' },
  ];

  private autoScroll = true;

  constructor() {
    // Whenever the active session changes, scroll the messages area to bottom
    effect(() => {
      this.sessionsSvc.activeId();
      this.autoScroll = true;
    });
  }

  // -------- Session interaction -------------------------------------

  protected onSelectSession(id: string): void {
    this.sessionsSvc.selectSession(id);
    this.mobileSessionsOpen.set(false);
  }

  protected onNewSession(): void {
    this.sessionsSvc.startNewSession();
    this.mobileSessionsOpen.set(false);
  }

  protected toggleMobileSessions(): void {
    this.mobileSessionsOpen.update((v) => !v);
  }

  @HostListener('document:keydown.escape')
  onEscape(): void {
    if (this.mobileSessionsOpen()) this.mobileSessionsOpen.set(false);
  }

  // -------- Chat interaction ----------------------------------------

  protected send(): void {
    const text = this.draft.trim();
    if (!text) return;
    this.pushUser(text);
    this.draft = '';
    this.respond(text);
  }

  protected sendQuick(q: QuickAction): void {
    this.pushUser(q.prompt);
    this.respond(q.prompt);
  }

  protected onEnter(e: Event): void {
    const ev = e as KeyboardEvent;
    if (!ev.shiftKey) {
      ev.preventDefault();
      this.send();
    }
  }

  protected onAskUnderwriting(p: InsuranceProduct): void {
    this.pushUser(`What underwriting documents are required for ${p.name}?`);
    this.isTyping.set(true);
    setTimeout(() => {
      this.isTyping.set(false);
      this.sessionsSvc.appendMessage({
        id: crypto.randomUUID(),
        author: 'bot',
        timestamp: new Date(),
        content:
          `Here's the underwriting checklist for ${p.name} (cover ${p.coverage}). Items in red are mandatory for issuance:`,
        attachment: {
          kind: 'underwriting',
          product: p.name,
          documents: this.sampleUnderwriting(),
        },
      });
    }, 900);
  }

  // -------- Helpers -------------------------------------------------

  private pushUser(content: string): void {
    this.sessionsSvc.appendMessage({
      id: crypto.randomUUID(),
      author: 'user',
      timestamp: new Date(),
      content,
    });
    this.autoScroll = true;
  }

  /** Demo response logic — replace with your real backend call */
  private respond(prompt: string): void {
    this.isTyping.set(true);
    const p = prompt.toLowerCase();

    setTimeout(() => {
      this.isTyping.set(false);
      let msg: ChatMessage;

      if (p.includes('underwriting') || p.includes('document')) {
        msg = {
          id: crypto.randomUUID(), author: 'bot', timestamp: new Date(),
          content:
            'Here is the standard underwriting document checklist for a ₹2 Cr term plan. Mandatory items are highlighted:',
          attachment: { kind: 'underwriting', product: 'Term Plan · ₹2 Cr', documents: this.sampleUnderwriting() },
        };
      } else if (p.includes('ulip')) {
        msg = {
          id: crypto.randomUUID(), author: 'bot', timestamp: new Date(),
          content:
            'For wealth creation with insurance cover, here are two ULIPs that consistently outperform their benchmark over 5 years:',
          attachment: {
            kind: 'product-cards',
            products: [
              { ...this.sampleProducts()[0]!, id: 'u1', name: 'Wealth Plus ULIP', carrier: 'Max Life', type: 'ULIP', premium: '₹50,000/yr', recommended: true,
                highlights: ['11.8% 5-yr CAGR (Balanced fund)', 'Loyalty additions from year 6', 'Unlimited fund switches'] },
              { ...this.sampleProducts()[1]!, id: 'u2', name: 'Smart Wealth Builder', carrier: 'TATA AIA', type: 'ULIP', premium: '₹50,000/yr',
                highlights: ['Top-ranked Multi-Cap fund', 'Wealth-boosters from year 10', 'Zero allocation charges'] },
            ],
          },
        };
      } else if (p.includes('compare') || p.includes('term') || p.includes('recommend')) {
        msg = {
          id: crypto.randomUUID(), author: 'bot', timestamp: new Date(),
          content: 'Here are the strongest matches for that profile, ranked by suitability:',
          attachment: { kind: 'product-cards', products: this.sampleProducts() },
        };
      } else {
        msg = {
          id: crypto.randomUUID(), author: 'bot', timestamp: new Date(),
          content:
            "I can help with product comparison, premium illustrations, rider analysis, underwriting checklists and tax positioning. Share the prospect's age, income, dependents and goal — I'll take it from there.",
        };
      }
      this.sessionsSvc.appendMessage(msg);
    }, 850);
  }

  private sampleProducts(): InsuranceProduct[] {
    return [
      {
        id: 'p1', name: 'SecureLife Elite Term', carrier: 'HDFC Life', type: 'Term',
        coverage: '₹1 Cr', tenure: '30 yrs', premium: '₹12,400/yr',
        rating: 5, recommended: true,
        highlights: [
          '99.4% claim settlement ratio',
          'Free annual health check-up',
          'Critical illness rider available',
        ],
      },
      {
        id: 'p2', name: 'iProtect Smart', carrier: 'ICICI Pru', type: 'Term',
        coverage: '₹1 Cr', tenure: '30 yrs', premium: '₹13,100/yr',
        rating: 4,
        highlights: [
          'Return-of-premium option',
          'Terminal illness benefit',
          'Spouse cover add-on',
        ],
      },
    ];
  }

  private sampleUnderwriting(): UnderwritingDoc[] {
    return [
      { id: 'd1', name: 'KYC — PAN + Aadhaar',  required: true,  description: 'Self-attested copies; e-KYC accepted via DigiLocker.' },
      { id: 'd2', name: 'Income proof',         required: true,  description: 'Latest 3 salary slips or Form 16 / ITR for last 2 years.' },
      { id: 'd3', name: 'Address proof',        required: true,  description: 'Utility bill, passport, or driving licence (≤ 3 months old).' },
      { id: 'd4', name: 'Medical examination',  required: true,  description: 'Full medicals at empanelled diagnostic centre — required for sum assured > ₹75 L.' },
      { id: 'd5', name: 'Financial questionnaire', required: false, description: 'Triggered if SA exceeds 25× annual income.' },
      { id: 'd6', name: 'NRI declaration',      required: false, description: 'Only if applicant is a non-resident Indian.' },
    ];
  }

  // -------- Auto-scroll ---------------------------------------------

  ngAfterViewChecked(): void {
    if (this.autoScroll && this.scrollArea) {
      const el = this.scrollArea.nativeElement;
      el.scrollTop = el.scrollHeight;
      this.autoScroll = false;
    }
  }
}
