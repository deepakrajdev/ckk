import { Injectable, computed, signal } from '@angular/core';
import {
  ChatMessage,
  ChatSession,
  InsuranceProduct,
} from '../models/chat.model';

const MAX_SESSIONS = 5;

@Injectable({ providedIn: 'root' })
export class ChatSessionsService {
  /** All sessions, newest first. Capped at MAX_SESSIONS. */
  private readonly _sessions = signal<ChatSession[]>(this.seedSessions());

  /** Active session id (one of the sessions above) */
  private readonly _activeId = signal<string>(this._sessions()[0]!.id);

  // -------- Public read-only signals --------------------------------

  readonly sessions = this._sessions.asReadonly();
  readonly activeId = this._activeId.asReadonly();

  readonly active = computed<ChatSession>(() => {
    const id = this._activeId();
    return (
      this._sessions().find((s) => s.id === id) ?? this._sessions()[0]!
    );
  });

  readonly messages = computed<ChatMessage[]>(() => this.active().messages);

  // -------- Mutations -----------------------------------------------

  /** Switch to a different session. No-op if id unknown. */
  selectSession(id: string): void {
    if (this._sessions().some((s) => s.id === id)) {
      this._activeId.set(id);
    }
  }

  /** Start a fresh session and make it active. Drops oldest if over cap. */
  startNewSession(): ChatSession {
    const fresh: ChatSession = {
      id: crypto.randomUUID(),
      title: 'New conversation',
      createdAt: new Date(),
      updatedAt: new Date(),
      messages: [
        {
          id: crypto.randomUUID(),
          author: 'bot',
          timestamp: new Date(),
          content:
            "👋 New session started. Share the prospect's profile — age, income, dependents, and what they're protecting against — and I'll match products and pull underwriting requirements.",
        },
      ],
    };
    this._sessions.update((all) => [fresh, ...all].slice(0, MAX_SESSIONS));
    this._activeId.set(fresh.id);
    return fresh;
  }

  /** Append a message to the active session and bump its updatedAt. */
  appendMessage(message: ChatMessage): void {
    this._sessions.update((all) =>
      all.map((s) => {
        if (s.id !== this._activeId()) return s;
        const messages = [...s.messages, message];
        // Auto-title from the first user message if still default
        const title =
          s.title === 'New conversation' && message.author === 'user'
            ? this.titleFrom(message.content)
            : s.title;
        return { ...s, messages, title, updatedAt: new Date() };
      })
    );
  }

  /** Replace the active session's messages wholesale (used for the seed). */
  setActiveMessages(messages: ChatMessage[]): void {
    this._sessions.update((all) =>
      all.map((s) =>
        s.id === this._activeId()
          ? { ...s, messages, updatedAt: new Date() }
          : s
      )
    );
  }

  // -------- Helpers -------------------------------------------------

  private titleFrom(content: string): string {
    const clean = content.replace(/\s+/g, ' ').trim();
    return clean.length > 48 ? clean.slice(0, 45).trimEnd() + '…' : clean;
  }

  /** Pre-seeded demo sessions so the strip isn't empty on first load. */
  private seedSessions(): ChatSession[] {
    const now = Date.now();
    const mins = (n: number) => new Date(now - n * 60_000);
    const hrs  = (n: number) => new Date(now - n * 60 * 60_000);
    const days = (n: number) => new Date(now - n * 24 * 60 * 60_000);

    const term: InsuranceProduct[] = [
      {
        id: 'p-secure', name: 'SecureLife Elite Term', carrier: 'HDFC Life',
        type: 'Term', coverage: '₹1 Cr', tenure: '30 yrs', premium: '₹12,400/yr',
        rating: 5, recommended: true,
        highlights: [
          '99.4% claim settlement ratio',
          'Free annual health check-up',
          'Critical illness rider available',
        ],
      },
      {
        id: 'p-iprotect', name: 'iProtect Smart', carrier: 'ICICI Pru',
        type: 'Term', coverage: '₹1 Cr', tenure: '30 yrs', premium: '₹13,100/yr',
        rating: 4,
        highlights: [
          'Return-of-premium option',
          'Terminal illness benefit',
          'Spouse cover add-on',
        ],
      },
    ];

    return [
      {
        id: 'sess-1',
        title: 'Term plan · 35yo non-smoker · ₹1 Cr',
        createdAt: mins(8),
        updatedAt: mins(2),
        messages: [
          {
            id: 'm1-1', author: 'bot', timestamp: mins(8),
            content:
              "👋 Hi Rohan — I'm your sales co-pilot. Share the prospect's profile and I'll match products and pull underwriting docs.",
          },
          {
            id: 'm1-2', author: 'user', timestamp: mins(7),
            content:
              'Prospect: 35-year-old, non-smoker, salaried (₹18 LPA), 2 dependents. Wants ₹1 Cr cover for 30 years. Suggest term plans.',
          },
          {
            id: 'm1-3', author: 'bot', timestamp: mins(2),
            content:
              "Strong matches — ranked by claim-settlement ratio, premium efficiency and rider flexibility:",
            attachment: { kind: 'product-cards', products: term },
          },
        ],
      },
      {
        id: 'sess-2',
        title: 'ULIP wealth creation · ₹50k/mo',
        createdAt: hrs(3),
        updatedAt: hrs(2),
        messages: [
          {
            id: 'm2-1', author: 'user', timestamp: hrs(3),
            content:
              'Client wants long-term wealth creation with insurance cover. Premium budget ₹50k/month. Recommend ULIPs.',
          },
          {
            id: 'm2-2', author: 'bot', timestamp: hrs(2),
            content:
              'Two ULIPs that have consistently outperformed their benchmark over 5 years for this ticket size:',
            attachment: {
              kind: 'product-cards',
              products: [
                { ...term[0]!, id: 'u-wealth', name: 'Wealth Plus ULIP',
                  carrier: 'Max Life', type: 'ULIP', premium: '₹50,000/yr',
                  highlights: [
                    '11.8% 5-yr CAGR (Balanced fund)',
                    'Loyalty additions from year 6',
                    'Unlimited fund switches',
                  ] },
                { ...term[1]!, id: 'u-smart', name: 'Smart Wealth Builder',
                  carrier: 'TATA AIA', type: 'ULIP', premium: '₹50,000/yr',
                  highlights: [
                    'Top-ranked Multi-Cap fund',
                    'Wealth-boosters from year 10',
                    'Zero allocation charges',
                  ] },
              ],
            },
          },
        ],
      },
      {
        id: 'sess-3',
        title: 'Underwriting · ₹2 Cr term plan',
        createdAt: hrs(20),
        updatedAt: hrs(19),
        messages: [
          {
            id: 'm3-1', author: 'user', timestamp: hrs(20),
            content:
              'What documents are required for underwriting a ₹2 Cr term plan? Self-employed prospect.',
          },
          {
            id: 'm3-2', author: 'bot', timestamp: hrs(19),
            content:
              'For a ₹2 Cr term plan on a self-employed prospect, the carrier will require:',
            attachment: {
              kind: 'underwriting',
              product: 'Term Plan · ₹2 Cr',
              documents: [
                { id: 'd1', name: 'KYC — PAN + Aadhaar', required: true,
                  description: 'Self-attested copies; e-KYC accepted via DigiLocker.' },
                { id: 'd2', name: 'Income proof', required: true,
                  description: 'ITR for last 3 years + audited financials for self-employed.' },
                { id: 'd3', name: 'Medical examination', required: true,
                  description: 'Full medicals — mandatory for SA > ₹75 L.' },
                { id: 'd4', name: 'Financial questionnaire', required: false,
                  description: 'Triggered when SA exceeds 25× annual income.' },
              ],
            },
          },
        ],
      },
      {
        id: 'sess-4',
        title: 'Pension plans · 45yo prospect',
        createdAt: days(2),
        updatedAt: days(2),
        messages: [
          {
            id: 'm4-1', author: 'user', timestamp: days(2),
            content: 'Recommend pension plans for a 45-year-old looking for guaranteed income at 60.',
          },
          {
            id: 'm4-2', author: 'bot', timestamp: days(2),
            content:
              'For guaranteed income at 60 with a 15-year accumulation window, I usually shortlist three options: deferred annuity plans from LIC and HDFC, and a ULIP-pension hybrid from ICICI. I can pull a side-by-side comparison if you confirm the premium budget and whether the client prefers monthly or annual payouts.',
          },
        ],
      },
      {
        id: 'sess-5',
        title: 'Critical illness rider explainer',
        createdAt: days(4),
        updatedAt: days(4),
        messages: [
          {
            id: 'm5-1', author: 'user', timestamp: days(4),
            content: 'Quick explainer on critical illness vs accidental death riders for a prospect.',
          },
          {
            id: 'm5-2', author: 'bot', timestamp: days(4),
            content:
              'Critical Illness (CI) rider pays a lump sum on diagnosis of any covered illness (typically 30–60 conditions: cancer, stroke, heart attack, kidney failure, major organ transplant). Payout is independent of the base sum assured. Accidental Death Benefit (ADB) doubles the sum assured if death is caused by an accident within 90 days. Together they cost roughly 8–15% of base premium and meaningfully widen the protection envelope — recommend CI for prospects with family history of lifestyle disease, ADB for anyone with significant road exposure (frequent travel, commute).',
          },
        ],
      },
    ];
  }
}
