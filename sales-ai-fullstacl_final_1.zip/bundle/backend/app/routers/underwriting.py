"""Underwriting Checks endpoints — cascading form workflows for every tab."""

from fastapi import APIRouter, Depends, Query

from app.models import (
    FinancialResponse,
    MedicalResponse,
    NonMedicalResponse,
    UnderwritingChecksBundle,
    UnderwritingOptions,
)
from app.services.store import Store, get_store

router = APIRouter(prefix="/api/underwriting", tags=["underwriting"])


@router.get("/checks", response_model=UnderwritingChecksBundle)
async def get_checks(store: Store = Depends(get_store)) -> UnderwritingChecksBundle:
    """Legacy flat payload — every row in every table."""
    return await store.underwriting_checks()


@router.get("/options", response_model=UnderwritingOptions)
async def options(store: Store = Depends(get_store)) -> UnderwritingOptions:
    """
    ★ Cascading dropdown data — drives every tab's plan → second-dropdown cascade.
    Frontend uses financial_occupations[plan], medical_age_limits[plan],
    non_medical_age_limits[plan] to populate the second dropdown.
    """
    return await store.underwriting_options()


# Backward-compat alias
@router.get("/financial-options", response_model=UnderwritingOptions)
async def financial_options(store: Store = Depends(get_store)) -> UnderwritingOptions:
    return await store.underwriting_options()


# ============================================================
# ★ Filtered grouped responses — match the JSON contract:
#   { planName, requestType, occupationLifeType/ageLimit, <suc array> }
# ============================================================

@router.get("/financial", response_model=FinancialResponse)
async def get_financial(
    plan: str = Query(..., description="Plan name (e.g. 'i select 360')"),
    occupation: str = Query(..., description="Occupation / Life Type"),
    store: Store = Depends(get_store),
) -> FinancialResponse:
    """Returns the grouped Financial response — every SUC band for the (plan, occupation)."""
    return await store.financial_response(plan, occupation)


@router.get("/medical-non-disclosure", response_model=MedicalResponse)
async def get_medical_non_disclosure(
    plan: str = Query(...),
    age_limit: str = Query(..., alias="ageLimit"),
    store: Store = Depends(get_store),
) -> MedicalResponse:
    """Grouped Medical Non-Disclosure response for the (plan, age)."""
    return await store.medical_response("non-disclosure", plan, age_limit)


@router.get("/medical-disclosure", response_model=MedicalResponse)
async def get_medical_disclosure(
    plan: str = Query(...),
    age_limit: str = Query(..., alias="ageLimit"),
    store: Store = Depends(get_store),
) -> MedicalResponse:
    """Grouped Medical Disclosure response for the (plan, age)."""
    return await store.medical_response("disclosure", plan, age_limit)


@router.get("/non-medical", response_model=NonMedicalResponse)
async def get_non_medical(
    plan: str = Query(...),
    age_limit: str = Query(..., alias="ageLimit"),
    store: Store = Depends(get_store),
) -> NonMedicalResponse:
    """Grouped Non-Medical / VMER response for the (plan, age) — no SUC step."""
    return await store.non_medical_response(plan, age_limit)
