"""
Initial demo data — same content the frontend ships with.
"""

from datetime import datetime, timedelta, timezone

from app.models import (
    ChatMessage,
    ChatSession,
    EarningsSummary,
    FinancialCheck,
    Incentive,
    IncentiveTag,
    InsuranceProduct,
    InsuranceProductType,
    InventoryRow,
    InventoryStat,
    Lead,
    LeadStage,
    LibraryCategory,
    LibraryDocument,
    MedicalCheck,
    MessageAuthor,
    NonMedicalCheck,
    ProductCardsAttachment,
    UnderwritingAttachment,
    UnderwritingChecksBundle,
    UnderwritingDoc,
    UnderwritingStage,
    UserProfile,
)


def _now() -> datetime:
    return datetime.now(timezone.utc)


def me() -> UserProfile:
    return UserProfile(
        id="48201",
        name="Rohan Sharma",
        initials="RS",
        role="Senior Advisor",
        email="rohan.sharma@aegis.example",
    )


# ---------------- Sessions ----------------

def _term_products() -> list[InsuranceProduct]:
    return [
        InsuranceProduct(
            id="p-secure", name="SecureLife Elite Term", carrier="HDFC Life",
            type=InsuranceProductType.term,
            coverage="₹1 Cr", tenure="30 yrs", premium="₹12,400/yr",
            rating=5, recommended=True,
            highlights=[
                "99.4% claim settlement ratio",
                "Free annual health check-up",
                "Critical illness rider available",
            ],
        ),
        InsuranceProduct(
            id="p-iprotect", name="iProtect Smart", carrier="ICICI Pru",
            type=InsuranceProductType.term,
            coverage="₹1 Cr", tenure="30 yrs", premium="₹13,100/yr",
            rating=4,
            highlights=[
                "Return-of-premium option",
                "Terminal illness benefit",
                "Spouse cover add-on",
            ],
        ),
    ]


def sessions() -> list[ChatSession]:
    now = _now()
    mins = lambda n: now - timedelta(minutes=n)
    hrs  = lambda n: now - timedelta(hours=n)
    days = lambda n: now - timedelta(days=n)

    term = _term_products()

    return [
        ChatSession(
            id="sess-1",
            title="Term plan · 35yo non-smoker · ₹1 Cr",
            created_at=mins(8), updated_at=mins(2),
            messages=[
                ChatMessage(id="m1-1", author=MessageAuthor.bot, timestamp=mins(8),
                    content="👋 Hi Rohan — I'm your sales co-pilot. Share the prospect's profile and I'll match products and pull underwriting docs."),
                ChatMessage(id="m1-2", author=MessageAuthor.user, timestamp=mins(7),
                    content="Prospect: 35-year-old, non-smoker, salaried (₹18 LPA), 2 dependents. Wants ₹1 Cr cover for 30 years. Suggest term plans."),
                ChatMessage(id="m1-3", author=MessageAuthor.bot, timestamp=mins(2),
                    content="Strong matches — ranked by claim-settlement ratio, premium efficiency and rider flexibility:",
                    attachment=ProductCardsAttachment(products=term)),
            ],
        ),
        ChatSession(
            id="sess-2",
            title="ULIP wealth creation · ₹50k/mo",
            created_at=hrs(3), updated_at=hrs(2),
            messages=[
                ChatMessage(id="m2-1", author=MessageAuthor.user, timestamp=hrs(3),
                    content="Client wants long-term wealth creation with insurance cover. Premium budget ₹50k/month. Recommend ULIPs."),
                ChatMessage(id="m2-2", author=MessageAuthor.bot, timestamp=hrs(2),
                    content="Two ULIPs that have consistently outperformed their benchmark over 5 years for this ticket size:",
                    attachment=ProductCardsAttachment(products=[
                        InsuranceProduct(
                            id="u-wealth", name="Wealth Plus ULIP", carrier="Max Life",
                            type=InsuranceProductType.ulip,
                            coverage="₹1 Cr", tenure="20 yrs", premium="₹50,000/yr",
                            rating=5, recommended=True,
                            highlights=[
                                "11.8% 5-yr CAGR (Balanced fund)",
                                "Loyalty additions from year 6",
                                "Unlimited fund switches",
                            ],
                        ),
                        InsuranceProduct(
                            id="u-smart", name="Smart Wealth Builder", carrier="TATA AIA",
                            type=InsuranceProductType.ulip,
                            coverage="₹1 Cr", tenure="20 yrs", premium="₹50,000/yr",
                            rating=4,
                            highlights=[
                                "Top-ranked Multi-Cap fund",
                                "Wealth-boosters from year 10",
                                "Zero allocation charges",
                            ],
                        ),
                    ])),
            ],
        ),
        ChatSession(
            id="sess-3",
            title="Underwriting · ₹2 Cr term plan",
            created_at=hrs(20), updated_at=hrs(19),
            messages=[
                ChatMessage(id="m3-1", author=MessageAuthor.user, timestamp=hrs(20),
                    content="What documents are required for underwriting a ₹2 Cr term plan? Self-employed prospect."),
                ChatMessage(id="m3-2", author=MessageAuthor.bot, timestamp=hrs(19),
                    content="For a ₹2 Cr term plan on a self-employed prospect, the carrier will require:",
                    attachment=UnderwritingAttachment(
                        product="Term Plan · ₹2 Cr",
                        documents=[
                            UnderwritingDoc(id="d1", name="KYC — PAN + Aadhaar",   required=True,
                                            description="Self-attested copies; e-KYC accepted via DigiLocker."),
                            UnderwritingDoc(id="d2", name="Income proof",          required=True,
                                            description="ITR for last 3 years + audited financials for self-employed."),
                            UnderwritingDoc(id="d3", name="Medical examination",   required=True,
                                            description="Full medicals — mandatory for SA > ₹75 L."),
                            UnderwritingDoc(id="d4", name="Financial questionnaire", required=False,
                                            description="Triggered when SA exceeds 25× annual income."),
                        ],
                    )),
            ],
        ),
        ChatSession(
            id="sess-4",
            title="Pension plans · 45yo prospect",
            created_at=days(2), updated_at=days(2),
            messages=[
                ChatMessage(id="m4-1", author=MessageAuthor.user, timestamp=days(2),
                    content="Recommend pension plans for a 45-year-old looking for guaranteed income at 60."),
                ChatMessage(id="m4-2", author=MessageAuthor.bot, timestamp=days(2),
                    content=("For guaranteed income at 60 with a 15-year accumulation window, I usually shortlist three options: "
                             "deferred annuity plans from LIC and HDFC, and a ULIP-pension hybrid from ICICI. I can pull a "
                             "side-by-side comparison if you confirm the premium budget and whether the client prefers monthly or annual payouts.")),
            ],
        ),
        ChatSession(
            id="sess-5",
            title="Critical illness rider explainer",
            created_at=days(4), updated_at=days(4),
            messages=[
                ChatMessage(id="m5-1", author=MessageAuthor.user, timestamp=days(4),
                    content="Quick explainer on critical illness vs accidental death riders for a prospect."),
                ChatMessage(id="m5-2", author=MessageAuthor.bot, timestamp=days(4),
                    content=("Critical Illness (CI) rider pays a lump sum on diagnosis of any covered illness (typically 30-60 conditions: "
                             "cancer, stroke, heart attack, kidney failure, major organ transplant). Payout is independent of the base sum "
                             "assured. Accidental Death Benefit (ADB) doubles the sum assured if death is caused by an accident within 90 days. "
                             "Together they cost roughly 8-15% of base premium and meaningfully widen the protection envelope - recommend "
                             "CI for prospects with family history of lifestyle disease, ADB for anyone with significant road exposure.")),
            ],
        ),
    ]


# ---------------- Inventory (FLS pipeline) ----------------

def inventory() -> list[InventoryRow]:
    """FLS pipeline records for the inventory screen."""
    return [
        InventoryRow(id="i1", fls_id="FLS-48201-Q2-0142", nop=12, pfr="₹12,40,000",
                     underwriting_stage=UnderwritingStage.issued,    submission=12, issuance=12, total_nop=156),
        InventoryRow(id="i2", fls_id="FLS-48201-Q2-0143", nop=8,  pfr="₹6,80,000",
                     underwriting_stage=UnderwritingStage.medical,   submission=8,  issuance=0,  total_nop=156),
        InventoryRow(id="i3", fls_id="FLS-48201-Q2-0144", nop=15, pfr="₹18,50,000",
                     underwriting_stage=UnderwritingStage.in_review, submission=15, issuance=11, total_nop=156),
        InventoryRow(id="i4", fls_id="FLS-48201-Q2-0145", nop=6,  pfr="₹4,20,000",
                     underwriting_stage=UnderwritingStage.submitted, submission=6,  issuance=0,  total_nop=156),
        InventoryRow(id="i5", fls_id="FLS-48201-Q2-0146", nop=22, pfr="₹26,40,000",
                     underwriting_stage=UnderwritingStage.approved,  submission=22, issuance=18, total_nop=156),
        InventoryRow(id="i6", fls_id="FLS-48201-Q2-0147", nop=4,  pfr="₹3,20,000",
                     underwriting_stage=UnderwritingStage.declined,  submission=4,  issuance=0,  total_nop=156),
        InventoryRow(id="i7", fls_id="FLS-48201-Q2-0148", nop=10, pfr="₹9,60,000",
                     underwriting_stage=UnderwritingStage.issued,    submission=10, issuance=10, total_nop=156),
        InventoryRow(id="i8", fls_id="FLS-48201-Q2-0149", nop=18, pfr="₹21,80,000",
                     underwriting_stage=UnderwritingStage.medical,   submission=18, issuance=5,  total_nop=156),
    ]


def inventory_stats() -> list[InventoryStat]:
    return [
        InventoryStat(label="Total NOP",        value="156",     delta="14 this week", delta_up=True),
        InventoryStat(label="Submissions MTD",  value="95",      delta="12.4%",        delta_up=True),
        InventoryStat(label="Issuance rate",    value="74%",     delta="3.1%",         delta_up=True),
        InventoryStat(label="PFR (MTD)",        value="₹1.02 Cr", delta="8.9%",        delta_up=True),
    ]


# ---------------- Incentives ----------------

def earnings() -> EarningsSummary:
    return EarningsSummary(
        period_label="Q2 2026",
        amount="₹2,84,500",
        delta_pct=18.2,
        delta_up=True,
        next_tier_label="Gold tier",
        next_tier_amount="₹4,00,000",
        next_tier_remaining="₹1,15,500",
        current_tier_label="Silver tier",
        progress_pct=71,
    )


def incentives() -> list[Incentive]:
    return [
        Incentive(id="c1", title="Term Plan Champion",  reward="₹50,000",  progress=78,
                  current="23 policies",  target="30",       deadline="Jun 30", tag=IncentiveTag.closing_soon),
        Incentive(id="c2", title="ULIP Premium Push",   reward="₹40,000",  progress=52,
                  current="₹6.2 L premium", target="₹12 L",  deadline="Jul 31", tag=IncentiveTag.active),
        Incentive(id="c3", title="New Customer Drive",  reward="Bali Trip", progress=35,
                  current="14 new",       target="40 new",   deadline="Aug 15", tag=IncentiveTag.stretch),
        Incentive(id="c4", title="Renewal Hero",        reward="₹25,000",  progress=92,
                  current="184 renewals", target="200",      deadline="Jun 30", tag=IncentiveTag.closing_soon),
    ]


# ---------------- Leads ----------------

def leads() -> list[Lead]:
    return [
        Lead(id="l1", initials="AP", name="Anita Pillai",  city="Bengaluru", interest="Term ₹1 Cr",
             potential="₹14,800/yr",  stage=LeadStage.quoted,     next_action="Send revised quote · today", hot=True),
        Lead(id="l2", initials="KM", name="Karan Mehta",   city="Mumbai",    interest="ULIP ₹50k/mo",
             potential="₹6,00,000/yr", stage=LeadStage.negotiating, next_action="Schedule call · tomorrow 11 AM"),
        Lead(id="l3", initials="RS", name="Riya Sharma",   city="Delhi",     interest="Pension Plan",
             potential="₹1,20,000/yr", stage=LeadStage.contacted,  next_action="Follow-up email · Wednesday"),
        Lead(id="l4", initials="VG", name="Vikram Gupta",  city="Pune",      interest="Term ₹2 Cr",
             potential="₹26,400/yr",   stage=LeadStage.new,        next_action="First contact · today", hot=True),
        Lead(id="l5", initials="SN", name="Sneha Nair",    city="Kochi",     interest="Endowment",
             potential="₹48,000/yr",   stage=LeadStage.closed,     next_action="Policy issued · Jun 12"),
        Lead(id="l6", initials="AB", name="Arjun Bose",    city="Kolkata",   interest="Term + CI Rider",
             potential="₹18,200/yr",   stage=LeadStage.quoted,     next_action="Awaiting decision · 3 days"),
        Lead(id="l7", initials="MJ", name="Meera Joshi",   city="Ahmedabad", interest="Child Plan",
             potential="₹72,000/yr",   stage=LeadStage.contacted,  next_action="Send brochure · today"),
    ]


# ---------------- Underwriting Checks ----------------

def underwriting_checks() -> UnderwritingChecksBundle:
    """
    ★ Realistic seed data — specific insurance product names with cascading
    variety so different plans expose different occupations & age limits.
    """

    # Plan-name catalogue (specific product names, matching the user's JSON).
    # Defined as locals so each list reads top-down per category.
    P_TERM_1 = "iProtect Smart"           # ICICI Pru Term
    P_TERM_2 = "Click 2 Protect Super"    # HDFC Life Term
    P_TERM_3 = "SecureLife Elite Term"    # Bajaj Allianz Term
    P_ULIP_1 = "i select 360"             # ICICI Pru ULIP
    P_ULIP_2 = "Wealth Plus ULIP"         # Max Life ULIP
    P_ULIP_3 = "Smart Wealth Builder"     # TATA AIA ULIP
    P_END_1  = "Saral Jeevan Bima"        # LIC Endowment
    P_END_2  = "Smart Endowment Plus"     # HDFC Endowment
    P_PEN_1  = "Smart Pension Plan"       # HDFC Pension
    P_PEN_2  = "Future Income Plus"       # Max Life Pension
    P_WL_1   = "Lifetime Income"          # HDFC Whole Life
    P_MB_1   = "Smart Money Back"         # LIC Money Back
    P_CP_1   = "Smart Future Plan"        # HDFC Child Plan

    # ============================================================
    # FINANCIAL — Plan × Occupation × SUC (each row = one combination)
    # ============================================================
    financial = [
        # ----- iProtect Smart -----
        FinancialCheck(id="f-1", plan_name=P_TERM_1,
                       occupation_life_type="Salaried · Class I",
                       suc_limit="Up to ₹50 L",
                       financial_requirement="No financial documents required.",
                       document_list=["KYC", "Income declaration"]),
        FinancialCheck(id="f-2", plan_name=P_TERM_1,
                       occupation_life_type="Salaried · Class I",
                       suc_limit="₹50 L – ₹1 Cr",
                       financial_requirement="Income proof for last 12 months.",
                       document_list=["3 salary slips", "Form 16", "Bank statement 6m"]),
        FinancialCheck(id="f-3", plan_name=P_TERM_1,
                       occupation_life_type="Salaried · Class I",
                       suc_limit="₹1 Cr – ₹2 Cr",
                       financial_requirement="Extended income proof + bank statement.",
                       document_list=["Form 16 (2 yrs)", "ITR (2 yrs)", "Bank statement 12m"]),
        FinancialCheck(id="f-4", plan_name=P_TERM_1,
                       occupation_life_type="Self-employed Professional",
                       suc_limit="Up to ₹75 L",
                       financial_requirement="ITR + practice proof.",
                       document_list=["ITR (2 yrs)", "Practice certificate", "Bank stmt 6m"]),
        FinancialCheck(id="f-5", plan_name=P_TERM_1,
                       occupation_life_type="Self-employed Professional",
                       suc_limit="₹75 L – ₹2 Cr",
                       financial_requirement="Extended ITR + bank statements.",
                       document_list=["ITR (3 yrs)", "Bank stmt 12m", "Practice certificate"]),
        FinancialCheck(id="f-6", plan_name=P_TERM_1,
                       occupation_life_type="Business Owner",
                       suc_limit="Up to ₹75 L",
                       financial_requirement="ITR + audited P&L.",
                       document_list=["ITR (2 yrs)", "Audited P&L", "GST returns 6m"]),
        FinancialCheck(id="f-7", plan_name=P_TERM_1,
                       occupation_life_type="Business Owner",
                       suc_limit="₹75 L – ₹2 Cr",
                       financial_requirement="Audited financials + GST returns.",
                       document_list=["ITR (3 yrs)", "Audited P&L + BS", "GST returns 12m"]),

        # ----- Click 2 Protect Super -----
        FinancialCheck(id="f-8", plan_name=P_TERM_2,
                       occupation_life_type="Salaried · Class I",
                       suc_limit="Up to ₹50 L",
                       financial_requirement="Basic income proof.",
                       document_list=["Form 16", "3 salary slips"]),
        FinancialCheck(id="f-9", plan_name=P_TERM_2,
                       occupation_life_type="Salaried · Class I",
                       suc_limit="₹50 L – ₹1 Cr",
                       financial_requirement="Full income proofs.",
                       document_list=["Form 16 (2 yrs)", "Salary slips (6 m)", "Bank stmt 12m"]),
        FinancialCheck(id="f-10", plan_name=P_TERM_2,
                       occupation_life_type="Salaried · Class II/III",
                       suc_limit="Up to ₹25 L",
                       financial_requirement="Salary slips + bank statement.",
                       document_list=["3 salary slips", "Bank statement 3m"]),
        FinancialCheck(id="f-11", plan_name=P_TERM_2,
                       occupation_life_type="Salaried · Class II/III",
                       suc_limit="₹25 L – ₹50 L",
                       financial_requirement="Extended salary proof.",
                       document_list=["Form 16 (2 yrs)", "Salary slips (6 m)"]),

        # ----- SecureLife Elite Term (broadest eligibility) -----
        FinancialCheck(id="f-12", plan_name=P_TERM_3,
                       occupation_life_type="Salaried · Class I",
                       suc_limit="Up to ₹50 L",
                       financial_requirement="No financial documents required.",
                       document_list=["KYC", "Income declaration"]),
        FinancialCheck(id="f-13", plan_name=P_TERM_3,
                       occupation_life_type="Salaried · Class I",
                       suc_limit="Above ₹2 Cr",
                       financial_requirement="CA-certified net-worth + full income proofs.",
                       document_list=["ITR (3 yrs)", "CA net-worth cert.", "Source-of-funds declaration"]),
        FinancialCheck(id="f-14", plan_name=P_TERM_3,
                       occupation_life_type="Self-employed Professional",
                       suc_limit="Above ₹2 Cr",
                       financial_requirement="CA-certified financials + full ITR.",
                       document_list=["ITR (3 yrs)", "CA-certified financials", "Bank stmt 12m"]),
        FinancialCheck(id="f-15", plan_name=P_TERM_3,
                       occupation_life_type="Business Owner",
                       suc_limit="Above ₹2 Cr",
                       financial_requirement="Full financial DD + source of funds.",
                       document_list=["ITR (3 yrs)", "Audited financials", "GST 12m",
                                      "CA net-worth cert.", "Source-of-funds declaration"]),
        FinancialCheck(id="f-16", plan_name=P_TERM_3,
                       occupation_life_type="Housewife (income-substitute)",
                       suc_limit="Up to ₹50 L",
                       financial_requirement="Spouse income proofs; capped at 50% of spouse SA.",
                       document_list=["Spouse Form 16", "Marriage certificate", "Spouse policy details"]),
        FinancialCheck(id="f-17", plan_name=P_TERM_3,
                       occupation_life_type="Housewife (income-substitute)",
                       suc_limit="₹50 L – ₹1 Cr",
                       financial_requirement="Full spouse financials + relationship proof.",
                       document_list=["Spouse ITR (2 yrs)", "Spouse bank stmt 12m",
                                      "Marriage certificate"]),

        # ----- i select 360 (ULIP — the user's example) -----
        FinancialCheck(id="f-18", plan_name=P_ULIP_1,
                       occupation_life_type="Salaried",
                       suc_limit="0 – 1 Cr",
                       financial_requirement="Income proof for current year.",
                       document_list=["Form 16", "3 salary slips"]),
        FinancialCheck(id="f-19", plan_name=P_ULIP_1,
                       occupation_life_type="Salaried",
                       suc_limit="1 – 2 Cr",
                       financial_requirement="Extended income proof + bank statement.",
                       document_list=["ITR (2 yrs)", "Bank stmt 12m", "Source-of-funds declaration"]),
        FinancialCheck(id="f-20", plan_name=P_ULIP_1,
                       occupation_life_type="Self-employed",
                       suc_limit="0 – 1 Cr",
                       financial_requirement="ITR for last 2 years.",
                       document_list=["ITR (2 yrs)", "Bank stmt 6m"]),
        FinancialCheck(id="f-21", plan_name=P_ULIP_1,
                       occupation_life_type="Self-employed",
                       suc_limit="1 – 3 Cr",
                       financial_requirement="Full financial DD with CA certification.",
                       document_list=["ITR (3 yrs)", "CA-certified financials", "Bank stmt 12m"]),

        # ----- Wealth Plus ULIP -----
        FinancialCheck(id="f-22", plan_name=P_ULIP_2,
                       occupation_life_type="Salaried · Class I",
                       suc_limit="Up to ₹25 L premium",
                       financial_requirement="Income proof for current year.",
                       document_list=["Form 16", "3 salary slips"]),
        FinancialCheck(id="f-23", plan_name=P_ULIP_2,
                       occupation_life_type="Business Owner",
                       suc_limit="Up to ₹50 L premium",
                       financial_requirement="Audited financials + GST returns.",
                       document_list=["ITR (3 yrs)", "Audited P&L + BS", "GST returns 12m"]),

        # ----- Smart Wealth Builder -----
        FinancialCheck(id="f-24", plan_name=P_ULIP_3,
                       occupation_life_type="Salaried · Class I",
                       suc_limit="Up to ₹25 L premium",
                       financial_requirement="Income proof for current year.",
                       document_list=["Form 16", "Salary slips"]),
        FinancialCheck(id="f-25", plan_name=P_ULIP_3,
                       occupation_life_type="Self-employed Professional",
                       suc_limit="Up to ₹25 L premium",
                       financial_requirement="ITR + practice certificate.",
                       document_list=["ITR (2 yrs)", "Practice certificate"]),

        # ----- Saral Jeevan Bima (Endowment) -----
        FinancialCheck(id="f-26", plan_name=P_END_1,
                       occupation_life_type="Salaried · Class I",
                       suc_limit="Up to ₹25 L",
                       financial_requirement="Basic income proof.",
                       document_list=["Form 16", "Salary slip"]),
        FinancialCheck(id="f-27", plan_name=P_END_1,
                       occupation_life_type="Salaried · Class II/III",
                       suc_limit="Up to ₹15 L",
                       financial_requirement="Salary slips for last 3 months.",
                       document_list=["3 salary slips", "Bank stmt 3m"]),

        # ----- Smart Endowment Plus -----
        FinancialCheck(id="f-28", plan_name=P_END_2,
                       occupation_life_type="Salaried · Class I",
                       suc_limit="Up to ₹50 L",
                       financial_requirement="Basic income proof.",
                       document_list=["Form 16", "3 salary slips"]),
        FinancialCheck(id="f-29", plan_name=P_END_2,
                       occupation_life_type="Self-employed Professional",
                       suc_limit="Up to ₹1 Cr",
                       financial_requirement="ITR + practice certificate.",
                       document_list=["ITR (2 yrs)", "Practice certificate"]),

        # ----- Smart Pension Plan -----
        FinancialCheck(id="f-30", plan_name=P_PEN_1,
                       occupation_life_type="Salaried · Class I",
                       suc_limit="Up to ₹50 L corpus",
                       financial_requirement="Income proof for current year.",
                       document_list=["Form 16", "3 salary slips"]),
        FinancialCheck(id="f-31", plan_name=P_PEN_1,
                       occupation_life_type="Self-employed Professional",
                       suc_limit="Up to ₹1 Cr corpus",
                       financial_requirement="ITR + practice certificate.",
                       document_list=["ITR (2 yrs)", "Practice certificate", "Bank stmt 6m"]),

        # ----- Future Income Plus -----
        FinancialCheck(id="f-32", plan_name=P_PEN_2,
                       occupation_life_type="Salaried · Class I",
                       suc_limit="Above ₹50 L corpus",
                       financial_requirement="Extended income proof + retirement plan.",
                       document_list=["ITR (2 yrs)", "Bank stmt 12m", "Existing pension docs"]),

        # ----- Lifetime Income (Whole Life) -----
        FinancialCheck(id="f-33", plan_name=P_WL_1,
                       occupation_life_type="Salaried · Class I",
                       suc_limit="Up to ₹1 Cr",
                       financial_requirement="Full income proofs for last 2 years.",
                       document_list=["Form 16 (2 yrs)", "ITR (2 yrs)", "Bank stmt 12m"]),
        FinancialCheck(id="f-34", plan_name=P_WL_1,
                       occupation_life_type="Business Owner",
                       suc_limit="Up to ₹2 Cr",
                       financial_requirement="Audited financials + GST returns.",
                       document_list=["ITR (3 yrs)", "Audited P&L + BS", "GST returns 12m"]),

        # ----- Smart Money Back -----
        FinancialCheck(id="f-35", plan_name=P_MB_1,
                       occupation_life_type="Salaried · Class I",
                       suc_limit="Up to ₹50 L",
                       financial_requirement="Basic income proof.",
                       document_list=["Form 16", "3 salary slips"]),
        FinancialCheck(id="f-36", plan_name=P_MB_1,
                       occupation_life_type="Salaried · Class II/III",
                       suc_limit="Up to ₹25 L",
                       financial_requirement="Salary slips + bank statement.",
                       document_list=["3 salary slips", "Bank stmt 3m"]),

        # ----- Smart Future Plan (Child) -----
        FinancialCheck(id="f-37", plan_name=P_CP_1,
                       occupation_life_type="Salaried · Class I",
                       suc_limit="Up to ₹50 L",
                       financial_requirement="Basic income proof + child KYC.",
                       document_list=["Form 16", "3 salary slips", "Child birth certificate"]),
        FinancialCheck(id="f-38", plan_name=P_CP_1,
                       occupation_life_type="Self-employed Professional",
                       suc_limit="Up to ₹75 L",
                       financial_requirement="ITR + child KYC.",
                       document_list=["ITR (2 yrs)", "Child birth certificate", "Bank stmt 6m"]),
    ]

    # ============================================================
    # MEDICAL NON-DISCLOSURE — Plan × Age × SUC
    # ============================================================
    medical_non_disclosure = [
        # iProtect Smart — full age coverage
        MedicalCheck(id="mnd-1", plan_name=P_TERM_1, age_limit="18-35",
                     suc_limit="Up to ₹50 L",
                     medical_requirements=["No medicals", "Tele-UW only"]),
        MedicalCheck(id="mnd-2", plan_name=P_TERM_1, age_limit="18-35",
                     suc_limit="₹50 L – ₹1 Cr",
                     medical_requirements=["MER", "Urine R/E"]),
        MedicalCheck(id="mnd-3", plan_name=P_TERM_1, age_limit="36-45",
                     suc_limit="Up to ₹50 L",
                     medical_requirements=["MER", "Urine R/E"]),
        MedicalCheck(id="mnd-4", plan_name=P_TERM_1, age_limit="36-45",
                     suc_limit="₹50 L – ₹1 Cr",
                     medical_requirements=["MER", "ECG", "FBS", "Lipid"]),
        MedicalCheck(id="mnd-5", plan_name=P_TERM_1, age_limit="46-55",
                     suc_limit="Up to ₹50 L",
                     medical_requirements=["MER", "ECG", "FBS", "HbA1c"]),
        MedicalCheck(id="mnd-6", plan_name=P_TERM_1, age_limit="56-65",
                     suc_limit="Any",
                     medical_requirements=["Full medicals", "TMT", "2D Echo", "KFT", "LFT"]),

        # Click 2 Protect Super — capped at 55
        MedicalCheck(id="mnd-7", plan_name=P_TERM_2, age_limit="18-35",
                     suc_limit="Up to ₹50 L",
                     medical_requirements=["No medicals"]),
        MedicalCheck(id="mnd-8", plan_name=P_TERM_2, age_limit="36-45",
                     suc_limit="Up to ₹50 L",
                     medical_requirements=["MER", "Urine R/E"]),
        MedicalCheck(id="mnd-9", plan_name=P_TERM_2, age_limit="46-55",
                     suc_limit="Up to ₹50 L",
                     medical_requirements=["MER", "ECG", "FBS"]),

        # SecureLife Elite — broadest
        MedicalCheck(id="mnd-10", plan_name=P_TERM_3, age_limit="18-35",
                     suc_limit="Any",
                     medical_requirements=["MER"]),
        MedicalCheck(id="mnd-11", plan_name=P_TERM_3, age_limit="56-65",
                     suc_limit="Any",
                     medical_requirements=["Full medicals", "TMT", "2D Echo"]),

        # i select 360 (ULIP)
        MedicalCheck(id="mnd-12", plan_name=P_ULIP_1, age_limit="18-45",
                     suc_limit="Up to ₹50 L",
                     medical_requirements=["MER", "ECG"]),
        MedicalCheck(id="mnd-13", plan_name=P_ULIP_1, age_limit="18-45",
                     suc_limit="Above ₹50 L",
                     medical_requirements=["MER", "ECG", "FBS", "Lipid"]),
        MedicalCheck(id="mnd-14", plan_name=P_ULIP_1, age_limit="46-65",
                     suc_limit="Any",
                     medical_requirements=["Full medicals", "TMT", "Lipid", "KFT"]),

        # Wealth Plus
        MedicalCheck(id="mnd-15", plan_name=P_ULIP_2, age_limit="18-45",
                     suc_limit="Up to ₹50 L",
                     medical_requirements=["MER"]),

        # Smart Wealth Builder
        MedicalCheck(id="mnd-16", plan_name=P_ULIP_3, age_limit="18-45",
                     suc_limit="Up to ₹50 L",
                     medical_requirements=["MER", "Urine R/E"]),

        # Endowment plans
        MedicalCheck(id="mnd-17", plan_name=P_END_1, age_limit="18-45",
                     suc_limit="Up to ₹25 L",
                     medical_requirements=["MER"]),
        MedicalCheck(id="mnd-18", plan_name=P_END_2, age_limit="18-45",
                     suc_limit="Up to ₹50 L",
                     medical_requirements=["MER", "Urine R/E"]),
        MedicalCheck(id="mnd-19", plan_name=P_END_2, age_limit="46-65",
                     suc_limit="Any",
                     medical_requirements=["Full medicals", "TMT"]),

        # Pension plans
        MedicalCheck(id="mnd-20", plan_name=P_PEN_1, age_limit="40-55",
                     suc_limit="Up to ₹50 L",
                     medical_requirements=["MER", "ECG", "FBS"]),
        MedicalCheck(id="mnd-21", plan_name=P_PEN_1, age_limit="56-65",
                     suc_limit="Any",
                     medical_requirements=["Full medicals", "TMT", "2D Echo"]),

        # Whole Life
        MedicalCheck(id="mnd-22", plan_name=P_WL_1, age_limit="18-45",
                     suc_limit="Any",
                     medical_requirements=["MER", "ECG", "Lipid", "FBS"]),

        # Money Back
        MedicalCheck(id="mnd-23", plan_name=P_MB_1, age_limit="18-45",
                     suc_limit="Up to ₹50 L",
                     medical_requirements=["MER", "Urine R/E"]),

        # Child Plan
        MedicalCheck(id="mnd-24", plan_name=P_CP_1, age_limit="25-40",
                     suc_limit="Up to ₹50 L",
                     medical_requirements=["MER", "Urine R/E"]),
        MedicalCheck(id="mnd-25", plan_name=P_CP_1, age_limit="41-55",
                     suc_limit="Any",
                     medical_requirements=["MER", "ECG", "FBS"]),
    ]

    # ============================================================
    # MEDICAL DISCLOSURE — heavier requirements (condition-specific)
    # ============================================================
    medical_disclosure = [
        # iProtect Smart
        MedicalCheck(id="md-1", plan_name=P_TERM_1, age_limit="18-35",
                     suc_limit="Up to ₹50 L",
                     medical_requirements=["MER", "Targeted tests", "Condition-specific report"]),
        MedicalCheck(id="md-2", plan_name=P_TERM_1, age_limit="18-35",
                     suc_limit="Above ₹50 L",
                     medical_requirements=["Full medicals", "Condition-specific report"]),
        MedicalCheck(id="md-3", plan_name=P_TERM_1, age_limit="36-45",
                     suc_limit="Any",
                     medical_requirements=["Full medicals", "HbA1c", "Condition-specific report"]),
        MedicalCheck(id="md-4", plan_name=P_TERM_1, age_limit="46-55",
                     suc_limit="Any",
                     medical_requirements=["Full medicals", "TMT", "Condition-specific report"]),
        MedicalCheck(id="md-5", plan_name=P_TERM_1, age_limit="56-65",
                     suc_limit="Any",
                     medical_requirements=["Full medicals", "TMT", "2D Echo", "Specialist consult"]),

        # Click 2 Protect Super
        MedicalCheck(id="md-6", plan_name=P_TERM_2, age_limit="18-35",
                     suc_limit="Up to ₹50 L",
                     medical_requirements=["MER", "Condition-specific report"]),
        MedicalCheck(id="md-7", plan_name=P_TERM_2, age_limit="46-55",
                     suc_limit="Any",
                     medical_requirements=["Full medicals", "TMT", "Specialist consult"]),

        # SecureLife Elite
        MedicalCheck(id="md-8", plan_name=P_TERM_3, age_limit="18-35",
                     suc_limit="Any",
                     medical_requirements=["MER", "Condition-specific report"]),
        MedicalCheck(id="md-9", plan_name=P_TERM_3, age_limit="56-65",
                     suc_limit="Any",
                     medical_requirements=["Full medicals", "TMT", "2D Echo", "Specialist consult"]),

        # i select 360
        MedicalCheck(id="md-10", plan_name=P_ULIP_1, age_limit="18-45",
                     suc_limit="Up to ₹50 L",
                     medical_requirements=["MER", "Condition-specific report"]),
        MedicalCheck(id="md-11", plan_name=P_ULIP_1, age_limit="46-65",
                     suc_limit="Any",
                     medical_requirements=["Full medicals", "TMT", "2D Echo", "Specialist consult"]),

        # Wealth Plus ULIP
        MedicalCheck(id="md-12", plan_name=P_ULIP_2, age_limit="18-45",
                     suc_limit="Above ₹50 L",
                     medical_requirements=["Full medicals", "Lipid", "Condition-specific report"]),

        # Endowment
        MedicalCheck(id="md-13", plan_name=P_END_2, age_limit="18-45",
                     suc_limit="Any",
                     medical_requirements=["MER", "Condition-specific report"]),
        MedicalCheck(id="md-14", plan_name=P_END_2, age_limit="46-65",
                     suc_limit="Any",
                     medical_requirements=["Full medicals", "TMT", "Specialist consult"]),

        # Pension
        MedicalCheck(id="md-15", plan_name=P_PEN_1, age_limit="40-55",
                     suc_limit="Any",
                     medical_requirements=["MER", "ECG", "FBS", "Condition-specific report"]),
        MedicalCheck(id="md-16", plan_name=P_PEN_1, age_limit="56-65",
                     suc_limit="Any",
                     medical_requirements=["Full medicals", "TMT", "2D Echo", "Specialist consult"]),

        # Whole Life
        MedicalCheck(id="md-17", plan_name=P_WL_1, age_limit="18-45",
                     suc_limit="Any",
                     medical_requirements=["Full medicals", "ECG", "Condition-specific report"]),

        # Child Plan
        MedicalCheck(id="md-18", plan_name=P_CP_1, age_limit="25-40",
                     suc_limit="Up to ₹50 L",
                     medical_requirements=["MER", "Condition-specific report"]),
        MedicalCheck(id="md-19", plan_name=P_CP_1, age_limit="41-55",
                     suc_limit="Any",
                     medical_requirements=["Full medicals", "TMT", "Condition-specific report"]),
    ]

    # ============================================================
    # NON-MEDICAL — Plan × Age (no SUC dimension)
    # ============================================================
    non_medical = [
        # iProtect Smart
        NonMedicalCheck(id="nm-1", plan_name=P_TERM_1, age_limit="18-35",
                        vmer_requirements=["Not required"]),
        NonMedicalCheck(id="nm-2", plan_name=P_TERM_1, age_limit="36-45",
                        vmer_requirements=["Conditional (SA > ₹50 L)"]),
        NonMedicalCheck(id="nm-3", plan_name=P_TERM_1, age_limit="46-50",
                        vmer_requirements=["VMER required"]),
        NonMedicalCheck(id="nm-4", plan_name=P_TERM_1, age_limit="51-55",
                        vmer_requirements=["VMER required", "Tele-MER follow-up"]),
        NonMedicalCheck(id="nm-5", plan_name=P_TERM_1, age_limit="56-65",
                        vmer_requirements=["Full medicals", "VMER not accepted"]),

        # Click 2 Protect Super
        NonMedicalCheck(id="nm-6", plan_name=P_TERM_2, age_limit="18-35",
                        vmer_requirements=["Not required"]),
        NonMedicalCheck(id="nm-7", plan_name=P_TERM_2, age_limit="46-55",
                        vmer_requirements=["VMER required"]),

        # SecureLife Elite
        NonMedicalCheck(id="nm-8", plan_name=P_TERM_3, age_limit="18-35",
                        vmer_requirements=["Not required"]),
        NonMedicalCheck(id="nm-9", plan_name=P_TERM_3, age_limit="56-65",
                        vmer_requirements=["Full medicals", "VMER not accepted"]),

        # i select 360
        NonMedicalCheck(id="nm-10", plan_name=P_ULIP_1, age_limit="18-45",
                        vmer_requirements=["Not required"]),
        NonMedicalCheck(id="nm-11", plan_name=P_ULIP_1, age_limit="46-65",
                        vmer_requirements=["VMER required"]),

        # Wealth Plus
        NonMedicalCheck(id="nm-12", plan_name=P_ULIP_2, age_limit="18-45",
                        vmer_requirements=["Not required"]),

        # Endowment plans
        NonMedicalCheck(id="nm-13", plan_name=P_END_1, age_limit="18-45",
                        vmer_requirements=["Not required"]),
        NonMedicalCheck(id="nm-14", plan_name=P_END_2, age_limit="18-45",
                        vmer_requirements=["Not required"]),
        NonMedicalCheck(id="nm-15", plan_name=P_END_2, age_limit="46-65",
                        vmer_requirements=["VMER required"]),

        # Pension
        NonMedicalCheck(id="nm-16", plan_name=P_PEN_1, age_limit="40-55",
                        vmer_requirements=["Not required"]),
        NonMedicalCheck(id="nm-17", plan_name=P_PEN_1, age_limit="56-65",
                        vmer_requirements=["VMER required"]),

        # Whole Life
        NonMedicalCheck(id="nm-18", plan_name=P_WL_1, age_limit="18-45",
                        vmer_requirements=["VMER required"]),

        # Money Back
        NonMedicalCheck(id="nm-19", plan_name=P_MB_1, age_limit="18-45",
                        vmer_requirements=["Not required"]),

        # Child Plan
        NonMedicalCheck(id="nm-20", plan_name=P_CP_1, age_limit="25-40",
                        vmer_requirements=["Not required"]),
        NonMedicalCheck(id="nm-21", plan_name=P_CP_1, age_limit="41-55",
                        vmer_requirements=["VMER required"]),
    ]

    return UnderwritingChecksBundle(
        financial=financial,
        medical_non_disclosure=medical_non_disclosure,
        medical_disclosure=medical_disclosure,
        non_medical=non_medical,
    )


def library() -> list[LibraryDocument]:
    now = _now()
    return [
        LibraryDocument(
            id="lib1", title="Underwriting Manual v2.4",
            description="Risk classification, financial underwriting bands, medical requirement matrix and substandard-life loadings.",
            category=LibraryCategory.underwriting,
            pages=42, size_kb=2,
            updated_at=now - timedelta(days=3),
            download_url="/static/pdfs/underwriting-manual.pdf",
        ),
        LibraryDocument(
            id="lib2", title="Financial Underwriting Guide 2026",
            description="Income multiples by occupation, document matrix per sum-assured band, and NRI-specific rules.",
            category=LibraryCategory.underwriting,
            pages=18, size_kb=2,
            updated_at=now - timedelta(days=10),
            download_url="/static/pdfs/financial-uw-guide.pdf",
        ),
        LibraryDocument(
            id="lib3", title="Medical Requirements Matrix",
            description="Age × sum-assured × disclosure matrix for tele-UW, VMER and full medicals; empanelled centre list.",
            category=LibraryCategory.underwriting,
            pages=24, size_kb=2,
            updated_at=now - timedelta(days=21),
            download_url="/static/pdfs/medical-requirements.pdf",
        ),
        LibraryDocument(
            id="lib4", title="Term Product Handbook — Q2 2026",
            description="Side-by-side comparison of SecureLife Elite, iProtect Smart and Click 2 Protect Super.",
            category=LibraryCategory.products,
            pages=36, size_kb=2,
            updated_at=now - timedelta(days=7),
            download_url="/static/pdfs/product-handbook.pdf",
        ),
        LibraryDocument(
            id="lib5", title="IRDAI Compliance Checklist",
            description="Pre-sale disclosures, suitability assessment, free-look period and AML obligations.",
            category=LibraryCategory.compliance,
            pages=12, size_kb=2,
            updated_at=now - timedelta(days=45),
            download_url="/static/pdfs/compliance-checklist.pdf",
        ),
    ]
