"""In-memory data store. Replace this class to switch to a real DB."""

import asyncio
import uuid
from datetime import datetime, timezone

from app.config import get_settings
from app.models import (
    ChatMessage,
    ChatSession,
    EarningsSummary,
    Incentive,
    IncentiveTag,
    InventoryRow,
    InventoryStat,
    Lead,
    LeadCreate,
    LeadStage,
    LeadUpdate,
    LibraryCategory,
    LibraryDocument,
    MessageAuthor,
    SessionSummary,
    UnderwritingChecksBundle,
    UnderwritingStage,
    UserProfile,
)
from app.services import seed


class Store:
    """Single in-memory store."""

    def __init__(self) -> None:
        self._settings = get_settings()
        self._lock = asyncio.Lock()

        self._sessions: dict[str, ChatSession] = {s.id: s for s in seed.sessions()}
        self._inventory: list[InventoryRow] = seed.inventory()
        self._inventory_stats: list[InventoryStat] = seed.inventory_stats()
        self._earnings: EarningsSummary = seed.earnings()
        self._incentives: list[Incentive] = seed.incentives()
        self._leads: dict[str, Lead] = {l.id: l for l in seed.leads()}
        self._library: dict[str, LibraryDocument] = {d.id: d for d in seed.library()}
        self._underwriting_checks: UnderwritingChecksBundle = seed.underwriting_checks()
        self._me: UserProfile = seed.me()

    # ---------------- Sessions / chat ----------------

    async def list_sessions(self) -> list[SessionSummary]:
        async with self._lock:
            ordered = sorted(
                self._sessions.values(),
                key=lambda s: s.updated_at,
                reverse=True,
            )[: self._settings.max_sessions]
            return [self._to_summary(s) for s in ordered]

    async def get_session(self, session_id: str) -> ChatSession | None:
        async with self._lock:
            return self._sessions.get(session_id)

    async def create_session(self, title: str | None = None) -> ChatSession:
        async with self._lock:
            now = datetime.now(timezone.utc)
            session = ChatSession(
                id=str(uuid.uuid4()),
                title=title or "New conversation",
                created_at=now, updated_at=now,
                messages=[
                    ChatMessage(
                        id=str(uuid.uuid4()),
                        author=MessageAuthor.bot,
                        timestamp=now,
                        content=("👋 New session started. Share the prospect's profile "
                                 "and I'll match products and pull underwriting requirements."),
                    )
                ],
            )
            self._sessions[session.id] = session
            self._enforce_cap()
            return session

    async def append_message(
        self, session_id: str, message: ChatMessage
    ) -> ChatSession | None:
        async with self._lock:
            session = self._sessions.get(session_id)
            if session is None:
                return None
            session.messages.append(message)
            session.updated_at = datetime.now(timezone.utc)
            if (
                session.title == "New conversation"
                and message.author == MessageAuthor.user
            ):
                session.title = self._title_from(message.content)
            return session

    async def delete_session(self, session_id: str) -> bool:
        async with self._lock:
            return self._sessions.pop(session_id, None) is not None

    # ---------------- Inventory (FLS pipeline) ----------------

    async def list_inventory(
        self,
        stage: UnderwritingStage | None = None,
        q: str | None = None,
    ) -> list[InventoryRow]:
        async with self._lock:
            rows = list(self._inventory)
        if stage is not None:
            rows = [r for r in rows if r.underwriting_stage == stage]
        if q:
            needle = q.lower()
            rows = [r for r in rows if needle in r.fls_id.lower()]
        return rows

    async def inventory_stats(self) -> list[InventoryStat]:
        async with self._lock:
            return list(self._inventory_stats)

    # ---------------- Incentives ----------------

    async def earnings_summary(self) -> EarningsSummary:
        async with self._lock:
            return self._earnings

    async def list_incentives(
        self, tag: IncentiveTag | None = None
    ) -> list[Incentive]:
        async with self._lock:
            rows = list(self._incentives)
        if tag is not None:
            rows = [i for i in rows if i.tag == tag]
        return rows

    # ---------------- Leads ----------------

    async def list_leads(self, stage: LeadStage | None = None) -> list[Lead]:
        async with self._lock:
            rows = list(self._leads.values())
        if stage is not None:
            rows = [l for l in rows if l.stage == stage]
        return rows

    async def lead_counts(self) -> dict[str, int]:
        async with self._lock:
            counts: dict[str, int] = {"All": len(self._leads)}
            for stage in LeadStage:
                counts[stage.value] = sum(
                    1 for l in self._leads.values() if l.stage == stage
                )
            return counts

    async def create_lead(self, data: LeadCreate) -> Lead:
        async with self._lock:
            lead = Lead(
                id=str(uuid.uuid4()),
                initials=self._initials_from(data.name),
                name=data.name, city=data.city,
                interest=data.interest, potential=data.potential,
                stage=data.stage, next_action=data.next_action, hot=data.hot,
            )
            self._leads[lead.id] = lead
            return lead

    async def update_lead(self, lead_id: str, patch: LeadUpdate) -> Lead | None:
        async with self._lock:
            lead = self._leads.get(lead_id)
            if lead is None:
                return None
            data = patch.model_dump(exclude_unset=True)
            updated = lead.model_copy(update=data)
            self._leads[lead_id] = updated
            return updated

    async def delete_lead(self, lead_id: str) -> bool:
        async with self._lock:
            return self._leads.pop(lead_id, None) is not None

    # ---------------- Library ----------------

    async def list_library(
        self,
        category: LibraryCategory | None = None,
        q: str | None = None,
    ) -> list[LibraryDocument]:
        async with self._lock:
            rows = list(self._library.values())
        if category is not None:
            rows = [d for d in rows if d.category == category]
        if q:
            needle = q.lower()
            rows = [
                d for d in rows
                if needle in d.title.lower() or needle in d.description.lower()
            ]
        # Newest first
        return sorted(rows, key=lambda d: d.updated_at, reverse=True)

    async def get_library(self, document_id: str) -> LibraryDocument | None:
        async with self._lock:
            return self._library.get(document_id)

    # ---------------- Underwriting Checks ----------------

    async def underwriting_checks(self) -> UnderwritingChecksBundle:
        """Backward-compat flat payload."""
        async with self._lock:
            return self._underwriting_checks

    # ---- Filtered + grouped responses (one object per plan+filter combo) ----

    async def financial_response(self, plan: str, occupation: str):
        """
        ★ Returns a single FinancialResponse object grouping every matching
        SUC band under one (plan, occupation) header — matches the JSON shape:

          { planName, requestType="Financial", occupationLifeType,
            financialSuc: [{sucLimit, financialRequirement, documentList}, ...] }
        """
        from app.models import FinancialResponse, FinancialSucEntry
        async with self._lock:
            rows = [
                r for r in self._underwriting_checks.financial
                if r.plan_name == plan and r.occupation_life_type == occupation
            ]
        return FinancialResponse(
            plan_name=plan,
            occupation_life_type=occupation,
            financial_suc=[
                FinancialSucEntry(
                    suc_limit=r.suc_limit,
                    financial_requirement=r.financial_requirement,
                    document_list=r.document_list,
                ) for r in rows
            ],
        )

    async def medical_response(self, kind: str, plan: str, age_limit: str):
        """★ Returns grouped MedicalResponse (kind = 'non-disclosure' | 'disclosure')."""
        from app.models import MedicalResponse, MedicalSucEntry
        async with self._lock:
            source = (
                self._underwriting_checks.medical_non_disclosure
                if kind == "non-disclosure"
                else self._underwriting_checks.medical_disclosure
            )
            rows = [
                r for r in source
                if r.plan_name == plan and r.age_limit == age_limit
            ]
        request_type = (
            "Medical Non-Disclosure" if kind == "non-disclosure"
            else "Medical Disclosure"
        )
        return MedicalResponse(
            plan_name=plan,
            request_type=request_type,
            age_limit=age_limit,
            medical_suc=[
                MedicalSucEntry(
                    suc_limit=r.suc_limit,
                    medical_requirements=r.medical_requirements,
                ) for r in rows
            ],
        )

    async def non_medical_response(self, plan: str, age_limit: str):
        """★ Returns grouped NonMedicalResponse (no SUC step)."""
        from app.models import NonMedicalResponse
        async with self._lock:
            rows = [
                r for r in self._underwriting_checks.non_medical
                if r.plan_name == plan and r.age_limit == age_limit
            ]
        # Flatten the vmer requirements from all matching rows (usually one)
        vmer: list[str] = []
        seen: set[str] = set()
        for r in rows:
            for req in r.vmer_requirements:
                if req not in seen:
                    seen.add(req); vmer.append(req)
        return NonMedicalResponse(
            plan_name=plan,
            age_limit=age_limit,
            vmer_requirements=vmer,
        )

    async def underwriting_options(self):
        """
        ★ Cascading dropdown data. The frontend uses these maps so picking
        a plan automatically narrows the next dropdown to only what's valid:

          plans, financial_occupations: {plan → [occupations]},
          medical_age_limits:           {plan → [age_limits]},
          non_medical_age_limits:       {plan → [age_limits]}
        """
        from app.models import UnderwritingOptions
        async with self._lock:
            financial = list(self._underwriting_checks.financial)
            med_nd    = list(self._underwriting_checks.medical_non_disclosure)
            med_d     = list(self._underwriting_checks.medical_disclosure)
            non_med   = list(self._underwriting_checks.non_medical)

        # All plan names — insertion-order preserving union
        plans: list[str] = []
        seen_plans: set[str] = set()
        for source in (financial, med_nd, med_d, non_med):
            for r in source:
                if r.plan_name not in seen_plans:
                    seen_plans.add(r.plan_name)
                    plans.append(r.plan_name)

        # plan → occupations (Financial)
        fin_occ: dict[str, list[str]] = {}
        for r in financial:
            fin_occ.setdefault(r.plan_name, [])
            if r.occupation_life_type not in fin_occ[r.plan_name]:
                fin_occ[r.plan_name].append(r.occupation_life_type)

        # plan → age limits (union of disclosure + non-disclosure)
        med_ages: dict[str, list[str]] = {}
        for r in med_nd + med_d:
            med_ages.setdefault(r.plan_name, [])
            if r.age_limit not in med_ages[r.plan_name]:
                med_ages[r.plan_name].append(r.age_limit)
        # Sort each plan's age list by leading digit
        def _age_key(s: str) -> int:
            d = ""
            for ch in s:
                if ch.isdigit(): d += ch
                else: break
            return int(d) if d else 999
        for k in med_ages: med_ages[k].sort(key=_age_key)

        # plan → age limits (Non-Medical)
        nm_ages: dict[str, list[str]] = {}
        for r in non_med:
            nm_ages.setdefault(r.plan_name, [])
            if r.age_limit not in nm_ages[r.plan_name]:
                nm_ages[r.plan_name].append(r.age_limit)
        for k in nm_ages: nm_ages[k].sort(key=_age_key)

        return UnderwritingOptions(
            plans=plans,
            financial_occupations=fin_occ,
            medical_age_limits=med_ages,
            non_medical_age_limits=nm_ages,
        )

    # Backward-compat alias
    async def financial_options(self):
        return await self.underwriting_options()

    # ---------------- Me ----------------

    async def me(self) -> UserProfile:
        return self._me

    # ---------------- Helpers ----------------

    def _enforce_cap(self) -> None:
        cap = self._settings.max_sessions
        if len(self._sessions) <= cap:
            return
        ordered = sorted(
            self._sessions.values(), key=lambda s: s.updated_at, reverse=True
        )
        keep_ids = {s.id for s in ordered[:cap]}
        for sid in list(self._sessions.keys()):
            if sid not in keep_ids:
                self._sessions.pop(sid, None)

    @staticmethod
    def _to_summary(session: ChatSession) -> SessionSummary:
        last = next(
            (m for m in reversed(session.messages) if (m.content or "").strip()),
            None,
        )
        preview = "No messages yet"
        if last is not None:
            preview = " ".join(last.content.split())
            preview = preview if len(preview) <= 70 else preview[:67] + "…"
        return SessionSummary(
            id=session.id, title=session.title,
            created_at=session.created_at, updated_at=session.updated_at,
            message_count=len(session.messages), last_message_preview=preview,
        )

    @staticmethod
    def _title_from(content: str) -> str:
        clean = " ".join(content.split())
        return clean if len(clean) <= 48 else clean[:45].rstrip() + "…"

    @staticmethod
    def _initials_from(name: str) -> str:
        parts = [p for p in name.split() if p]
        if not parts: return "?"
        if len(parts) == 1: return parts[0][:2].upper()
        return (parts[0][0] + parts[-1][0]).upper()


_store: Store | None = None


def get_store() -> Store:
    global _store
    if _store is None:
        _store = Store()
    return _store
