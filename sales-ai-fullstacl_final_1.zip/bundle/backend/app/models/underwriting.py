"""
Underwriting Checks — data shapes for the form-driven UI.

Internal storage is kept as flat rows (each row = one specific combination)
because that's easy to filter. The API layer groups them into the nested
response shape the frontend consumes — matching the JSON contract:

  {
    "planName": "i select 360",
    "requestType": "Financial",
    "occupationLifeType": "Salaried",
    "financialSuc": [
      {
        "sucLimit": "0 - 1 cr",
        "financialRequirement": "...",
        "documentList": [...]
      }
    ]
  }
"""

from .chat import Base


# ============================================================
# Internal flat-row storage models (used by seed.py + store)
# ============================================================

class FinancialCheck(Base):
    """Internal row — one (plan, occupation, SUC) combination."""
    id: str
    plan_name: str                    # ★ now free-form (e.g. "i select 360")
    occupation_life_type: str
    suc_limit: str                    # ★ renamed from financial_suc
    financial_requirement: str
    document_list: list[str]          # ★ renamed from documents_list


class MedicalCheck(Base):
    """Internal row — one (plan, age, SUC) combination."""
    id: str
    plan_name: str
    age_limit: str
    suc_limit: str                    # ★ renamed from medical_suc
    medical_requirements: list[str]


class NonMedicalCheck(Base):
    """Internal row — one (plan, age) combination."""
    id: str
    plan_name: str
    age_limit: str
    vmer_requirements: list[str]


# ============================================================
# ★ NEW — Nested API response shapes (match the user's JSON)
# ============================================================

class FinancialSucEntry(Base):
    """One row of the Financial SUC array."""
    suc_limit: str
    financial_requirement: str
    document_list: list[str]


class FinancialResponse(Base):
    plan_name: str
    request_type: str = "Financial"
    occupation_life_type: str
    financial_suc: list[FinancialSucEntry]


class MedicalSucEntry(Base):
    """One row of the Medical SUC array."""
    suc_limit: str
    medical_requirements: list[str]


class MedicalResponse(Base):
    plan_name: str
    request_type: str                 # "Medical Non-Disclosure" or "Medical Disclosure"
    age_limit: str
    medical_suc: list[MedicalSucEntry]


class NonMedicalResponse(Base):
    plan_name: str
    request_type: str = "Non-Medical"
    age_limit: str
    vmer_requirements: list[str]


# ============================================================
# Options endpoint — cascading dropdown payload
# ============================================================

class UnderwritingOptions(Base):
    """
    ★ Cascading dropdown data for ALL underwriting workflows.

    plans                  — all distinct plan names across the dataset
    financial_occupations  — {plan_name → [occupations]} (Financial tab)
    medical_age_limits     — {plan_name → [age_limits]} (Medical tabs)
    non_medical_age_limits — {plan_name → [age_limits]} (Non-Medical tab)

    The UI uses these maps so picking a plan automatically narrows the
    second dropdown to only the valid options for that plan.
    """
    plans: list[str]
    financial_occupations: dict[str, list[str]]
    medical_age_limits: dict[str, list[str]]
    non_medical_age_limits: dict[str, list[str]]


# Backward-compat aliases (kept for any external code that imports old names)
FinancialOptions = UnderwritingOptions


# ============================================================
# Combined bundle (legacy endpoint)
# ============================================================

class UnderwritingChecksBundle(Base):
    """Flat backward-compat payload — every row of every table."""
    financial: list[FinancialCheck]
    medical_non_disclosure: list[MedicalCheck]
    medical_disclosure: list[MedicalCheck]
    non_medical: list[NonMedicalCheck]
