import {
  ChangeDetectionStrategy,
  Component,
  computed,
  inject,
  signal,
} from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { firstValueFrom } from 'rxjs';

import {
  ApiService,
  FinancialResponse,
  MedicalResponse,
  NonMedicalResponse,
  UnderwritingOptions,
} from '../../core/services/api.service';

type SectionId =
  | 'financial' | 'medicalNonDisclosure' | 'medicalDisclosure' | 'nonMedical';

@Component({
  selector: 'app-underwriting',
  standalone: true,
  imports: [CommonModule, FormsModule],
  changeDetection: ChangeDetectionStrategy.OnPush,
  templateUrl: './underwriting.component.html',
})
export class UnderwritingComponent {
  private readonly api = inject(ApiService);

  // ===== Shared options + tab switcher =====
  protected readonly options = signal<UnderwritingOptions | null>(null);
  protected readonly optionsError = signal<string | null>(null);
  protected readonly activeSection = signal<SectionId>('financial');

  protected readonly sectionMeta = [
    { id: 'financial',            label: 'Financial',                short: 'Financial' },
    { id: 'medicalNonDisclosure', label: 'Medical · Non-Disclosure', short: 'Non-Disc.' },
    { id: 'medicalDisclosure',    label: 'Medical · Disclosure',     short: 'Disclosure' },
    { id: 'nonMedical',           label: 'Non-Medical',              short: 'Non-Med.' },
  ] as const;

  // ===========================================================
  // ★ FINANCIAL — Plan + Occupation (cascading) → SUC → docs
  // ===========================================================
  protected readonly finPlan = signal<string>('');
  protected readonly finOccupation = signal<string>('');
  protected readonly finSuc = signal<string>('');
  protected readonly finResp = signal<FinancialResponse | null>(null);
  protected readonly finLoading = signal(false);
  protected readonly finError = signal<string | null>(null);

  /** ★ Cascading: occupations available for the currently-selected plan. */
  protected readonly finAvailableOccupations = computed<string[]>(() => {
    const plan = this.finPlan();
    if (!plan) return [];
    return this.options()?.financialOccupations?.[plan] ?? [];
  });

  /** SUC dropdown options come from the loaded response. */
  protected readonly finSucs = computed<string[]>(() =>
    (this.finResp()?.financialSuc ?? []).map((e) => e.sucLimit)
  );

  /** The matching SUC entry — drives the requirement + document list. */
  protected readonly finSelectedEntry = computed(() =>
    this.finResp()?.financialSuc.find((e) => e.sucLimit === this.finSuc()) ?? null
  );

  protected readonly finStep1Complete = computed(
    () => this.finPlan() !== '' && this.finOccupation() !== ''
  );
  protected readonly finStep2Complete = computed(() => this.finSuc() !== '');

  // ===========================================================
  // ★ MEDICAL NON-DISCLOSURE — Plan + Age → SUC → reqs
  // ===========================================================
  protected readonly mndPlan = signal<string>('');
  protected readonly mndAgeLimit = signal<string>('');
  protected readonly mndSuc = signal<string>('');
  protected readonly mndResp = signal<MedicalResponse | null>(null);
  protected readonly mndLoading = signal(false);
  protected readonly mndError = signal<string | null>(null);

  protected readonly mndAvailableAges = computed<string[]>(() => {
    const plan = this.mndPlan();
    if (!plan) return [];
    return this.options()?.medicalAgeLimits?.[plan] ?? [];
  });
  protected readonly mndSucs = computed<string[]>(() =>
    (this.mndResp()?.medicalSuc ?? []).map((e) => e.sucLimit)
  );
  protected readonly mndSelectedEntry = computed(() =>
    this.mndResp()?.medicalSuc.find((e) => e.sucLimit === this.mndSuc()) ?? null
  );
  protected readonly mndStep1Complete = computed(
    () => this.mndPlan() !== '' && this.mndAgeLimit() !== ''
  );
  protected readonly mndStep2Complete = computed(() => this.mndSuc() !== '');

  // ===========================================================
  // ★ MEDICAL DISCLOSURE — same shape, different data
  // ===========================================================
  protected readonly mdPlan = signal<string>('');
  protected readonly mdAgeLimit = signal<string>('');
  protected readonly mdSuc = signal<string>('');
  protected readonly mdResp = signal<MedicalResponse | null>(null);
  protected readonly mdLoading = signal(false);
  protected readonly mdError = signal<string | null>(null);

  protected readonly mdAvailableAges = computed<string[]>(() => {
    const plan = this.mdPlan();
    if (!plan) return [];
    return this.options()?.medicalAgeLimits?.[plan] ?? [];
  });
  protected readonly mdSucs = computed<string[]>(() =>
    (this.mdResp()?.medicalSuc ?? []).map((e) => e.sucLimit)
  );
  protected readonly mdSelectedEntry = computed(() =>
    this.mdResp()?.medicalSuc.find((e) => e.sucLimit === this.mdSuc()) ?? null
  );
  protected readonly mdStep1Complete = computed(
    () => this.mdPlan() !== '' && this.mdAgeLimit() !== ''
  );
  protected readonly mdStep2Complete = computed(() => this.mdSuc() !== '');

  // ===========================================================
  // ★ NON-MEDICAL — Plan + Age → VMER card (no SUC step)
  // ===========================================================
  protected readonly nmPlan = signal<string>('');
  protected readonly nmAgeLimit = signal<string>('');
  protected readonly nmResp = signal<NonMedicalResponse | null>(null);
  protected readonly nmLoading = signal(false);
  protected readonly nmError = signal<string | null>(null);

  protected readonly nmAvailableAges = computed<string[]>(() => {
    const plan = this.nmPlan();
    if (!plan) return [];
    return this.options()?.nonMedicalAgeLimits?.[plan] ?? [];
  });
  protected readonly nmStep1Complete = computed(
    () => this.nmPlan() !== '' && this.nmAgeLimit() !== ''
  );

  // ===========================================================
  // Init
  // ===========================================================
  constructor() { void this.loadOptions(); }

  private async loadOptions(): Promise<void> {
    try {
      this.options.set(await firstValueFrom(this.api.underwritingOptions()));
    } catch (err) {
      this.optionsError.set(err instanceof Error ? err.message : 'Failed to load options');
    }
  }

  // ===========================================================
  // FINANCIAL handlers
  // ===========================================================
  protected onFinPlan(v: string): void {
    this.finPlan.set(v);
    // ★ Cascading reset: occupation cleared because the next list changes
    this.finOccupation.set(''); this.finSuc.set('');
    this.finResp.set(null); this.finError.set(null);
  }
  protected async onFinOccupation(v: string): Promise<void> {
    this.finOccupation.set(v);
    this.finSuc.set(''); this.finResp.set(null); this.finError.set(null);
    if (!this.finPlan() || !v) return;
    this.finLoading.set(true);
    try {
      this.finResp.set(await firstValueFrom(this.api.getFinancial(this.finPlan(), v)));
    } catch (err) {
      this.finError.set(err instanceof Error ? err.message : 'Fetch failed');
    } finally { this.finLoading.set(false); }
  }
  protected onFinSuc(v: string): void { this.finSuc.set(v); }
  protected resetFin(): void {
    this.finPlan.set(''); this.finOccupation.set(''); this.finSuc.set('');
    this.finResp.set(null); this.finError.set(null);
  }

  // ===========================================================
  // MEDICAL NON-DISCLOSURE handlers
  // ===========================================================
  protected onMndPlan(v: string): void {
    this.mndPlan.set(v);
    this.mndAgeLimit.set(''); this.mndSuc.set('');
    this.mndResp.set(null); this.mndError.set(null);
  }
  protected async onMndAge(v: string): Promise<void> {
    this.mndAgeLimit.set(v);
    this.mndSuc.set(''); this.mndResp.set(null); this.mndError.set(null);
    if (!this.mndPlan() || !v) return;
    this.mndLoading.set(true);
    try {
      this.mndResp.set(await firstValueFrom(
        this.api.getMedicalNonDisclosure(this.mndPlan(), v)
      ));
    } catch (err) {
      this.mndError.set(err instanceof Error ? err.message : 'Fetch failed');
    } finally { this.mndLoading.set(false); }
  }
  protected onMndSuc(v: string): void { this.mndSuc.set(v); }
  protected resetMnd(): void {
    this.mndPlan.set(''); this.mndAgeLimit.set(''); this.mndSuc.set('');
    this.mndResp.set(null); this.mndError.set(null);
  }

  // ===========================================================
  // MEDICAL DISCLOSURE handlers
  // ===========================================================
  protected onMdPlan(v: string): void {
    this.mdPlan.set(v);
    this.mdAgeLimit.set(''); this.mdSuc.set('');
    this.mdResp.set(null); this.mdError.set(null);
  }
  protected async onMdAge(v: string): Promise<void> {
    this.mdAgeLimit.set(v);
    this.mdSuc.set(''); this.mdResp.set(null); this.mdError.set(null);
    if (!this.mdPlan() || !v) return;
    this.mdLoading.set(true);
    try {
      this.mdResp.set(await firstValueFrom(
        this.api.getMedicalDisclosure(this.mdPlan(), v)
      ));
    } catch (err) {
      this.mdError.set(err instanceof Error ? err.message : 'Fetch failed');
    } finally { this.mdLoading.set(false); }
  }
  protected onMdSuc(v: string): void { this.mdSuc.set(v); }
  protected resetMd(): void {
    this.mdPlan.set(''); this.mdAgeLimit.set(''); this.mdSuc.set('');
    this.mdResp.set(null); this.mdError.set(null);
  }

  // ===========================================================
  // NON-MEDICAL handlers
  // ===========================================================
  protected onNmPlan(v: string): void {
    this.nmPlan.set(v);
    this.nmAgeLimit.set('');
    this.nmResp.set(null); this.nmError.set(null);
  }
  protected async onNmAge(v: string): Promise<void> {
    this.nmAgeLimit.set(v);
    this.nmResp.set(null); this.nmError.set(null);
    if (!this.nmPlan() || !v) return;
    this.nmLoading.set(true);
    try {
      this.nmResp.set(await firstValueFrom(
        this.api.getNonMedical(this.nmPlan(), v)
      ));
    } catch (err) {
      this.nmError.set(err instanceof Error ? err.message : 'Fetch failed');
    } finally { this.nmLoading.set(false); }
  }
  protected resetNm(): void {
    this.nmPlan.set(''); this.nmAgeLimit.set('');
    this.nmResp.set(null); this.nmError.set(null);
  }
}
