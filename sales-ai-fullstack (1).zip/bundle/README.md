# Sales AI Assistant — Full Stack

Angular 18 + Tailwind v4 frontend paired with a FastAPI + Pydantic 2 backend.

```
.
├── frontend/   Angular 18 + Tailwind v4
└── backend/    FastAPI + Pydantic v2
```

## Run both

Two terminals.

**Terminal 1 — backend:**
```bash
cd backend
python -m venv .venv && source .venv/bin/activate     # Windows: .venv\Scripts\activate
pip install -r requirements.txt
uvicorn app.main:app --reload --port 8000
```

**Terminal 2 — frontend:**
```bash
cd frontend
npm install
npm start                                              # opens http://localhost:4200
```

## Screens

Six menu items in the left drawer:

1. **Product Recommendation & Comparison** — chat with 5 recent sessions
2. **Sales Inventory** — FLS pipeline (FLS ID · NOP · PFR · Stage · Submission · Issuance · Total NOP)
3. **Incentives** — earnings hero + contests
4. **Leads** — pipeline by stage
5. **Underwriting Checks** — Financial / Medical (Non-Disclosure & Disclosure) / Non-Medical reference tables
6. **Library** — PDF knowledge base (5 sample PDFs served from FastAPI's `/static/pdfs/`)

## Typography

A deliberate, professional small-text system:

- **Inter** for body & UI (best-in-class small-size readability)
- **Instrument Serif** for occasional display moments (page titles, hero figures)
- **JetBrains Mono** for FLS IDs and tabular numbers
- 13 px base font size, tabular numerals throughout, lighter heading weights
