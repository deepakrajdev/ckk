import { ChangeDetectionStrategy, Component, computed, inject, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { firstValueFrom } from 'rxjs';

import {
  ApiService,
  InventoryRow,
  InventoryStat,
  UnderwritingStage,
} from '../../core/services/api.service';

@Component({
  selector: 'app-inventory',
  standalone: true,
  imports: [CommonModule, FormsModule],
  changeDetection: ChangeDetectionStrategy.OnPush,
  templateUrl: './inventory.component.html',
})
export class InventoryComponent {
  private readonly api = inject(ApiService);

  protected readonly rows = signal<InventoryRow[]>([]);
  protected readonly stats = signal<InventoryStat[]>([]);
  protected readonly loading = signal<boolean>(true);
  protected readonly error = signal<string | null>(null);

  protected readonly stageFilters: ('All' | UnderwritingStage)[] = [
    'All', 'Submitted', 'Medical', 'In Review', 'Approved', 'Issued', 'Declined',
  ];
  protected readonly activeStage = signal<'All' | UnderwritingStage>('All');

  protected query = '';
  protected readonly querySignal = signal('');

  protected readonly visible = computed<InventoryRow[]>(() => {
    const stage = this.activeStage();
    const q = this.querySignal().trim().toLowerCase();
    return this.rows().filter(
      (r) =>
        (stage === 'All' || r.underwritingStage === stage) &&
        (!q || r.flsId.toLowerCase().includes(q))
    );
  });

  constructor() {
    void this.load();
  }

  protected onQueryChange(v: string): void {
    this.query = v;
    this.querySignal.set(v);
  }

  protected stageStyle(stage: UnderwritingStage): string {
    const map: Record<UnderwritingStage, string> = {
      'Submitted': 'bg-ink-100 text-ink-700',
      'Medical':   'bg-warn-50 text-warn-600',
      'In Review': 'bg-brand-50 text-brand-700',
      'Approved':  'bg-success-50 text-success-600',
      'Issued':    'bg-success-500/15 text-success-600',
      'Declined':  'bg-danger-50 text-danger-600',
    };
    return map[stage];
  }

  protected retry(): void {
    void this.load();
  }

  private async load(): Promise<void> {
    this.loading.set(true);
    this.error.set(null);
    try {
      const [rows, stats] = await Promise.all([
        firstValueFrom(this.api.listInventory()),
        firstValueFrom(this.api.inventoryStats()),
      ]);
      this.rows.set(rows);
      this.stats.set(stats);
    } catch (err) {
      this.error.set(err instanceof Error ? err.message : 'Failed to load inventory');
    } finally {
      this.loading.set(false);
    }
  }
}
