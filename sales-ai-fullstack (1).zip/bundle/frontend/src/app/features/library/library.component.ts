import {
  ChangeDetectionStrategy,
  Component,
  computed,
  inject,
  signal,
} from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { firstValueFrom } from 'rxjs';

import {
  ApiService,
  LibraryCategory,
  LibraryDocument,
} from '../../core/services/api.service';

@Component({
  selector: 'app-library',
  standalone: true,
  imports: [CommonModule, FormsModule],
  changeDetection: ChangeDetectionStrategy.OnPush,
  templateUrl: './library.component.html',
})
export class LibraryComponent {
  private readonly api = inject(ApiService);

  protected readonly all = signal<LibraryDocument[]>([]);
  protected readonly loading = signal<boolean>(true);
  protected readonly error = signal<string | null>(null);

  protected readonly categories: ('All' | LibraryCategory)[] = [
    'All', 'Underwriting', 'Products', 'Compliance', 'Training', 'Tax & Regulations',
  ];
  protected readonly activeCategory = signal<'All' | LibraryCategory>('All');
  protected query = '';
  /** Bumped whenever the query input changes — drives the computed filter. */
  protected readonly querySignal = signal('');

  protected readonly visible = computed<LibraryDocument[]>(() => {
    const cat = this.activeCategory();
    const q = this.querySignal().trim().toLowerCase();
    return this.all().filter(
      (d) =>
        (cat === 'All' || d.category === cat) &&
        (!q ||
          d.title.toLowerCase().includes(q) ||
          d.description.toLowerCase().includes(q))
    );
  });

  constructor() {
    void this.load();
  }

  /** Open the PDF in a new browser tab. The backend serves at /static/pdfs/... */
  protected openDocument(d: LibraryDocument): void {
    const url = this.api.absoluteUrl(d.downloadUrl);
    window.open(url, '_blank', 'noopener');
  }

  protected onQueryChange(value: string): void {
    this.query = value;
    this.querySignal.set(value);
  }

  /** Category color tint for the card icon */
  protected colorFor(c: LibraryCategory): string {
    return ({
      Underwriting: 'bg-brand-100 text-brand-700',
      Products: 'bg-accent-100 text-accent-700',
      Compliance: 'bg-danger-50 text-danger-600',
      Training: 'bg-success-50 text-success-600',
      'Tax & Regulations': 'bg-warn-50 text-warn-600',
    } as const)[c];
  }

  protected retry(): void {
    void this.load();
  }

  private async load(): Promise<void> {
    this.loading.set(true);
    this.error.set(null);
    try {
      const docs = await firstValueFrom(this.api.listLibrary());
      this.all.set(docs);
    } catch (err) {
      this.error.set(err instanceof Error ? err.message : 'Failed to load library');
    } finally {
      this.loading.set(false);
    }
  }
}
