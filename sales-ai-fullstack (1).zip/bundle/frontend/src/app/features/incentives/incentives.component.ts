import { ChangeDetectionStrategy, Component } from '@angular/core';
import { CommonModule } from '@angular/common';

interface Incentive {
  id: string;
  title: string;
  reward: string;
  progress: number; // 0-100
  current: string;
  target: string;
  deadline: string;
  tag: 'Active' | 'Closing soon' | 'Stretch';
}

@Component({
  selector: 'app-incentives',
  standalone: true,
  imports: [CommonModule],
  changeDetection: ChangeDetectionStrategy.OnPush,
  templateUrl: './incentives.component.html',
})
export class IncentivesComponent {
  protected readonly incentives: Incentive[] = [
    {
      id: 'c1', title: 'Term Plan Champion',
      reward: '₹50,000',
      progress: 78, current: '23 policies', target: '30',
      deadline: 'Jun 30', tag: 'Closing soon',
    },
    {
      id: 'c2', title: 'ULIP Premium Push',
      reward: '₹40,000',
      progress: 52, current: '₹6.2 L premium', target: '₹12 L',
      deadline: 'Jul 31', tag: 'Active',
    },
    {
      id: 'c3', title: 'New Customer Drive',
      reward: 'Bali Trip',
      progress: 35, current: '14 new', target: '40 new',
      deadline: 'Aug 15', tag: 'Stretch',
    },
    {
      id: 'c4', title: 'Renewal Hero',
      reward: '₹25,000',
      progress: 92, current: '184 renewals', target: '200',
      deadline: 'Jun 30', tag: 'Closing soon',
    },
  ];
}
