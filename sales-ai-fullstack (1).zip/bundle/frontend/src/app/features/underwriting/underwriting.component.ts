import { ChangeDetectionStrategy, Component, inject, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { firstValueFrom } from 'rxjs';

import {
  ApiService,
  UnderwritingChecksBundle,
} from '../../core/services/api.service';

@Component({
  selector: 'app-underwriting',
  standalone: true,
  imports: [CommonModule],
  changeDetection: ChangeDetectionStrategy.OnPush,
  templateUrl: './underwriting.component.html',
})
export class UnderwritingComponent {
  private readonly api = inject(ApiService);

  protected readonly data = signal<UnderwritingChecksBundle | null>(null);
  protected readonly loading = signal<boolean>(true);
  protected readonly error = signal<string | null>(null);

  /** Drives the section switcher on mobile (so we don't show all 4 tables stacked). */
  protected readonly activeSection = signal<
    'financial' | 'medicalNonDisclosure' | 'medicalDisclosure' | 'nonMedical'
  >('financial');

  protected readonly sectionMeta = [
    { id: 'financial',            label: 'Financial',              short: 'Financial' },
    { id: 'medicalNonDisclosure', label: 'Medical · Non-Disclosure', short: 'Non-Disc.' },
    { id: 'medicalDisclosure',    label: 'Medical · Disclosure',   short: 'Disclosure' },
    { id: 'nonMedical',           label: 'Non-Medical',            short: 'Non-Med.' },
  ] as const;

  constructor() {
    void this.load();
  }

  private async load(): Promise<void> {
    this.loading.set(true);
    this.error.set(null);
    try {
      const bundle = await firstValueFrom(this.api.underwritingChecks());
      this.data.set(bundle);
    } catch (err) {
      this.error.set(this.toMessage(err));
    } finally {
      this.loading.set(false);
    }
  }

  protected retry(): void {
    void this.load();
  }

  private toMessage(err: unknown): string {
    if (err instanceof Error) return err.message;
    return 'Failed to load underwriting checks';
  }
}
