import {
  ChangeDetectionStrategy,
  Component,
  ElementRef,
  ViewChild,
  AfterViewChecked,
  HostListener,
  effect,
  inject,
  signal,
} from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { InsuranceProduct, QuickAction } from '../../core/models/chat.model';
import { ChatSessionsService } from '../../core/services/chat-sessions.service';
import { ChatSessionsComponent } from './chat-sessions/chat-sessions.component';

@Component({
  selector: 'app-chat',
  standalone: true,
  imports: [CommonModule, FormsModule, ChatSessionsComponent],
  changeDetection: ChangeDetectionStrategy.OnPush,
  templateUrl: './chat.component.html',
})
export class ChatComponent implements AfterViewChecked {
  @ViewChild('scrollArea') private scrollArea!: ElementRef<HTMLDivElement>;

  protected readonly sessionsSvc = inject(ChatSessionsService);

  protected draft = '';
  /** Convenience alias for the template — true while a bot reply is in flight. */
  protected readonly isTyping = this.sessionsSvc.sending;

  /** Mobile sessions panel open/closed */
  protected readonly mobileSessionsOpen = signal(false);

  protected readonly quickActions: QuickAction[] = [
    { id: 'q1', label: 'Compare term plans',     icon: '📊', prompt: 'Compare top term insurance plans for a 35-year-old non-smoker with ₹1 Cr cover for 30 years.' },
    { id: 'q2', label: 'Best ULIP options',       icon: '📈', prompt: 'Show me the best ULIP options for long-term wealth creation.' },
    { id: 'q3', label: 'Underwriting checklist',  icon: '📋', prompt: 'What documents are needed for underwriting a ₹2 Cr term plan?' },
    { id: 'q4', label: 'Rider explainer',         icon: '🛡️', prompt: 'Explain critical illness and accidental death riders.' },
    { id: 'q5', label: 'Tax benefits 80C',        icon: '💸', prompt: 'Summarise tax benefits under 80C and 10(10D) for life insurance.' },
    { id: 'q6', label: 'Pension plans',           icon: '🏦', prompt: 'Recommend pension plans for a 45-year-old.' },
  ];

  private autoScroll = true;

  constructor() {
    // Whenever the active session changes or sending finishes, scroll to bottom
    effect(() => {
      this.sessionsSvc.activeId();
      this.sessionsSvc.sending();
      this.autoScroll = true;
    });
  }

  // -------- Session interaction -------------------------------------

  protected async onSelectSession(id: string): Promise<void> {
    await this.sessionsSvc.selectSession(id);
    this.mobileSessionsOpen.set(false);
  }

  protected async onNewSession(): Promise<void> {
    await this.sessionsSvc.startNewSession();
    this.mobileSessionsOpen.set(false);
  }

  protected toggleMobileSessions(): void {
    this.mobileSessionsOpen.update((v) => !v);
  }

  @HostListener('document:keydown.escape')
  onEscape(): void {
    if (this.mobileSessionsOpen()) this.mobileSessionsOpen.set(false);
  }

  // -------- Chat interaction ----------------------------------------

  protected async send(): Promise<void> {
    const text = this.draft.trim();
    if (!text) return;
    this.draft = '';
    await this.sessionsSvc.sendUserMessage(text);
  }

  protected async sendQuick(q: QuickAction): Promise<void> {
    await this.sessionsSvc.sendUserMessage(q.prompt);
  }

  protected onEnter(e: Event): void {
    const ev = e as KeyboardEvent;
    if (!ev.shiftKey) {
      ev.preventDefault();
      void this.send();
    }
  }

  protected async onAskUnderwriting(p: InsuranceProduct): Promise<void> {
    await this.sessionsSvc.sendUserMessage(
      `What underwriting documents are required for ${p.name}?`
    );
  }

  // -------- Auto-scroll ---------------------------------------------

  ngAfterViewChecked(): void {
    if (this.autoScroll && this.scrollArea) {
      const el = this.scrollArea.nativeElement;
      el.scrollTop = el.scrollHeight;
      this.autoScroll = false;
    }
  }
}
