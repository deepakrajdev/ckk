"""Incentives & earnings endpoints."""

from fastapi import APIRouter, Depends, Query

from app.models import EarningsSummary, Incentive, IncentiveTag
from app.services.store import Store, get_store

router = APIRouter(prefix="/api/incentives", tags=["incentives"])


@router.get("/summary", response_model=EarningsSummary)
async def earnings_summary(
    store: Store = Depends(get_store),
) -> EarningsSummary:
    """Hero earnings tile for the incentives screen."""
    return await store.earnings_summary()


@router.get("/contests", response_model=list[Incentive])
async def list_incentives(
    tag: IncentiveTag | None = Query(None, description="Filter by contest tag"),
    store: Store = Depends(get_store),
) -> list[Incentive]:
    """Active contest cards."""
    return await store.list_incentives(tag=tag)
