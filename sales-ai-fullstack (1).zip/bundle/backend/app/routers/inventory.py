"""Sales-inventory (FLS pipeline) endpoints."""

from fastapi import APIRouter, Depends, Query

from app.models import InventoryRow, InventoryStat, UnderwritingStage
from app.services.store import Store, get_store

router = APIRouter(prefix="/api/inventory", tags=["inventory"])


@router.get("", response_model=list[InventoryRow])
async def list_inventory(
    stage: UnderwritingStage | None = Query(None, description="Filter by underwriting stage"),
    q: str | None = Query(None, description="Search across FLS ID"),
    store: Store = Depends(get_store),
) -> list[InventoryRow]:
    """Filterable FLS pipeline table."""
    return await store.list_inventory(stage=stage, q=q)


@router.get("/stats", response_model=list[InventoryStat])
async def inventory_stats(
    store: Store = Depends(get_store),
) -> list[InventoryStat]:
    """KPI tiles shown above the inventory table."""
    return await store.inventory_stats()
