"""Underwriting Checks endpoint — surfaces the 4 reference tables."""

from fastapi import APIRouter, Depends

from app.models import UnderwritingChecksBundle
from app.services.store import Store, get_store

router = APIRouter(prefix="/api/underwriting", tags=["underwriting"])


@router.get("/checks", response_model=UnderwritingChecksBundle)
async def get_checks(
    store: Store = Depends(get_store),
) -> UnderwritingChecksBundle:
    """
    Returns all four underwriting reference tables in a single payload:
      • Financial
      • Medical · Non-Disclosure
      • Medical · Disclosure
      • Non-Medical
    """
    return await store.underwriting_checks()
