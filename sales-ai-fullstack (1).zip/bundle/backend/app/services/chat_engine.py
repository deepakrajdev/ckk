"""
Chat engine — generates a bot reply for a user prompt.

This ports the demo logic from the Angular frontend so the two stay in sync.
Replace this module's body with a real LLM call (OpenAI / Anthropic / Bedrock,
plus your RAG layer over product & underwriting docs) without changing the
return type — every router stays untouched.
"""

import uuid
from datetime import datetime, timezone

from app.models.chat import (
    ChatMessage,
    InsuranceProduct,
    InsuranceProductType,
    MessageAuthor,
    ProductCardsAttachment,
    UnderwritingAttachment,
    UnderwritingDoc,
)


# -------- Sample catalogue (mirrors the frontend's demo data) --------

def _sample_term_products() -> list[InsuranceProduct]:
    return [
        InsuranceProduct(
            id="p1", name="SecureLife Elite Term", carrier="HDFC Life",
            type=InsuranceProductType.term,
            coverage="₹1 Cr", tenure="30 yrs", premium="₹12,400/yr",
            rating=5, recommended=True,
            highlights=[
                "99.4% claim settlement ratio",
                "Free annual health check-up",
                "Critical illness rider available",
            ],
        ),
        InsuranceProduct(
            id="p2", name="iProtect Smart", carrier="ICICI Pru",
            type=InsuranceProductType.term,
            coverage="₹1 Cr", tenure="30 yrs", premium="₹13,100/yr",
            rating=4,
            highlights=[
                "Return-of-premium option",
                "Terminal illness benefit",
                "Spouse cover add-on",
            ],
        ),
    ]


def _sample_ulip_products() -> list[InsuranceProduct]:
    return [
        InsuranceProduct(
            id="u1", name="Wealth Plus ULIP", carrier="Max Life",
            type=InsuranceProductType.ulip,
            coverage="₹1 Cr", tenure="20 yrs", premium="₹50,000/yr",
            rating=5, recommended=True,
            highlights=[
                "11.8% 5-yr CAGR (Balanced fund)",
                "Loyalty additions from year 6",
                "Unlimited fund switches",
            ],
        ),
        InsuranceProduct(
            id="u2", name="Smart Wealth Builder", carrier="TATA AIA",
            type=InsuranceProductType.ulip,
            coverage="₹1 Cr", tenure="20 yrs", premium="₹50,000/yr",
            rating=4,
            highlights=[
                "Top-ranked Multi-Cap fund",
                "Wealth-boosters from year 10",
                "Zero allocation charges",
            ],
        ),
    ]


def _sample_underwriting() -> list[UnderwritingDoc]:
    return [
        UnderwritingDoc(id="d1", name="KYC — PAN + Aadhaar",
                        required=True,
                        description="Self-attested copies; e-KYC accepted via DigiLocker."),
        UnderwritingDoc(id="d2", name="Income proof",
                        required=True,
                        description="Latest 3 salary slips or Form 16 / ITR for last 2 years."),
        UnderwritingDoc(id="d3", name="Address proof",
                        required=True,
                        description="Utility bill, passport, or driving licence (≤ 3 months old)."),
        UnderwritingDoc(id="d4", name="Medical examination",
                        required=True,
                        description="Full medicals at empanelled diagnostic centre — required for sum assured > ₹75 L."),
        UnderwritingDoc(id="d5", name="Financial questionnaire",
                        required=False,
                        description="Triggered if SA exceeds 25× annual income."),
        UnderwritingDoc(id="d6", name="NRI declaration",
                        required=False,
                        description="Only if applicant is a non-resident Indian."),
    ]


# -------- Public API --------------------------------------------------

def generate_reply(prompt: str) -> ChatMessage:
    """
    Produce a bot reply for *prompt*. Returns a fully-formed ChatMessage
    that the router will persist and ship to the frontend.
    """
    p = (prompt or "").lower()
    now = datetime.now(timezone.utc)
    new_id = str(uuid.uuid4())

    # Underwriting question
    if "underwriting" in p or "document" in p:
        return ChatMessage(
            id=new_id, author=MessageAuthor.bot, timestamp=now,
            content=("Here is the standard underwriting document checklist "
                     "for a ₹2 Cr term plan. Mandatory items are highlighted:"),
            attachment=UnderwritingAttachment(
                product="Term Plan · ₹2 Cr",
                documents=_sample_underwriting(),
            ),
        )

    # ULIP recommendation
    if "ulip" in p:
        return ChatMessage(
            id=new_id, author=MessageAuthor.bot, timestamp=now,
            content=("For wealth creation with insurance cover, here are two "
                     "ULIPs that consistently outperform their benchmark over 5 years:"),
            attachment=ProductCardsAttachment(products=_sample_ulip_products()),
        )

    # Term-plan comparison / recommendation
    if any(k in p for k in ("compare", "term", "recommend")):
        return ChatMessage(
            id=new_id, author=MessageAuthor.bot, timestamp=now,
            content="Here are the strongest matches for that profile, ranked by suitability:",
            attachment=ProductCardsAttachment(products=_sample_term_products()),
        )

    # Conversational fallback
    return ChatMessage(
        id=new_id, author=MessageAuthor.bot, timestamp=now,
        content=("I can help with product comparison, premium illustrations, "
                 "rider analysis, underwriting checklists and tax positioning. "
                 "Share the prospect's age, income, dependents and goal — I'll take it from there."),
    )


def underwriting_reply_for(product_name: str, coverage: str) -> ChatMessage:
    """Specifically requested via the 'Underwriting docs' button on a product card."""
    return ChatMessage(
        id=str(uuid.uuid4()),
        author=MessageAuthor.bot,
        timestamp=datetime.now(timezone.utc),
        content=(f"Here's the underwriting checklist for {product_name} "
                 f"(cover {coverage}). Items in red are mandatory for issuance:"),
        attachment=UnderwritingAttachment(
            product=product_name,
            documents=_sample_underwriting(),
        ),
    )
