"""Underwriting Checks — four reference tables surfaced by the UI."""

from .chat import Base


class FinancialCheck(Base):
    """One row of the Financial table."""
    id: str
    financial_suc: str        # e.g. "Up to ₹50 L"
    occupation_life_type: str # e.g. "Salaried · Class I"
    financial_requirement: str
    documents_list: list[str]


class MedicalCheck(Base):
    """
    Shared shape for both Medical tables (disclosure / non-disclosure).
    'disclosure_type' distinguishes the two without duplicating the model.
    """
    id: str
    age_limit: str            # e.g. "18-35", "36-45"
    medical_suc: str          # e.g. "Up to ₹25 L"
    medical_requirement: str  # e.g. "MER + ECG + FBS"


class NonMedicalCheck(Base):
    id: str
    age_limit: str
    vmer_requirement: str     # e.g. "Yes", "No", "Conditional"


class UnderwritingChecksBundle(Base):
    """Single payload — frontend renders all four tables in one screen."""
    financial: list[FinancialCheck]
    medical_non_disclosure: list[MedicalCheck]
    medical_disclosure: list[MedicalCheck]
    non_medical: list[NonMedicalCheck]
