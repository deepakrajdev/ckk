"""Sales inventory — FLS (Field Life Sales) pipeline records."""

from enum import Enum
from .chat import Base


class UnderwritingStage(str, Enum):
    submitted = "Submitted"
    medical = "Medical"
    in_review = "In Review"
    approved = "Approved"
    issued = "Issued"
    declined = "Declined"


class InventoryRow(Base):
    """One row in the FLS pipeline table."""
    id: str
    fls_id: str                       # Field Life Sales ID, e.g. "FLS-48201-Q2-0142"
    nop: int                          # Number of policies (this batch / submission)
    pfr: str                          # Premium First-year Receipts, formatted "₹12,40,000"
    underwriting_stage: UnderwritingStage
    submission: int                   # Submission count
    issuance: int                     # Issuance count
    total_nop: int                    # Cumulative NOP


class InventoryStat(Base):
    label: str
    value: str
    delta: str
    delta_up: bool
