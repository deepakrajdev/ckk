"""Incentives / earnings models."""

from enum import Enum
from pydantic import Field
from .chat import Base


class IncentiveTag(str, Enum):
    active = "Active"
    closing_soon = "Closing soon"
    stretch = "Stretch"


class Incentive(Base):
    id: str
    title: str
    reward: str
    progress: int = Field(ge=0, le=100)
    current: str
    target: str
    deadline: str
    tag: IncentiveTag


class EarningsSummary(Base):
    period_label: str        # "Q2 2026"
    amount: str              # "₹2,84,500"
    delta_pct: float         # 18.2
    delta_up: bool
    next_tier_label: str     # "Gold tier"
    next_tier_amount: str    # "₹4,00,000"
    next_tier_remaining: str # "₹1,15,500"
    current_tier_label: str  # "Silver tier"
    progress_pct: int = Field(ge=0, le=100)
