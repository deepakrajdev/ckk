# Sales AI Assistant — Full Stack

Angular 18 + Tailwind v4 frontend, FastAPI + Pydantic 2 backend.

```
.
├── frontend/   Angular 18 + Tailwind v4
└── backend/    FastAPI + Pydantic v2 + pypdfium2 (PDF thumbnails)
```

## Run both

```bash
# Terminal 1 — backend
cd backend
python -m venv .venv && source .venv/bin/activate   # Windows: .venv\Scripts\activate
pip install -r requirements.txt
uvicorn app.main:app --reload --port 8000
# On startup, thumbnails are auto-generated for any PDF that doesn't have one.

# Terminal 2 — frontend
cd frontend
npm install
npm start
```

## Library PDF thumbnails

The Library screen shows a real first-page preview of each PDF.

- **Build-time**: 5 sample thumbnails are pre-generated and shipped in `backend/app/static/thumbs/`.
- **Runtime**: at FastAPI startup, `ensure_thumbnails()` scans `static/pdfs/`. Any PDF without a sibling thumbnail (or whose PDF is newer than the thumbnail) gets one regenerated. So dropping a new PDF into `static/pdfs/foo.pdf` and restarting the server is all it takes.
- **Engine**: `pypdfium2` (Chrome's PDF engine, pure-wheel install, no system poppler needed) + Pillow for JPEG encoding.

Adjust render size or quality in `backend/app/services/thumbs.py`:
- `THUMB_WIDTH_PX` — source render width (default 480)
- `THUMB_JPEG_QUALITY` — 1–95 (default 82)

## Six screens

1. Product Recommendation & Comparison — chat with 5 sessions
2. Sales Inventory — FLS pipeline
3. Incentives — earnings + contests
4. Leads — pipeline by stage
5. Underwriting Checks — 4 reference tables
6. **Library — PDF tiles with first-page thumbnails**
