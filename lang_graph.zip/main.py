"""
FastAPI application entry point.

Start with:
    uvicorn app.main:app --reload --port 8000
"""
import logging
import os
from contextlib import asynccontextmanager

from dotenv import load_dotenv
from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import JSONResponse

from app.graph.insurance_graph import build_insurance_graph
from app.models.schemas import HealthCheckResponse
from app.routers.insurance_router import router as insurance_router
from app.services.llm_service import LLMService

# ──────────────────────────────────────────────
# Logging
# ──────────────────────────────────────────────
logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s | %(levelname)-8s | %(name)s | %(message)s",
    datefmt="%Y-%m-%d %H:%M:%S",
)
logger = logging.getLogger(__name__)

load_dotenv()


# ──────────────────────────────────────────────
# Lifespan (startup / shutdown)
# ──────────────────────────────────────────────
@asynccontextmanager
async def lifespan(app: FastAPI):
    """
    Initialise heavy objects once at startup and store them on app.state
    so every request can access them without re-creation.
    """
    logger.info("🚀  Starting Insurance AI service …")

    api_key = os.getenv("ANTHROPIC_API_KEY")
    if not api_key:
        raise RuntimeError("ANTHROPIC_API_KEY environment variable is not set.")

    # Initialise LLM service and LangGraph
    llm_service = LLMService()
    graph       = build_insurance_graph(llm_service)

    app.state.llm_service = llm_service
    app.state.graph       = graph

    logger.info("✅  LangGraph compiled and ready.")
    yield

    logger.info("🛑  Shutting down Insurance AI service.")


# ──────────────────────────────────────────────
# App instance
# ──────────────────────────────────────────────
app = FastAPI(
    title="Insurance AI Recommendation Engine",
    description=(
        "AI-powered insurance product recommendation system built with "
        "LangGraph + FastAPI. Classifies customer queries and recommends "
        "suitable life / health insurance products."
    ),
    version="1.0.0",
    lifespan=lifespan,
    docs_url="/docs",
    redoc_url="/redoc",
)

# ── CORS ────────────────────────────────────────
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],          # tighten in production
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# ── Routers ─────────────────────────────────────
app.include_router(insurance_router)


# ──────────────────────────────────────────────
# Core routes
# ──────────────────────────────────────────────
@app.get("/", include_in_schema=False)
async def root():
    return {"message": "Insurance AI Recommendation Engine is running. Visit /docs for the API."}


@app.get(
    "/health",
    response_model=HealthCheckResponse,
    tags=["System"],
    summary="Health check",
)
async def health_check() -> HealthCheckResponse:
    return HealthCheckResponse(
        status="healthy",
        service="Insurance AI Recommendation Engine",
        version="1.0.0",
    )


# ── Global exception handler ─────────────────
@app.exception_handler(Exception)
async def global_exception_handler(request, exc: Exception):
    logger.exception("Unhandled exception: %s", exc)
    return JSONResponse(
        status_code=500,
        content={"detail": "An unexpected error occurred. Please try again later."},
    )


# ──────────────────────────────────────────────
# Dev runner
# ──────────────────────────────────────────────
if __name__ == "__main__":
    import uvicorn
    uvicorn.run(
        "app.main:app",
        host="0.0.0.0",
        port=int(os.getenv("APP_PORT", 8000)),
        reload=os.getenv("APP_ENV", "development") == "development",
        log_level="info",
    )
