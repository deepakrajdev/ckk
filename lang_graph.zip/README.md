# Insurance AI Recommendation Engine

AI-powered life insurance product recommendation system built with **LangGraph** + **FastAPI** + **Claude (Anthropic)**.

---

## Architecture

```
Frontend Request
      │
      ▼
FastAPI (POST /api/v1/insurance/recommend)
      │
      ▼
LangGraph Pipeline
      │
      ├─► [1] validate_input        — sanitise and guard the input
      │
      ├─► [2] classify_query        — LLM classifies intent + risk profile
      │         │
      │         ├─(out_of_scope)──► handle_out_of_scope
      │         └─(error)────────► handle_error
      │
      ├─► [3] recommend_products    — LLM generates 2-3 product recommendations
      │         └─(error)────────► handle_error
      │
      └─► [4] format_output         — assemble final state
```

---

## Project Structure

```
insurance_ai/
├── app/
│   ├── main.py                  # FastAPI app, lifespan, middleware
│   ├── graph/
│   │   └── insurance_graph.py   # LangGraph nodes + graph builder
│   ├── models/
│   │   └── schemas.py           # Pydantic models + GraphState
│   ├── routers/
│   │   └── insurance_router.py  # API endpoints
│   └── services/
│       └── llm_service.py       # LLM wrapper + prompts
├── tests/
│   └── test_insurance.py        # Unit tests (mocked LLM)
├── requirements.txt
└── .env.example
```

---

## Setup

```bash
# 1. Clone / create the project
cd insurance_ai

# 2. Create virtual environment
python -m venv venv
source venv/bin/activate          # Windows: venv\Scripts\activate

# 3. Install dependencies
pip install -r requirements.txt

# 4. Configure environment
cp .env.example .env
# Edit .env and set your ANTHROPIC_API_KEY

# 5. Run the server
uvicorn app.main:app --reload --port 8000
```

---

## API Reference

### `POST /api/v1/insurance/recommend`
Full pipeline: classify → recommend.

**Request body**
```json
{
  "query": "I am 35 with two kids. I want to protect my family.",
  "user_age": 35,
  "annual_income": 1200000,
  "dependents": 2,
  "existing_policies": []
}
```

**Response**
```json
{
  "query": "...",
  "classification": {
    "category": "term_life",
    "confidence": 0.93,
    "detected_intent": "family financial protection",
    "risk_profile": "low",
    "key_factors": ["family protection", "affordable premium"]
  },
  "recommendations": [
    {
      "product_name": "SecureLife Term Plan",
      "product_type": "Term Life",
      "description": "...",
      "key_benefits": ["..."],
      "ideal_for": "...",
      "premium_range": "₹7,000 – ₹14,000/year",
      "coverage_range": "₹50 Lakh – ₹2 Crore",
      "why_recommended": "..."
    }
  ],
  "summary": "...",
  "disclaimer": "..."
}
```

### `POST /api/v1/insurance/classify`
Classification only (lighter, faster).

### `GET /health`
Returns service health status.

---

## Running Tests

```bash
pytest tests/ -v
```

No API key needed — LLM calls are fully mocked.

---

## Supported Query Categories

| Category | Description |
|---|---|
| `term_life` | Pure protection, affordable premium |
| `whole_life` | Lifelong cover with savings |
| `ulip` | Market-linked investment + insurance |
| `health_insurance` | Medical / critical illness cover |
| `child_plan` | Education / child future planning |
| `retirement_plan` | Pension, annuity, corpus building |
| `group_insurance` | Corporate / employer plans |
| `general_inquiry` | Generic insurance questions |
| `out_of_scope` | Non-insurance queries |
