"""
FastAPI router – /api/v1/insurance
"""
import logging
from fastapi import APIRouter, HTTPException, Request, status

from app.models.schemas import (
    UserQueryRequest,
    RecommendationResponse,
    ClassificationResult,
    InsuranceGraphState,
)

logger = logging.getLogger(__name__)

router = APIRouter(prefix="/api/v1/insurance", tags=["Insurance Recommendations"])


@router.post(
    "/recommend",
    response_model=RecommendationResponse,
    summary="Get personalised insurance product recommendations",
    description=(
        "Accepts a natural language query along with optional customer profile data. "
        "The request flows through a LangGraph pipeline: "
        "(1) query classification → (2) product recommendation."
    ),
)
async def recommend_insurance(
    request_body: UserQueryRequest,
    request: Request,
) -> RecommendationResponse:
    """
    Main recommendation endpoint.

    The compiled LangGraph is stored on `app.state` (set in main.py).
    """
    graph = request.app.state.graph

    # ── Build initial graph state ────────────────────────────────────────
    initial_state = InsuranceGraphState(
        user_query=request_body.query,
        user_age=request_body.user_age,
        annual_income=request_body.annual_income,
        dependents=request_body.dependents,
        existing_policies=request_body.existing_policies or [],
    )

    logger.info(
        "Received recommendation request  query=%r  age=%s  income=%s",
        request_body.query[:60],
        request_body.user_age,
        request_body.annual_income,
    )

    # ── Invoke the graph ─────────────────────────────────────────────────
    try:
        final_state: InsuranceGraphState = await graph.ainvoke(initial_state)
    except Exception as exc:
        logger.exception("Unhandled exception during graph execution")
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Internal processing error: {exc}",
        ) from exc

    logger.info("Graph completed  trace=%s", final_state.node_trace)

    # ── Guard: ensure we have minimum required fields ────────────────────
    if not final_state.query_category:
        # error occurred before classification could run
        raise HTTPException(
            status_code=status.HTTP_422_UNPROCESSABLE_ENTITY,
            detail=final_state.error or "Failed to classify query.",
        )

    # ── Assemble response ─────────────────────────────────────────────────
    classification = ClassificationResult(
        category=final_state.query_category,
        confidence=final_state.confidence,
        detected_intent=final_state.detected_intent,
        risk_profile=final_state.risk_profile,
        key_factors=final_state.key_factors,
    )

    return RecommendationResponse(
        query=request_body.query,
        classification=classification,
        recommendations=final_state.recommendations,
        summary=final_state.recommendation_summary,
    )


@router.post(
    "/classify",
    summary="Classify a query without generating recommendations",
    description="Lightweight endpoint – runs only the classification node.",
)
async def classify_only(
    request_body: UserQueryRequest,
    request: Request,
) -> ClassificationResult:
    """Return classification result only (no product recommendations)."""
    llm_service = request.app.state.llm_service
    try:
        classification, _ = llm_service.classify_query(
            query=request_body.query,
            user_age=request_body.user_age,
            annual_income=request_body.annual_income,
            dependents=request_body.dependents,
            existing_policies=request_body.existing_policies or [],
        )
    except Exception as exc:
        logger.exception("Classification failed")
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=str(exc),
        ) from exc

    return classification
