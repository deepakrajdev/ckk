"""
LangGraph workflow for the Insurance Recommendation Engine.

Graph topology:
  START
    │
    ▼
 [validate_input]
    │
    ▼
 [classify_query]  ──(error)──► [handle_error]
    │                                  │
    ▼                                  │
 [route_by_category]                   │
    │                                  │
    ├──(out_of_scope)──► [handle_out_of_scope]
    │                                  │
    ▼                                  │
 [recommend_products] ─(error)─►       │
    │                                  │
    ▼                                  │
 [format_output] ◄─────────────────────┘
    │
    ▼
  END
"""

import logging
from typing import Literal

from langgraph.graph import StateGraph, START, END

from app.models.schemas import InsuranceGraphState, QueryCategory, InsuranceProduct
from app.services.llm_service import LLMService

logger = logging.getLogger(__name__)

# ──────────────────────────────────────────────
# Node implementations
# ──────────────────────────────────────────────

def validate_input(state: InsuranceGraphState) -> InsuranceGraphState:
    """Sanitise and validate inputs before hitting the LLM."""
    logger.info("[NODE] validate_input")
    state.node_trace.append("validate_input")

    query = state.user_query.strip()
    if not query:
        state.error = "User query cannot be empty."
        return state

    if len(query) < 3:
        state.error = "Query is too short to process."
        return state

    state.user_query = query
    return state


def classify_query(state: InsuranceGraphState, llm: LLMService) -> InsuranceGraphState:
    """Call LLM to classify the query intent and risk profile."""
    logger.info("[NODE] classify_query  query=%r", state.user_query[:80])
    state.node_trace.append("classify_query")

    if state.error:          # propagate earlier errors
        return state

    try:
        classification, raw = llm.classify_query(
            query=state.user_query,
            user_age=state.user_age,
            annual_income=state.annual_income,
            dependents=state.dependents,
            existing_policies=state.existing_policies,
        )
        state.query_category      = classification.category
        state.confidence          = classification.confidence
        state.detected_intent     = classification.detected_intent
        state.risk_profile        = classification.risk_profile
        state.key_factors         = classification.key_factors
        state.classification_raw  = raw

        logger.info(
            "[NODE] classify_query  category=%s confidence=%.2f",
            state.query_category, state.confidence
        )
    except Exception as exc:
        logger.exception("[NODE] classify_query failed")
        state.error = f"Classification failed: {exc}"

    return state


def recommend_products(state: InsuranceGraphState, llm: LLMService) -> InsuranceGraphState:
    """Call LLM to generate product recommendations."""
    logger.info("[NODE] recommend_products")
    state.node_trace.append("recommend_products")

    if state.error:
        return state

    from app.models.schemas import ClassificationResult
    classification = ClassificationResult(
        category=state.query_category,
        confidence=state.confidence,
        detected_intent=state.detected_intent,
        risk_profile=state.risk_profile,
        key_factors=state.key_factors,
    )

    try:
        products, summary, raw = llm.recommend_products(
            query=state.user_query,
            classification=classification,
            user_age=state.user_age,
            annual_income=state.annual_income,
            dependents=state.dependents,
        )
        state.recommendations        = products
        state.recommendation_summary = summary
        state.recommendation_raw     = raw
        logger.info("[NODE] recommend_products  count=%d", len(products))
    except Exception as exc:
        logger.exception("[NODE] recommend_products failed")
        state.error = f"Recommendation failed: {exc}"

    return state


def handle_out_of_scope(state: InsuranceGraphState) -> InsuranceGraphState:
    """Return a polite out-of-scope message without calling the LLM again."""
    logger.info("[NODE] handle_out_of_scope")
    state.node_trace.append("handle_out_of_scope")

    state.recommendations = [
        InsuranceProduct(
            product_name="N/A",
            product_type="N/A",
            description="Your query does not appear to be related to insurance products.",
            key_benefits=[],
            ideal_for="N/A",
            premium_range="N/A",
            coverage_range="N/A",
            why_recommended=(
                "We specialise in life and health insurance. "
                "Please ask us about term life, ULIPs, health plans, child plans, or retirement plans."
            ),
        )
    ]
    state.recommendation_summary = (
        "This query is outside the scope of our insurance advisory service. "
        "Please feel free to ask about our insurance products."
    )
    return state


def handle_error(state: InsuranceGraphState) -> InsuranceGraphState:
    """Produce a graceful error response."""
    logger.warning("[NODE] handle_error  error=%s", state.error)
    state.node_trace.append("handle_error")

    state.recommendations = []
    state.recommendation_summary = (
        f"We encountered an issue processing your request: {state.error}. "
        "Please try again or contact our support team."
    )
    return state


def format_output(state: InsuranceGraphState) -> InsuranceGraphState:
    """Final node – log and pass state through (no transformation needed)."""
    logger.info("[NODE] format_output  trace=%s", state.node_trace)
    state.node_trace.append("format_output")
    return state


# ──────────────────────────────────────────────
# Routing functions (conditional edges)
# ──────────────────────────────────────────────

def route_after_validation(
    state: InsuranceGraphState,
) -> Literal["classify_query", "handle_error"]:
    return "handle_error" if state.error else "classify_query"


def route_after_classification(
    state: InsuranceGraphState,
) -> Literal["recommend_products", "handle_out_of_scope", "handle_error"]:
    if state.error:
        return "handle_error"
    if state.query_category == QueryCategory.OUT_OF_SCOPE:
        return "handle_out_of_scope"
    return "recommend_products"


def route_after_recommendation(
    state: InsuranceGraphState,
) -> Literal["format_output", "handle_error"]:
    return "handle_error" if state.error else "format_output"


# ──────────────────────────────────────────────
# Graph builder
# ──────────────────────────────────────────────

def build_insurance_graph(llm: LLMService) -> StateGraph:
    """
    Construct and compile the LangGraph state machine.
    The LLMService is injected via closures so nodes stay stateless.
    """

    # Bind LLM into nodes that need it
    def _classify(s: InsuranceGraphState) -> InsuranceGraphState:
        return classify_query(s, llm)

    def _recommend(s: InsuranceGraphState) -> InsuranceGraphState:
        return recommend_products(s, llm)

    builder = StateGraph(InsuranceGraphState)

    # ── Register nodes ──────────────────────
    builder.add_node("validate_input",       validate_input)
    builder.add_node("classify_query",       _classify)
    builder.add_node("recommend_products",   _recommend)
    builder.add_node("handle_out_of_scope",  handle_out_of_scope)
    builder.add_node("handle_error",         handle_error)
    builder.add_node("format_output",        format_output)

    # ── Edges ───────────────────────────────
    builder.add_edge(START, "validate_input")

    builder.add_conditional_edges(
        "validate_input",
        route_after_validation,
        {"classify_query": "classify_query", "handle_error": "handle_error"},
    )

    builder.add_conditional_edges(
        "classify_query",
        route_after_classification,
        {
            "recommend_products":  "recommend_products",
            "handle_out_of_scope": "handle_out_of_scope",
            "handle_error":        "handle_error",
        },
    )

    builder.add_conditional_edges(
        "recommend_products",
        route_after_recommendation,
        {"format_output": "format_output", "handle_error": "handle_error"},
    )

    builder.add_edge("handle_out_of_scope", "format_output")
    builder.add_edge("handle_error",        "format_output")
    builder.add_edge("format_output",       END)

    return builder.compile()
