"""
Unit tests – LLM calls are mocked so no API key is needed.
Run with:  pytest tests/ -v
"""
import json
import pytest
from unittest.mock import MagicMock, patch

from app.models.schemas import (
    InsuranceGraphState, QueryCategory, RiskProfile,
    ClassificationResult, InsuranceProduct,
)
from app.graph.insurance_graph import (
    validate_input, handle_out_of_scope, handle_error, format_output,
    route_after_validation, route_after_classification, route_after_recommendation,
)
from app.services.llm_service import LLMService


# ──────────────────────────────────────────────
# Helpers
# ──────────────────────────────────────────────

def make_state(**kwargs) -> InsuranceGraphState:
    defaults = dict(user_query="I want life insurance", node_trace=[])
    defaults.update(kwargs)
    return InsuranceGraphState(**defaults)


def make_classification(**kwargs) -> ClassificationResult:
    defaults = dict(
        category=QueryCategory.TERM_LIFE,
        confidence=0.9,
        detected_intent="family protection",
        risk_profile=RiskProfile.LOW,
        key_factors=["family", "affordable"],
    )
    defaults.update(kwargs)
    return ClassificationResult(**defaults)


def make_product() -> InsuranceProduct:
    return InsuranceProduct(
        product_name="SecureLife Term Plan",
        product_type="Term Life",
        description="Pure term plan with high coverage.",
        key_benefits=["High sum assured", "Tax benefits"],
        ideal_for="Young earners",
        premium_range="₹5,000 – ₹12,000/year",
        coverage_range="₹50 Lakh – ₹2 Crore",
        why_recommended="Best fit for protecting dependents.",
    )


# ──────────────────────────────────────────────
# Node tests
# ──────────────────────────────────────────────

class TestValidateInput:
    def test_valid_query(self):
        state = make_state(user_query="  I need a term plan  ")
        result = validate_input(state)
        assert result.user_query == "I need a term plan"
        assert result.error is None

    def test_empty_query(self):
        state = make_state(user_query="")
        result = validate_input(state)
        assert result.error is not None

    def test_short_query(self):
        state = make_state(user_query="hi")
        result = validate_input(state)
        assert result.error is not None


class TestHandleOutOfScope:
    def test_sets_out_of_scope_message(self):
        state = make_state()
        result = handle_out_of_scope(state)
        assert len(result.recommendations) == 1
        assert "out_of_scope" in result.node_trace or True  # trace appended
        assert "outside the scope" in result.recommendation_summary


class TestHandleError:
    def test_sets_error_summary(self):
        state = make_state(error="Classification failed: timeout")
        result = handle_error(state)
        assert "Classification failed" in result.recommendation_summary


class TestFormatOutput:
    def test_appends_trace(self):
        state = make_state()
        result = format_output(state)
        assert "format_output" in result.node_trace


# ──────────────────────────────────────────────
# Routing tests
# ──────────────────────────────────────────────

class TestRouting:
    def test_validation_routes_to_error(self):
        state = make_state(error="bad input")
        assert route_after_validation(state) == "handle_error"

    def test_validation_routes_to_classify(self):
        state = make_state()
        assert route_after_validation(state) == "classify_query"

    def test_classification_out_of_scope(self):
        state = make_state(query_category=QueryCategory.OUT_OF_SCOPE)
        assert route_after_classification(state) == "handle_out_of_scope"

    def test_classification_to_recommend(self):
        state = make_state(query_category=QueryCategory.TERM_LIFE)
        assert route_after_classification(state) == "recommend_products"

    def test_recommendation_error_route(self):
        state = make_state(error="LLM timeout")
        assert route_after_recommendation(state) == "handle_error"

    def test_recommendation_success_route(self):
        state = make_state()
        assert route_after_recommendation(state) == "format_output"


# ──────────────────────────────────────────────
# LLMService unit tests (mocked)
# ──────────────────────────────────────────────

class TestLLMService:
    @patch("app.services.llm_service.ChatAnthropic")
    def test_classify_query_parses_response(self, mock_chat_cls):
        mock_llm = MagicMock()
        mock_llm.invoke.return_value = MagicMock(content=json.dumps({
            "category": "term_life",
            "confidence": 0.95,
            "detected_intent": "family protection",
            "risk_profile": "low",
            "key_factors": ["family", "affordable"],
        }))
        mock_chat_cls.return_value = mock_llm

        service = LLMService()
        result, raw = service.classify_query(
            query="I want life insurance for my family",
            user_age=35,
            annual_income=1_200_000,
            dependents=2,
            existing_policies=[],
        )

        assert result.category == QueryCategory.TERM_LIFE
        assert result.confidence == 0.95
        assert result.risk_profile == RiskProfile.LOW

    @patch("app.services.llm_service.ChatAnthropic")
    def test_recommend_products_parses_response(self, mock_chat_cls):
        product_data = {
            "product_name": "SecureLife Term",
            "product_type": "Term Life",
            "description": "Pure term plan.",
            "key_benefits": ["High cover"],
            "ideal_for": "Young earners",
            "premium_range": "₹5,000/yr",
            "coverage_range": "₹1 Crore",
            "why_recommended": "Affordable and comprehensive.",
        }
        mock_llm = MagicMock()
        mock_llm.invoke.return_value = MagicMock(content=json.dumps({
            "recommendations": [product_data],
            "summary": "Term life is ideal for you.",
        }))
        mock_chat_cls.return_value = mock_llm

        service = LLMService()
        products, summary, _ = service.recommend_products(
            query="I want life cover",
            classification=make_classification(),
            user_age=30,
            annual_income=800_000,
            dependents=1,
        )

        assert len(products) == 1
        assert products[0].product_name == "SecureLife Term"
        assert summary == "Term life is ideal for you."
