"""
LLM service – thin wrapper around the Claude model.
All prompts live here to keep graph nodes clean.
"""
import json
import logging
from typing import Any

from langchain_anthropic import ChatAnthropic
from langchain_core.messages import HumanMessage, SystemMessage

from app.models.schemas import (
    QueryCategory, RiskProfile,
    ClassificationResult, InsuranceProduct,
)

logger = logging.getLogger(__name__)

# ──────────────────────────────────────────────
# System Prompts
# ──────────────────────────────────────────────

CLASSIFICATION_SYSTEM_PROMPT = """
You are an expert life insurance advisor AI for an Indian insurance company.
Your job is to classify customer queries into one of the following categories and
extract key information.

Categories:
- term_life        : Pure term life cover, death benefit only
- whole_life       : Lifelong cover with savings component
- ulip             : Market-linked insurance plans
- health_insurance : Medical / critical illness cover
- child_plan       : Plans for child's education / future
- retirement_plan  : Pension, annuity, retirement corpus
- group_insurance  : Corporate / group covers
- general_inquiry  : Generic questions about insurance
- out_of_scope     : Completely unrelated to insurance

You MUST respond with ONLY a valid JSON object (no markdown, no explanation):
{
  "category": "<one of the categories above>",
  "confidence": <0.0 to 1.0>,
  "detected_intent": "<short phrase describing user intent>",
  "risk_profile": "<low | moderate | high>",
  "key_factors": ["<factor1>", "<factor2>", ...]
}
""".strip()

RECOMMENDATION_SYSTEM_PROMPT = """
You are a senior insurance product specialist at an Indian life insurance company.
Given a classified customer query, recommend 2-3 insurance products.

Respond ONLY with a valid JSON object (no markdown, no preamble):
{
  "recommendations": [
    {
      "product_name": "<specific product name>",
      "product_type": "<product type>",
      "description": "<2-3 sentence description>",
      "key_benefits": ["<benefit1>", "<benefit2>", "<benefit3>"],
      "ideal_for": "<target customer profile>",
      "premium_range": "<e.g. ₹5,000 – ₹15,000 per year>",
      "coverage_range": "<e.g. ₹25 Lakh – ₹1 Crore>",
      "why_recommended": "<1-2 sentences specific to this customer>"
    }
  ],
  "summary": "<2-3 sentence overall recommendation rationale>"
}
""".strip()


# ──────────────────────────────────────────────
# LLM Service
# ──────────────────────────────────────────────

class LLMService:
    """Wraps Claude via LangChain for structured insurance tasks."""

    def __init__(self, model_name: str = "claude-sonnet-4-20250514", temperature: float = 0.2):
        self.llm = ChatAnthropic(model=model_name, temperature=temperature)
        logger.info("LLMService initialised with model=%s", model_name)

    # ── helpers ──────────────────────────────

    def _invoke(self, system_prompt: str, user_message: str) -> str:
        """Call the LLM and return the raw string response."""
        messages = [
            SystemMessage(content=system_prompt),
            HumanMessage(content=user_message),
        ]
        response = self.llm.invoke(messages)
        return response.content.strip()

    @staticmethod
    def _safe_json(raw: str) -> Any:
        """Strip markdown fences and parse JSON."""
        cleaned = raw.replace("```json", "").replace("```", "").strip()
        return json.loads(cleaned)

    # ── public methods ───────────────────────

    def classify_query(
        self,
        query: str,
        user_age: int | None,
        annual_income: float | None,
        dependents: int | None,
        existing_policies: list[str],
    ) -> tuple[ClassificationResult, str]:
        """
        Classify the user query.
        Returns (ClassificationResult, raw_json_string).
        """
        context_parts = [f"Customer query: {query}"]
        if user_age:
            context_parts.append(f"Age: {user_age}")
        if annual_income:
            context_parts.append(f"Annual income: ₹{annual_income:,.0f}")
        if dependents is not None:
            context_parts.append(f"Number of dependents: {dependents}")
        if existing_policies:
            context_parts.append(f"Existing policies: {', '.join(existing_policies)}")

        user_message = "\n".join(context_parts)
        logger.debug("Classification user_message: %s", user_message)

        raw = self._invoke(CLASSIFICATION_SYSTEM_PROMPT, user_message)
        logger.debug("Classification raw response: %s", raw)

        data = self._safe_json(raw)

        result = ClassificationResult(
            category=QueryCategory(data["category"]),
            confidence=float(data["confidence"]),
            detected_intent=data["detected_intent"],
            risk_profile=RiskProfile(data["risk_profile"]),
            key_factors=data.get("key_factors", []),
        )
        return result, raw

    def recommend_products(
        self,
        query: str,
        classification: ClassificationResult,
        user_age: int | None,
        annual_income: float | None,
        dependents: int | None,
    ) -> tuple[list[InsuranceProduct], str, str]:
        """
        Generate product recommendations.
        Returns (list[InsuranceProduct], summary, raw_json_string).
        """
        user_message = f"""
Customer Query: {query}

Classification Result:
- Category: {classification.category.value}
- Detected Intent: {classification.detected_intent}
- Risk Profile: {classification.risk_profile.value}
- Key Factors: {', '.join(classification.key_factors)}

Customer Profile:
- Age: {user_age or 'Not provided'}
- Annual Income: {'₹{:,.0f}'.format(annual_income) if annual_income else 'Not provided'}
- Dependents: {dependents if dependents is not None else 'Not provided'}

Please recommend the most suitable insurance products.
""".strip()

        logger.debug("Recommendation user_message: %s", user_message)

        raw = self._invoke(RECOMMENDATION_SYSTEM_PROMPT, user_message)
        logger.debug("Recommendation raw response: %s", raw)

        data = self._safe_json(raw)

        products = [InsuranceProduct(**p) for p in data["recommendations"]]
        summary  = data.get("summary", "")
        return products, summary, raw
