"""FastAPI application exposing the Query Identification REST API.

Uses a direct REST integration with the Gemini API (no google-generativeai SDK).
A single httpx.AsyncClient is shared across requests via the app lifespan so
that connection pooling and keep-alive work correctly.
"""

import logging
from contextlib import asynccontextmanager
from typing import AsyncIterator

import httpx
from fastapi import FastAPI, HTTPException, Request
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import JSONResponse

from classifier import GeminiAPIError, QueryClassifier
from config import settings
from models import ClassifyRequest, ClassifyResponse, ErrorResponse, HealthResponse

logging.basicConfig(
    level=settings.log_level,
    format="%(asctime)s | %(levelname)s | %(name)s | %(message)s",
)
logger = logging.getLogger("query_classifier_api")


@asynccontextmanager
async def lifespan(app: FastAPI) -> AsyncIterator[None]:
    logger.info("Starting up. Model=%s", settings.gemini_model)

    # Tunable HTTP pool. Adjust max_connections for your expected concurrency.
    limits = httpx.Limits(max_connections=50, max_keepalive_connections=20)
    timeout = httpx.Timeout(connect=5.0, read=20.0, write=10.0, pool=5.0)
    http_client = httpx.AsyncClient(limits=limits, timeout=timeout)

    classifier = QueryClassifier(
        api_key= 'gemini_api_key',#settings.gemini_api_key,
        model='google-flash-2.0', #settings.gemini_model,
        client=http_client,  # share the pool
    )

    app.state.http_client = http_client
    app.state.classifier = classifier
    try:
        yield
    finally:
        logger.info("Shutting down — closing HTTP client.")
        await http_client.aclose()


app = FastAPI(
    title="Query Identification API",
    description=(
        "Classifies an end-user query into: recommendation | comparison | information | "
        "underwriting_document_ask | incentive_ask. Backed by Google Gemini 2.0 Flash via REST."
    ),
    version="1.1.0",
    lifespan=lifespan,
)

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_methods=["GET", "POST"],
    allow_headers=["*"],
)


@app.exception_handler(Exception)
async def unhandled_exception_handler(request: Request, exc: Exception) -> JSONResponse:
    logger.exception("Unhandled error on %s %s", request.method, request.url.path)
    return JSONResponse(
        status_code=500,
        content=ErrorResponse(detail=f"Internal server error: {exc}").model_dump(),
    )


@app.get("/health", response_model=HealthResponse, tags=["meta"])
async def health() -> HealthResponse:
    return HealthResponse(status="ok", model=settings.gemini_model)


@app.post(
    "/v1/classify",
    response_model=ClassifyResponse,
    responses={
        400: {"model": ErrorResponse, "description": "Bad request"},
        502: {"model": ErrorResponse, "description": "Upstream Gemini error"},
        503: {"model": ErrorResponse, "description": "Classifier not initialized"},
    },
    tags=["classify"],
)
async def classify(req: ClassifyRequest, request: Request) -> ClassifyResponse:
    """Classify a single query and return the predicted category."""
    classifier: QueryClassifier | None = getattr(request.app.state, "classifier", None)
    if classifier is None:
        raise HTTPException(status_code=503, detail="Classifier not initialized")

    try:
        return await classifier.classify(req.query)
    except ValueError as exc:
        raise HTTPException(status_code=400, detail=str(exc)) from exc
    except GeminiAPIError as exc:
        logger.error("Upstream Gemini error: %s", exc)
        raise HTTPException(status_code=502, detail=f"Upstream Gemini error: {exc}") from exc


if __name__ == "__main__":
    import uvicorn

    uvicorn.run("main:app", host="0.0.0.0", port=8000, reload=False)
