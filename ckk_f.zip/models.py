"""Pydantic schemas for the Query Identification API."""

from enum import Enum
from pydantic import BaseModel, Field


class QueryCategory(str, Enum):
    """The supported query categories.

    Keep these values stable — they are part of the public API contract.
    """

    RECOMMENDATION = "recommendation"
    COMPARISON = "comparison"
    INFORMATION = "information"
    UNDERWRITING_DOCUMENT_ASK = "underwriting_document_ask"
    INCENTIVE_ASK = "incentive_ask"
    UNKNOWN = "unknown"  # fallback when the model returns something off-spec


class ClassifyRequest(BaseModel):
    query: str = Field(
        ...,
        min_length=1,
        max_length=4000,
        description="The end-user query to classify.",
    )


class ClassifyResponse(BaseModel):
    category: QueryCategory = Field(..., description="The identified query category.")
    # confidence: float = Field(
    #     ..., ge=0.0, le=1.0, description="Model self-reported confidence in [0, 1]."
    # )
    # reasoning: str = Field(..., description="Short explanation from the model.")
    query: str = Field(..., description="Echo of the input query for traceability.")


class HealthResponse(BaseModel):
    status: str
    model: str


class ErrorResponse(BaseModel):
    detail: str
