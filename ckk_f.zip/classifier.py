"""Gemini-backed query classifier using the raw REST API (no SDK).

We call the Gemini `generateContent` endpoint directly with httpx.AsyncClient.
This avoids the google-generativeai dependency and gives us full control over
timeouts, retries, and error handling.

Endpoint:
    POST https://generativelanguage.googleapis.com/v1beta/models/{model}:generateContent?key={API_KEY}

Docs: https://ai.google.dev/api/generate-content
"""

import asyncio
import json
import logging
from typing import Any

import httpx

from models import ClassifyResponse, QueryCategory

logger = logging.getLogger(__name__)


GEMINI_BASE_URL = "https://generativelanguage.googleapis.com/v1beta"


SYSTEM_PROMPT = """You are a query classifier for an insurance-domain assistant.
Classify the user's query into EXACTLY ONE of these categories:

1. recommendation — User wants a suggestion or advice on what to choose/buy/do.
   Examples: "Which term plan is best for a 30-year-old?", "Suggest a health policy for my family"

2. comparison — User is comparing two or more options, products, or concepts.
   Examples: "Plan A vs Plan B", "Difference between term and whole life insurance"

3. information — User wants factual information, definitions, or how-things-work explanations.
   Examples: "What is a deductible?", "How does claim settlement work?", "Explain riders"

4. underwriting_document_ask — User is asking about, requesting, or uploading documents needed
   for underwriting: medical reports, KYC, income proof, questionnaires, financial statements.
   Examples: "What documents do I need for underwriting?", "Share the medical questionnaire",
   "Is income proof mandatory?"

5. incentive_ask — User is asking about incentives, discounts, offers, bonuses, rewards,
   cashback, or promotional benefits — either for customers or for agents/advisors.
   Examples: "Any discount on this policy?", "What incentives are available for agents this quarter?",
   "Is there a no-claim bonus?"

CLASSIFICATION RULES:
- Pick the category that BEST fits the primary intent of the query.
- If a query mixes intents, prefer the dominant one.
- If the query is ambiguous or out of scope, choose "information" with a lower confidence.
- Never invent new categories.

OUTPUT FORMAT — respond with a SINGLE JSON object, no markdown fences, no prose:
{
  "category": "<one of: recommendation, comparison, information, underwriting_document_ask, incentive_ask>",
  "confidence": <float between 0.0 and 1.0>,
  "reasoning": "<one short sentence explaining the choice>"
}
"""


class GeminiAPIError(RuntimeError):
    """Raised for any non-recoverable Gemini REST error."""


class QueryClassifier:
    """Classifies queries by POSTing directly to the Gemini REST endpoint."""

    def __init__(
        self,
        api_key: str,
        model: str = "gemini-2.0-flash",
        client: httpx.AsyncClient | None = None,
        request_timeout_s: float = 20.0,
        max_retries: int = 2,
    ) -> None:
        if not api_key:
            raise ValueError("GEMINI_API_KEY is required to initialize QueryClassifier")
        self.api_key = api_key
        self.model = model
        self.url = f"{GEMINI_BASE_URL}/models/{model}:generateContent"
        # If a shared client isn't injected, we'll own one.
        self._owns_client = client is None
        self.client = client or httpx.AsyncClient(timeout=request_timeout_s)
        self.request_timeout_s = request_timeout_s
        self.max_retries = max_retries

    async def aclose(self) -> None:
        if self._owns_client:
            await self.client.aclose()

    async def classify(self, query: str) -> ClassifyResponse:
        query = query.strip()
        if not query:
            raise ValueError("Query must not be empty")

        # payload = self._build_payload(query)
        # data = await self._post_with_retry(payload)
        # raw_text = self._extract_text(data)
        # parsed = self._parse_json(raw_text)

        # return ClassifyResponse(
        #     category=self._coerce_category(parsed.get("category")),
        #     confidence=self._coerce_confidence(parsed.get("confidence")),
        #     reasoning=str(parsed.get("reasoning") or "").strip() or "No reasoning provided.",
        #     query=query,
        # )

        return ClassifyResponse(
            category='recommendation',
            query=query,
        )

    # ----- HTTP -----

    def _build_payload(self, query: str) -> dict[str, Any]:
        return {
            "system_instruction": {"parts": [{"text": SYSTEM_PROMPT}]},
            "contents": [
                {"role": "user", "parts": [{"text": query}]}
            ],
            "generationConfig": {
                "temperature": 0.1,
                "topP": 0.95,
                "maxOutputTokens": 256,
                "responseMimeType": "application/json",
            },
        }

    async def _post_with_retry(self, payload: dict[str, Any]) -> dict[str, Any]:
        """POST with exponential backoff for transient errors (429 / 5xx / network)."""
        attempt = 0
        last_exc: Exception | None = None

        while attempt <= self.max_retries:
            try:
                resp = await self.client.post(
                    self.url,
                    params={"key": self.api_key},
                    json=payload,
                    headers={"Content-Type": "application/json"},
                    timeout=self.request_timeout_s,
                )
            except (httpx.TimeoutException, httpx.TransportError) as exc:
                last_exc = exc
                logger.warning("Network error to Gemini (attempt %d): %s", attempt + 1, exc)
            else:
                if resp.status_code == 200:
                    try:
                        return resp.json()
                    except json.JSONDecodeError as exc:
                        raise GeminiAPIError(f"Non-JSON 200 response: {exc}") from exc

                # 4xx (except 429) → don't retry, surface to caller.
                if 400 <= resp.status_code < 500 and resp.status_code != 429:
                    raise GeminiAPIError(
                        f"Gemini {resp.status_code}: {self._err_detail(resp)}"
                    )

                # 429 or 5xx → retryable
                logger.warning(
                    "Retryable Gemini status %s (attempt %d): %s",
                    resp.status_code, attempt + 1, self._err_detail(resp),
                )
                last_exc = GeminiAPIError(f"HTTP {resp.status_code}")

            attempt += 1
            if attempt <= self.max_retries:
                await asyncio.sleep(0.5 * (2 ** (attempt - 1)))  # 0.5s, 1s, 2s, ...

        raise GeminiAPIError(f"Gemini call failed after {self.max_retries + 1} attempts: {last_exc}")

    @staticmethod
    def _err_detail(resp: httpx.Response) -> str:
        try:
            body = resp.json()
            return json.dumps(body.get("error", body))[:500]
        except Exception:
            return resp.text[:500]

    # ----- response parsing -----

    @staticmethod
    def _extract_text(data: dict[str, Any]) -> str:
        """Pull the text out of a Gemini generateContent response."""
        candidates = data.get("candidates") or []
        if not candidates:
            # Sometimes safety blocks surface as promptFeedback with no candidates.
            feedback = data.get("promptFeedback")
            raise GeminiAPIError(f"No candidates in response. promptFeedback={feedback}")

        cand = candidates[0]
        finish = cand.get("finishReason")
        if finish and finish not in ("STOP", "MAX_TOKENS"):
            raise GeminiAPIError(f"Generation halted: finishReason={finish}")

        parts = (cand.get("content") or {}).get("parts") or []
        text = "".join(p.get("text", "") for p in parts).strip()
        if not text:
            raise GeminiAPIError("Empty text in Gemini response")
        return text

    @staticmethod
    def _parse_json(raw: str) -> dict[str, Any]:
        try:
            return json.loads(raw)
        except json.JSONDecodeError:
            # Defensive: strip code fences if the model wrapped JSON despite instructions.
            cleaned = raw.strip().removeprefix("```json").removeprefix("```").removesuffix("```").strip()
            try:
                return json.loads(cleaned)
            except json.JSONDecodeError as exc:
                logger.error("Failed to parse model JSON. Raw=%r", raw)
                raise GeminiAPIError(f"Invalid JSON from model: {exc}") from exc

    @staticmethod
    def _coerce_category(value: Any) -> QueryCategory:
        if not isinstance(value, str):
            return QueryCategory.UNKNOWN
        try:
            return QueryCategory(value.lower().strip())
        except ValueError:
            logger.warning("Model returned unknown category: %r", value)
            return QueryCategory.UNKNOWN

    @staticmethod
    def _coerce_confidence(value: Any) -> float:
        try:
            c = float(value)
        except (TypeError, ValueError):
            return 0.0
        return max(0.0, min(1.0, c))
