# Query Identification API (REST-direct)

A FastAPI service that classifies an end-user query into one of five categories,
calling **Google Gemini 2.0 Flash** directly over its **REST API** with `httpx`
(no `google-generativeai` SDK).

## Why REST-direct?

- **No SDK lock-in.** You depend only on standard HTTP + JSON.
- **Full control** over timeouts, retries, connection pooling, and observability.
- **Same payload shape** works from any language — easy to port.

## Categories

| Category                     | When to use                                                                 |
| ---------------------------- | --------------------------------------------------------------------------- |
| `recommendation`             | User wants a suggestion / advice on what to choose                          |
| `comparison`                 | User is comparing two or more options                                       |
| `information`                | User wants factual info, definitions, or explanations                       |
| `underwriting_document_ask`  | User is asking about underwriting documents (KYC, medical, income proof…)   |
| `incentive_ask`              | User is asking about discounts, bonuses, cashback, agent incentives, etc.   |

## Project layout

```
query_classifier_api_rest/
├── main.py            # FastAPI app, lifespan with shared httpx client
├── classifier.py      # Raw REST call to Gemini, retries, JSON parsing
├── models.py          # Pydantic schemas
├── config.py          # Env-based settings
├── requirements.txt
├── .env.example
└── README.md
```

## Setup

```bash
python -m venv .venv && source .venv/bin/activate
pip install -r requirements.txt

cp .env.example .env
# edit .env and set GEMINI_API_KEY  (get one at https://aistudio.google.com/app/apikey)

uvicorn main:app --host 0.0.0.0 --port 8000
# or:  python main.py
```

OpenAPI docs at `http://localhost:8000/docs`.

## API

### `GET /health`
```json
{ "status": "ok", "model": "gemini-2.0-flash" }
```

### `POST /v1/classify`

Request:
```json
{ "query": "What documents do I need to submit for underwriting a term plan?" }
```

Response:
```json
{
  "category": "underwriting_document_ask",
  "confidence": 0.96,
  "reasoning": "The user is explicitly asking which documents are required for underwriting.",
  "query": "What documents do I need to submit for underwriting a term plan?"
}
```

### Examples

```bash
curl -s http://localhost:8000/v1/classify \
  -H 'content-type: application/json' \
  -d '{"query":"Suggest a good health policy for a family of 4"}'

curl -s http://localhost:8000/v1/classify \
  -H 'content-type: application/json' \
  -d '{"query":"Compare ULIP vs traditional endowment plans"}'

curl -s http://localhost:8000/v1/classify \
  -H 'content-type: application/json' \
  -d '{"query":"Are there any festive discounts on premium this month?"}'
```

## What the upstream call looks like

For reference / debugging, the request the service sends to Google:

```http
POST https://generativelanguage.googleapis.com/v1beta/models/gemini-2.0-flash:generateContent?key=YOUR_KEY
Content-Type: application/json

{
  "system_instruction": { "parts": [{ "text": "<system prompt>" }] },
  "contents": [
    { "role": "user", "parts": [{ "text": "<user query>" }] }
  ],
  "generationConfig": {
    "temperature": 0.1,
    "topP": 0.95,
    "maxOutputTokens": 256,
    "responseMimeType": "application/json"
  }
}
```

You can curl the same thing standalone:
```bash
curl -s "https://generativelanguage.googleapis.com/v1beta/models/gemini-2.0-flash:generateContent?key=$GEMINI_API_KEY" \
  -H 'Content-Type: application/json' \
  -d '{
    "contents":[{"role":"user","parts":[{"text":"hello"}]}],
    "generationConfig":{"responseMimeType":"application/json","temperature":0.1}
  }'
```

## Design notes

- **Shared `httpx.AsyncClient`** owned by the app lifespan → connection pooling + keep-alive.
  Configurable `Limits` (50 max connections, 20 keep-alive) and granular `Timeout`
  (connect/read/write/pool).
- **Retries with exponential backoff** for 429 and 5xx and network errors (default 2 retries → 3 total attempts, 0.5s → 1s → 2s).
  4xx (non-429) errors fail fast since they're config or input problems, not transient.
- **Strict JSON mode** (`responseMimeType: application/json`) + low temperature for stable output.
- **Defensive parsing**: handles code-fenced JSON, empty candidates, and safety-blocked responses (`promptFeedback`).
- **Typed errors**: `GeminiAPIError` maps cleanly to HTTP 502 so callers can distinguish upstream failures from validation or internal errors.

## Production hardening checklist

- [ ] Lock down CORS origins
- [ ] Add API-key / OAuth on this service's edge
- [ ] Per-IP / per-key rate limiting
- [ ] Structured logs with a request-id middleware
- [ ] Metrics: latency, retry counts, per-category distribution, error codes
- [ ] Small offline eval set (50–100 labeled queries) wired into CI
- [ ] LRU cache keyed by `hash(normalize(query))` if you expect repeats
- [ ] Pin a specific model snapshot (e.g., `gemini-2.0-flash-001`) once stable
- [ ] Store `GEMINI_API_KEY` in a secret manager (not a `.env` in prod)
