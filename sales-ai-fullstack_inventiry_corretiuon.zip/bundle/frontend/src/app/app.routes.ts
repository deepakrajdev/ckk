import { Routes } from '@angular/router';

export const routes: Routes = [
  {
    path: '',
    pathMatch: 'full',
    loadComponent: () =>
      import('./features/welcome/welcome.component').then((m) => m.WelcomeComponent),
    data: { title: 'Welcome' },
  },
  {
    path: 'assistant',
    loadComponent: () =>
      import('./features/intake/intake.component').then((m) => m.IntakeComponent),
    data: { title: 'Product Recommendation' },
  },
  {
    path: 'assistant/chat',
    loadComponent: () =>
      import('./features/chat/chat.component').then((m) => m.ChatComponent),
    data: { title: 'Product Recommendation & Comparison' },
  },
  {
    path: 'inventory',
    loadComponent: () =>
      import('./features/inventory/inventory.component').then(
        (m) => m.InventoryComponent
      ),
    data: { title: 'Sales Inventory' },
  },
  {
    path: 'incentives',
    loadComponent: () =>
      import('./features/incentives/incentives.component').then(
        (m) => m.IncentivesComponent
      ),
    data: { title: 'Incentives' },
  },
  {
    path: 'leads',
    loadComponent: () =>
      import('./features/leads/leads.component').then((m) => m.LeadsComponent),
    data: { title: 'Leads' },
  },
  {
    path: 'underwriting',
    loadComponent: () =>
      import('./features/underwriting/underwriting.component').then(
        (m) => m.UnderwritingComponent
      ),
    data: { title: 'Underwriting Checks' },
  },
  {
    path: 'library',
    loadComponent: () =>
      import('./features/library/library.component').then(
        (m) => m.LibraryComponent
      ),
    data: { title: 'Library' },
  },
  { path: '**', redirectTo: '' },
];
