export type MessageAuthor = 'user' | 'bot';

export interface ChatMessage {
  id: string;
  author: MessageAuthor;
  content: string;
  timestamp: Date;
  /** Optional rich attachment rendered after the text */
  attachment?: ChatAttachment;
}

export type ChatAttachment =
  | { kind: 'product-cards'; products: InsuranceProduct[] }
  | { kind: 'underwriting'; documents: UnderwritingDoc[]; product: string }
  | { kind: 'quick-replies'; options: string[] };

export interface InsuranceProduct {
  id: string;
  name: string;
  carrier: string;
  type: 'Term' | 'Whole Life' | 'ULIP' | 'Endowment' | 'Pension';
  coverage: string;       // e.g. "₹1 Cr"
  tenure: string;         // e.g. "30 years"
  premium: string;        // e.g. "₹12,400 / year"
  rating: number;         // 0–5
  highlights: string[];
  recommended?: boolean;
}

export interface UnderwritingDoc {
  id: string;
  name: string;
  required: boolean;
  description: string;
  status?: 'pending' | 'received' | 'verified';
}

export interface QuickAction {
  id: string;
  label: string;
  icon?: string;
  prompt: string;
}

/**
 * A single conversation thread the user can resume.
 * The Product Recommendation screen keeps up to 5 of these.
 */
export interface ChatSession {
  id: string;
  /** Auto-generated from the first user message, or user-renamed */
  title: string;
  createdAt: Date;
  updatedAt: Date;
  messages: ChatMessage[];
}
