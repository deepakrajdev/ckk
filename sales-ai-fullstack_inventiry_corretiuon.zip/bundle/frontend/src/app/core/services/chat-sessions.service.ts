import { Injectable, computed, inject, signal } from '@angular/core';
import { firstValueFrom } from 'rxjs';

import {
  ChatMessage,
  ChatSession,
} from '../models/chat.model';
import { ApiService, IntakeProfile, rehydrateSession } from './api.service';

/**
 * Sessions store — thin client over the FastAPI backend.
 *
 * UI components read signals (sessions, active, messages, loading) and call
 * mutation methods (selectSession, startNewSession, sendUserMessage).
 * Every mutation round-trips through HTTP; local state is updated
 * optimistically where it improves perceived latency.
 */
@Injectable({ providedIn: 'root' })
export class ChatSessionsService {
  private readonly api = inject(ApiService);

  /** All loaded sessions, newest first (mirrors the server cap of 5). */
  private readonly _sessions = signal<ChatSession[]>([]);
  /** Active session id. */
  private readonly _activeId = signal<string>('');
  /** True while we're fetching sessions / a specific session. */
  private readonly _loading = signal<boolean>(true);
  /** True while we're awaiting a bot reply. */
  private readonly _sending = signal<boolean>(false);
  /** Last error message (for surfacing in the UI). */
  private readonly _error = signal<string | null>(null);

  // ---- Public readonly signals ----

  readonly sessions = this._sessions.asReadonly();
  readonly activeId = this._activeId.asReadonly();
  readonly loading  = this._loading.asReadonly();
  readonly sending  = this._sending.asReadonly();
  readonly error    = this._error.asReadonly();

  readonly active = computed<ChatSession | undefined>(() => {
    const id = this._activeId();
    return this._sessions().find((s) => s.id === id);
  });

  readonly messages = computed<ChatMessage[]>(() => this.active()?.messages ?? []);

  constructor() {
    void this.bootstrap();
  }

  /** Initial load — list sessions, then fetch the first one's full messages. */
  private async bootstrap(): Promise<void> {
    this._loading.set(true);
    this._error.set(null);
    try {
      const summaries = await firstValueFrom(this.api.listSessions());
      if (summaries.length === 0) {
        // No sessions on the server — start a fresh one
        const fresh = await firstValueFrom(this.api.createSession());
        const rehydrated = rehydrateSession(fresh);
        this._sessions.set([rehydrated]);
        this._activeId.set(rehydrated.id);
        return;
      }
      // Load the first session's full content; keep the rest as summaries-with-empty-messages
      // until the user clicks them (loads on demand in selectSession).
      const first = await firstValueFrom(this.api.getSession(summaries[0]!.id));
      const firstFull = rehydrateSession(first);
      const remaining: ChatSession[] = summaries.slice(1).map((s) => ({
        id: s.id,
        title: s.title,
        createdAt: new Date(s.createdAt),
        updatedAt: new Date(s.updatedAt),
        messages: [],   // lazy-loaded
      }));
      this._sessions.set([firstFull, ...remaining]);
      this._activeId.set(firstFull.id);
    } catch (err) {
      this._error.set(this.toErrorMessage(err));
    } finally {
      this._loading.set(false);
    }
  }

  /** Switch to a different session. Lazy-loads its messages if not yet fetched. */
  async selectSession(id: string): Promise<void> {
    if (!this._sessions().some((s) => s.id === id)) return;
    this._activeId.set(id);
    const target = this._sessions().find((s) => s.id === id)!;
    if (target.messages.length === 0) {
      // Lazy load
      this._loading.set(true);
      this._error.set(null);
      try {
        const full = await firstValueFrom(this.api.getSession(id));
        const rehydrated = rehydrateSession(full);
        this._sessions.update((all) =>
          all.map((s) => (s.id === id ? rehydrated : s))
        );
      } catch (err) {
        this._error.set(this.toErrorMessage(err));
      } finally {
        this._loading.set(false);
      }
    }
  }

  /** Start a new conversation server-side and make it active. */
  async startNewSession(intake?: IntakeProfile): Promise<ChatSession | null> {
    this._loading.set(true);
    this._error.set(null);
    try {
      const created = await firstValueFrom(
        this.api.createSession(intake ? { intake } : undefined)
      );
      const rehydrated = rehydrateSession(created);
      // Server already enforces the cap; mirror it locally
      this._sessions.update((all) => [rehydrated, ...all].slice(0, 5));
      this._activeId.set(rehydrated.id);
      return rehydrated;
    } catch (err) {
      this._error.set(this.toErrorMessage(err));
      return null;
    } finally {
      this._loading.set(false);
    }
  }

  /** Send a user message and persist + display the bot reply. */
  async sendUserMessage(content: string): Promise<void> {
    const sessionId = this._activeId();
    if (!sessionId || !content.trim()) return;
    this._sending.set(true);
    this._error.set(null);
    try {
      const resp = await firstValueFrom(
        this.api.sendMessage(sessionId, content.trim())
      );
      const user = { ...resp.userMessage, timestamp: new Date(resp.userMessage.timestamp as any) };
      const bot  = { ...resp.botMessage,  timestamp: new Date(resp.botMessage.timestamp  as any) };
      this._sessions.update((all) =>
        all.map((s) =>
          s.id === sessionId
            ? {
                ...s,
                messages: [...s.messages, user, bot],
                updatedAt: new Date(),
                // Mirror server's auto-title behaviour
                title:
                  s.title === 'New conversation' && user.author === 'user'
                    ? this.titleFrom(user.content)
                    : s.title,
              }
            : s
        )
      );
    } catch (err) {
      this._error.set(this.toErrorMessage(err));
    } finally {
      this._sending.set(false);
    }
  }

  // ---- Helpers ----

  private titleFrom(content: string): string {
    const clean = content.replace(/\s+/g, ' ').trim();
    return clean.length > 48 ? clean.slice(0, 45).trimEnd() + '…' : clean;
  }

  private toErrorMessage(err: unknown): string {
    if (err instanceof Error) return err.message;
    if (typeof err === 'string') return err;
    try { return JSON.stringify(err); } catch { return 'Unknown error'; }
  }
}
