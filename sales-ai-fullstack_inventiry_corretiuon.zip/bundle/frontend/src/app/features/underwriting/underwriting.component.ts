import {
  ChangeDetectionStrategy,
  Component,
  computed,
  inject,
  signal,
} from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { firstValueFrom } from 'rxjs';

import {
  ApiService,
  FinancialSucEntry,
  RequestType,
  SucResponse,
} from '../../core/services/api.service';

type SectionId =
  | 'financial' | 'medicalNonDisclosure' | 'medicalDisclosure' | 'nonMedical';

interface TabMeta {
  id: SectionId;
  label: string;
  short: string;
  requestType: RequestType;
  accent: 'brand' | 'warn' | 'danger' | 'success';
}

interface TabState {
  product:    ReturnType<typeof signal<string>>;
  occupation: ReturnType<typeof signal<string>>;
  ageLimit:   ReturnType<typeof signal<string>>;
  products:    ReturnType<typeof signal<string[]>>;
  occupations: ReturnType<typeof signal<string[]>>;
  sucResp:     ReturnType<typeof signal<SucResponse | null>>;
  loadingProducts:    ReturnType<typeof signal<boolean>>;
  loadingOccupations: ReturnType<typeof signal<boolean>>;
  loadingSuc:         ReturnType<typeof signal<boolean>>;
  error:    ReturnType<typeof signal<string | null>>;
}

@Component({
  selector: 'app-underwriting',
  standalone: true,
  imports: [CommonModule, FormsModule],
  changeDetection: ChangeDetectionStrategy.OnPush,
  templateUrl: './underwriting.component.html',
})
export class UnderwritingComponent {
  private readonly api = inject(ApiService);

  // ============================================================
  // Tabs — each maps to a request_type in the MongoDB collection
  // ============================================================
  protected readonly tabs: TabMeta[] = [
    { id: 'financial',            label: 'Financial',                short: 'Financial', requestType: 'Financial',              accent: 'brand'   },
    { id: 'medicalNonDisclosure', label: 'Medical · Non-Disclosure', short: 'Non-Disc.', requestType: 'Medical-Non Disclosure', accent: 'warn'    },
    { id: 'medicalDisclosure',    label: 'Medical · Disclosure',     short: 'Disclosure',requestType: 'Medical-Disclosure',     accent: 'danger'  },
    { id: 'nonMedical',           label: 'Non-Medical',              short: 'Non-Med.',  requestType: 'Non-Medical',            accent: 'success' },
  ];
  protected readonly activeSection = signal<SectionId>('financial');
  protected readonly activeTab = computed<TabMeta>(
    () => this.tabs.find((t) => t.id === this.activeSection())!
  );

  // ============================================================
  // Independent state for each tab so switches preserve selections
  // ============================================================
  private readonly states: Record<SectionId, TabState> = {
    financial:            this.makeState(),
    medicalNonDisclosure: this.makeState(),
    medicalDisclosure:    this.makeState(),
    nonMedical:           this.makeState(),
  };

  private makeState(): TabState {
    return {
      product:    signal<string>(''),
      occupation: signal<string>(''),
      ageLimit:   signal<string>(''),
      products:    signal<string[]>([]),
      occupations: signal<string[]>([]),
      sucResp:     signal<SucResponse | null>(null),
      loadingProducts:    signal(false),
      loadingOccupations: signal(false),
      loadingSuc:         signal(false),
      error: signal<string | null>(null),
    };
  }

  /** The currently-active tab's state — bound to the template. */
  protected readonly s = computed<TabState>(() => this.states[this.activeSection()]);

  /** SUC entry matching the currently-selected ageLimit. */
  protected readonly selectedEntry = computed<FinancialSucEntry | null>(() => {
    const st = this.s();
    const ageLimit = st.ageLimit();
    if (!ageLimit) return null;
    return st.sucResp()?.financialSuc.find((e) => e.ageLimit === ageLimit) ?? null;
  });

  protected readonly availableAgeLimits = computed<string[]>(() =>
    this.s().sucResp()?.financialSuc.map((e) => e.ageLimit) ?? []
  );

  protected readonly step1Complete = computed(
    () => this.s().product() !== '' && this.s().occupation() !== ''
  );
  protected readonly step2Complete = computed(() => this.s().ageLimit() !== '');

  // ============================================================
  // Tab switching — load products for the new tab if not already loaded
  // ============================================================
  constructor() { void this.activateTab('financial'); }

  protected async activateTab(id: SectionId): Promise<void> {
    this.activeSection.set(id);
    const st = this.states[id];
    if (st.products().length === 0) {
      await this.fetchProducts(id);
    }
  }

  // ============================================================
  // A/B  ·  Fetch products for the current tab's requestType
  // ============================================================
  private async fetchProducts(id: SectionId): Promise<void> {
    const st = this.states[id];
    const tab = this.tabs.find((t) => t.id === id)!;
    st.loadingProducts.set(true); st.error.set(null);
    try {
      const resp = await firstValueFrom(this.api.listProducts(tab.requestType));
      st.products.set(resp.products);
    } catch (err) {
      st.error.set(err instanceof Error ? err.message : 'Failed to load products');
    } finally {
      st.loadingProducts.set(false);
    }
  }

  // ============================================================
  // C  ·  User picked a product — fetch occupations
  // ============================================================
  protected async onProductChange(value: string): Promise<void> {
    const st = this.s();
    const tab = this.activeTab();
    st.product.set(value);
    // ★ Cascading reset
    st.occupation.set(''); st.ageLimit.set('');
    st.occupations.set([]); st.sucResp.set(null);
    st.error.set(null);

    if (!value) return;
    st.loadingOccupations.set(true);
    try {
      const resp = await firstValueFrom(
        this.api.listOccupations(value, tab.requestType)
      );
      st.occupations.set(resp.occupations);
    } catch (err) {
      st.error.set(err instanceof Error ? err.message : 'Failed to load occupations');
    } finally {
      st.loadingOccupations.set(false);
    }
  }

  // ============================================================
  // D  ·  User picked an occupation — fetch SUC array
  // ============================================================
  protected async onOccupationChange(value: string): Promise<void> {
    const st = this.s();
    const tab = this.activeTab();
    st.occupation.set(value);
    st.ageLimit.set(''); st.sucResp.set(null); st.error.set(null);

    if (!value || !st.product()) return;
    st.loadingSuc.set(true);
    try {
      st.sucResp.set(await firstValueFrom(
        this.api.getSuc(st.product(), tab.requestType, value)
      ));
    } catch (err) {
      st.error.set(err instanceof Error ? err.message : 'Failed to load SUC bands');
    } finally {
      st.loadingSuc.set(false);
    }
  }

  // ============================================================
  // User picked an Age Limit — purely client-side filter of the SUC array
  // ============================================================
  protected onAgeLimitChange(value: string): void {
    this.s().ageLimit.set(value);
  }

  // ============================================================
  // Reset the current tab
  // ============================================================
  protected resetTab(): void {
    const st = this.s();
    st.product.set(''); st.occupation.set(''); st.ageLimit.set('');
    st.occupations.set([]); st.sucResp.set(null); st.error.set(null);
  }
}
