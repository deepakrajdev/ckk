import {
  ChangeDetectionStrategy,
  Component,
  computed,
  inject,
  signal,
} from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { firstValueFrom } from 'rxjs';

import {
  ApiService,
  FlsInventoryCounts,
  InventoryOverviewResponse,
  PolicyLookupRow,
  PolicyStatus,
} from '../../core/services/api.service';

type Tab = 'overview' | 'lookup';

interface StatusMeta {
  status: PolicyStatus;
  key: keyof Pick<
    FlsInventoryCounts,
    'freshBusiness' | 'newBusiness' | 'pendingUw' | 'pfr' | 'rfi' | 'na'
  >;
  short: string;        // for narrow mobile cells
  bg: string;
  text: string;
  ring: string;
  dot: string;
}

@Component({
  selector: 'app-inventory',
  standalone: true,
  imports: [CommonModule, FormsModule],
  changeDetection: ChangeDetectionStrategy.OnPush,
  templateUrl: './inventory.component.html',
})
export class InventoryComponent {
  private readonly api = inject(ApiService);

  // ───── Tabs ─────
  protected readonly tab = signal<Tab>('overview');

  // ───── Policy Overview ─────
  protected readonly overview = signal<InventoryOverviewResponse | null>(null);
  protected readonly overviewLoading = signal(false);
  protected readonly overviewError = signal<string | null>(null);

  /** Toggle for the per-FLS breakdown (CBM/CBH/ZBH only). */
  protected readonly showFlsBreakdown = signal(false);

  /** Drill-down — which status tile is currently selected (if any). */
  protected readonly drillStatus = signal<PolicyStatus | null>(null);

  // ───── Policy Lookup ─────
  protected readonly lookupQuery = signal<string>('');
  protected readonly lookupResults = signal<PolicyLookupRow[]>([]);
  protected readonly lookupLoading = signal(false);
  protected readonly lookupError = signal<string | null>(null);
  protected readonly hasSearched = signal(false);

  // ───── Status display metadata (ordering + colours) ─────
  protected readonly STATUS_META: StatusMeta[] = [
    { status: 'Fresh Business', key: 'freshBusiness', short: 'Fresh',  bg: 'bg-blue-50',   text: 'text-blue-700',   ring: 'border-blue-200',   dot: 'bg-blue-500'   },
    { status: 'New Business',   key: 'newBusiness',   short: 'New',    bg: 'bg-violet-50', text: 'text-violet-700', ring: 'border-violet-200', dot: 'bg-violet-500' },
    { status: 'Pending UW',     key: 'pendingUw',     short: 'UW',     bg: 'bg-amber-50',  text: 'text-amber-700',  ring: 'border-amber-200',  dot: 'bg-amber-500'  },
    { status: 'PFR',            key: 'pfr',           short: 'PFR',    bg: 'bg-orange-50', text: 'text-orange-700', ring: 'border-orange-200', dot: 'bg-orange-500' },
    { status: 'RFI',            key: 'rfi',           short: 'RFI',    bg: 'bg-rose-50',   text: 'text-rose-700',   ring: 'border-rose-200',   dot: 'bg-rose-500'   },
    { status: 'NA',             key: 'na',            short: 'NA',     bg: 'bg-ink-100',   text: 'text-ink-600',    ring: 'border-ink-200',    dot: 'bg-ink-400'    },
  ];

  /** Show the "FLS breakdown" toggle only for hierarchical user types. */
  protected readonly hasFlsBreakdown = computed(() => {
    const t = this.overview()?.userType;
    return t === 'CBM' || t === 'CBH' || t === 'ZBH';
  });

  constructor() { void this.loadOverview(); }

  // ╭───────────────────────────╮
  // │ Policy Overview           │
  // ╰───────────────────────────╯

  private async loadOverview(): Promise<void> {
    this.overviewLoading.set(true);
    this.overviewError.set(null);
    try {
      this.overview.set(await firstValueFrom(this.api.inventoryOverview()));
    } catch (err) {
      this.overviewError.set(
        err instanceof Error ? err.message : 'Failed to load overview'
      );
    } finally {
      this.overviewLoading.set(false);
    }
  }

  protected toggleFlsBreakdown(): void {
    this.showFlsBreakdown.update((v) => !v);
  }

  /** Click a status tile — toggles drill-down highlight on the FLS table. */
  protected onTileClick(status: PolicyStatus): void {
    if (this.drillStatus() === status) {
      this.drillStatus.set(null);
    } else {
      this.drillStatus.set(status);
      // Auto-open the breakdown if user clicked a tile (only for CBM/CBH/ZBH)
      if (this.hasFlsBreakdown()) this.showFlsBreakdown.set(true);
    }
  }

  protected countFor(row: FlsInventoryCounts, key: StatusMeta['key']): number {
    return row[key];
  }

  // ╭───────────────────────────╮
  // │ Policy Lookup             │
  // ╰───────────────────────────╯

  protected async runSearch(): Promise<void> {
    const q = this.lookupQuery().trim();
    if (!q) return;
    this.lookupLoading.set(true);
    this.lookupError.set(null);
    this.hasSearched.set(true);
    try {
      const resp = await firstValueFrom(this.api.policyLookup(q));
      this.lookupResults.set(resp.results);
    } catch (err) {
      this.lookupError.set(
        err instanceof Error ? err.message : 'Search failed'
      );
      this.lookupResults.set([]);
    } finally {
      this.lookupLoading.set(false);
    }
  }

  protected clearLookup(): void {
    this.lookupQuery.set('');
    this.lookupResults.set([]);
    this.hasSearched.set(false);
    this.lookupError.set(null);
  }

  /** Look up styling for a status pill in the lookup results. */
  protected metaFor(status: PolicyStatus): StatusMeta {
    return this.STATUS_META.find((s) => s.status === status) ?? this.STATUS_META[0];
  }
}
