import {
  ChangeDetectionStrategy,
  Component,
  EventEmitter,
  Input,
  Output,
  input,
} from '@angular/core';
import { CommonModule } from '@angular/common';
import { ChatSession } from '../../../core/models/chat.model';

export type SessionsVariant = 'sidebar' | 'overlay';

@Component({
  selector: 'app-chat-sessions',
  standalone: true,
  imports: [CommonModule],
  changeDetection: ChangeDetectionStrategy.OnPush,
  templateUrl: './chat-sessions.component.html',
})
export class ChatSessionsComponent {
  /** All sessions to render (newest first). */
  readonly sessions = input.required<ChatSession[]>();

  /** Currently-active session id. */
  readonly activeId = input.required<string>();

  /**
   * 'sidebar' — permanent left column (desktop)
   * 'overlay' — slide-down panel that can be dismissed (mobile)
   */
  readonly variant = input<SessionsVariant>('sidebar');

  /** User clicked a session row */
  @Output() select = new EventEmitter<string>();

  /** User clicked "+ New" */
  @Output() newSession = new EventEmitter<void>();

  /** User tapped the close button (overlay variant only) */
  @Output() close = new EventEmitter<void>();

  /** Short preview of the last meaningful message in the session. */
  protected previewOf(s: ChatSession): string {
    const last = [...s.messages].reverse().find((m) => m.content?.trim().length);
    if (!last) return 'No messages yet';
    const text = last.content.replace(/\s+/g, ' ').trim();
    return text.length > 70 ? text.slice(0, 67) + '…' : text;
  }
}
