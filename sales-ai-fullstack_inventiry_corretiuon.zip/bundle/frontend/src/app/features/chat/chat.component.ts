import {
  ChangeDetectionStrategy,
  Component,
  ElementRef,
  ViewChild,
  HostListener,
  effect,
  inject,
  signal,
} from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { Router } from '@angular/router';
import { InsuranceProduct, QuickAction } from '../../core/models/chat.model';
import { ChatSessionsService } from '../../core/services/chat-sessions.service';
import { ChatSessionsComponent } from './chat-sessions/chat-sessions.component';

@Component({
  selector: 'app-chat',
  standalone: true,
  imports: [CommonModule, FormsModule, ChatSessionsComponent],
  changeDetection: ChangeDetectionStrategy.OnPush,
  templateUrl: './chat.component.html',
})
export class ChatComponent {
  @ViewChild('scrollArea') private scrollArea?: ElementRef<HTMLDivElement>;

  protected readonly sessionsSvc = inject(ChatSessionsService);
  private readonly router = inject(Router);

  protected draft = '';
  protected readonly isTyping = this.sessionsSvc.sending;

  /** Mobile sessions panel open/closed */
  protected readonly mobileSessionsOpen = signal(false);

  protected readonly quickActions: QuickAction[] = [
    { id: 'q1', label: 'Compare term plans',     icon: '📊', prompt: 'Compare top term insurance plans for a 35-year-old non-smoker with ₹1 Cr cover for 30 years.' },
    { id: 'q2', label: 'Best ULIP options',       icon: '📈', prompt: 'Show me the best ULIP options for long-term wealth creation.' },
    { id: 'q3', label: 'Underwriting checklist',  icon: '📋', prompt: 'What documents are needed for underwriting a ₹2 Cr term plan?' },
    { id: 'q4', label: 'Rider explainer',         icon: '🛡️', prompt: 'Explain critical illness and accidental death riders.' },
    { id: 'q5', label: 'Tax benefits 80C',        icon: '💸', prompt: 'Summarise tax benefits under 80C and 10(10D) for life insurance.' },
    { id: 'q6', label: 'Pension plans',           icon: '🏦', prompt: 'Recommend pension plans for a 45-year-old.' },
  ];

  // ★★★ AUTO-SCROLL FIX ★★★
  // Previously this used AfterViewChecked + an `autoScroll` flag, which raced
  // Angular's change detection — the bot reply could land but the scroll
  // fired before the DOM had the new content height.
  //
  // The new approach uses a signal effect plus a queueMicrotask +
  // requestAnimationFrame chain so the scroll runs AFTER the browser
  // has laid out the new content. Also adds "smart" scrolling so users
  // who've scrolled up to read history aren't yanked back down.
  private prevActiveId: string | null = null;

  constructor() {
    effect(() => {
      const activeId = this.sessionsSvc.activeId();
      // Reading these signals registers them as dependencies — any change
      // to messages or typing state re-runs this effect.
      this.sessionsSvc.messages();
      this.sessionsSvc.sending();

      const sessionChanged = activeId !== this.prevActiveId;
      this.prevActiveId = activeId;

      // queueMicrotask → after Angular's DOM update
      // requestAnimationFrame → after the browser's next paint/layout
      queueMicrotask(() => {
        requestAnimationFrame(() => this.scrollToBottom(sessionChanged));
      });
    });
  }

  /**
   * Force-scroll on session switch, otherwise only auto-scroll when the
   * user is already near the bottom (within 200 px) — preserves the
   * scroll position when reading older messages.
   */
  private scrollToBottom(force: boolean): void {
    const el = this.scrollArea?.nativeElement;
    if (!el) return;

    if (force) {
      el.scrollTop = el.scrollHeight;
      return;
    }
    const distanceFromBottom = el.scrollHeight - el.scrollTop - el.clientHeight;
    if (distanceFromBottom < 200) {
      el.scrollTop = el.scrollHeight;
    }
  }

  // -------- Session interaction -------------------------------------

  protected async onSelectSession(id: string): Promise<void> {
    await this.sessionsSvc.selectSession(id);
    this.mobileSessionsOpen.set(false);
  }

  protected async onNewSession(): Promise<void> {
    this.mobileSessionsOpen.set(false);
    // Day-one journey: every new session starts from the intake form.
    await this.router.navigate(['/assistant']);
  }

  protected toggleMobileSessions(): void {
    this.mobileSessionsOpen.update((v) => !v);
  }

  @HostListener('document:keydown.escape')
  onEscape(): void {
    if (this.mobileSessionsOpen()) this.mobileSessionsOpen.set(false);
  }

  // -------- Chat interaction ----------------------------------------

  protected async send(): Promise<void> {
    const text = this.draft.trim();
    if (!text) return;
    this.draft = '';
    await this.sessionsSvc.sendUserMessage(text);
  }

  protected async sendQuick(q: QuickAction): Promise<void> {
    await this.sessionsSvc.sendUserMessage(q.prompt);
  }

  protected onEnter(e: Event): void {
    const ev = e as KeyboardEvent;
    if (!ev.shiftKey) {
      ev.preventDefault();
      void this.send();
    }
  }

  protected async onAskUnderwriting(p: InsuranceProduct): Promise<void> {
    await this.sessionsSvc.sendUserMessage(
      `What underwriting documents are required for ${p.name}?`
    );
  }
}
