import { ChangeDetectionStrategy, Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterLink } from '@angular/router';

interface ModuleTile {
  id: string;
  label: string;
  description: string;
  route: string;
  /** Tailwind classes for the icon panel — gives each tile a distinct accent. */
  accent: string;
  /** 24x24 SVG path */
  icon: string;
  cta: string;
}

@Component({
  selector: 'app-welcome',
  standalone: true,
  imports: [CommonModule, RouterLink],
  changeDetection: ChangeDetectionStrategy.OnPush,
  templateUrl: './welcome.component.html',
})
export class WelcomeComponent {
  protected readonly tiles: ModuleTile[] = [
    {
      id: 'assistant',
      label: 'Product Recommendation & Comparison',
      description:
        'Capture the prospect profile, get AI-matched products, and run side-by-side comparisons with premium illustrations.',
      route: '/assistant',
      accent: 'bg-brand-100 text-brand-700',
      icon:
        'M9 11.5a2.5 2.5 0 1 1 5 0 2.5 2.5 0 0 1-5 0Zm-6 7.75A7.25 7.25 0 0 1 10.25 12h3.5A7.25 7.25 0 0 1 21 19.25V21H3v-1.75ZM12 2 4 5v6c0 5 3.4 9.1 8 10 4.6-.9 8-5 8-10V5l-8-3Z',
      cta: 'Start a new conversation',
    },
    {
      id: 'inventory',
      label: 'Sales Inventory',
      description:
        'Track your FLS pipeline — submissions, underwriting stage, issuance progress and total NOP at a glance.',
      route: '/inventory',
      accent: 'bg-accent-100 text-accent-700',
      icon: 'M3 7l9-4 9 4-9 4-9-4Zm0 5 9 4 9-4M3 17l9 4 9-4',
      cta: 'View pipeline',
    },
    {
      id: 'incentives',
      label: 'Incentives',
      description:
        'Live commission and contest progress — see how close you are to the next tier and what to prioritise this quarter.',
      route: '/incentives',
      accent: 'bg-success-50 text-success-600',
      icon:
        'M12 2v3m0 14v3M4.22 4.22l2.12 2.12m11.32 11.32 2.12 2.12M2 12h3m14 0h3M4.22 19.78l2.12-2.12M17.66 6.34l2.12-2.12M12 7a5 5 0 1 1 0 10 5 5 0 0 1 0-10Z',
      cta: 'Track earnings',
    },
    {
      id: 'underwriting',
      label: 'Underwriting Checks',
      description:
        'Reference tables for Financial, Medical (Disclosure / Non-Disclosure) and Non-Medical / VMER requirements.',
      route: '/underwriting',
      accent: 'bg-warn-50 text-warn-600',
      icon: 'M9 12l2 2 4-4M21 12c0 5-3.5 9-9 9-5.5 0-9-4-9-9 0-5 3.5-9 9-9 5.5 0 9 4 9 9z',
      cta: 'Open the checklist',
    },
    {
      id: 'library',
      label: 'Library',
      description:
        'PDF knowledge base — underwriting manual, product handbooks, compliance checklists and training material.',
      route: '/library',
      accent: 'bg-danger-50 text-danger-600',
      icon: 'M4 19.5A2.5 2.5 0 0 1 6.5 17H20M6.5 2H20v20H6.5A2.5 2.5 0 0 1 4 19.5v-15A2.5 2.5 0 0 1 6.5 2z',
      cta: 'Browse documents',
    },
  ];
}
