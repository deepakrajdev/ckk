import { ChangeDetectionStrategy, Component, signal } from '@angular/core';
import { CommonModule } from '@angular/common';

type Stage = 'New' | 'Contacted' | 'Quoted' | 'Negotiating' | 'Closed';

interface Lead {
  id: string;
  initials: string;
  name: string;
  city: string;
  interest: string;
  potential: string;
  stage: Stage;
  nextAction: string;
  hot?: boolean;
}

@Component({
  selector: 'app-leads',
  standalone: true,
  imports: [CommonModule],
  changeDetection: ChangeDetectionStrategy.OnPush,
  templateUrl: './leads.component.html',
})
export class LeadsComponent {
  protected readonly stageFilters = ['All', 'New', 'Contacted', 'Quoted', 'Negotiating', 'Closed'] as const;
  protected readonly activeStage = signal<(typeof this.stageFilters)[number]>('All');

  private readonly leads: Lead[] = [
    { id: 'l1', initials: 'AP', name: 'Anita Pillai',  city: 'Bengaluru', interest: 'Term ₹1 Cr',  potential: '₹14,800/yr', stage: 'Quoted',      nextAction: 'Send revised quote · today', hot: true },
    { id: 'l2', initials: 'KM', name: 'Karan Mehta',   city: 'Mumbai',    interest: 'ULIP ₹50k/mo',potential: '₹6,00,000/yr',stage: 'Negotiating', nextAction: 'Schedule call · tomorrow 11 AM' },
    { id: 'l3', initials: 'RS', name: 'Riya Sharma',   city: 'Delhi',     interest: 'Pension Plan',potential: '₹1,20,000/yr',stage: 'Contacted',   nextAction: 'Follow-up email · Wednesday' },
    { id: 'l4', initials: 'VG', name: 'Vikram Gupta',  city: 'Pune',      interest: 'Term ₹2 Cr',  potential: '₹26,400/yr', stage: 'New',         nextAction: 'First contact · today', hot: true },
    { id: 'l5', initials: 'SN', name: 'Sneha Nair',    city: 'Kochi',     interest: 'Endowment',   potential: '₹48,000/yr', stage: 'Closed',      nextAction: 'Policy issued · Jun 12' },
    { id: 'l6', initials: 'AB', name: 'Arjun Bose',    city: 'Kolkata',   interest: 'Term + CI Rider', potential: '₹18,200/yr', stage: 'Quoted', nextAction: 'Awaiting decision · 3 days' },
    { id: 'l7', initials: 'MJ', name: 'Meera Joshi',   city: 'Ahmedabad', interest: 'Child Plan',  potential: '₹72,000/yr', stage: 'Contacted',   nextAction: 'Send brochure · today' },
  ];

  protected readonly filtered = () => {
    const s = this.activeStage();
    return s === 'All' ? this.leads : this.leads.filter((l) => l.stage === s);
  };

  protected countFor(s: (typeof this.stageFilters)[number]): number {
    return s === 'All' ? this.leads.length : this.leads.filter((l) => l.stage === s).length;
  }

  /** Deterministic gradient per initials for visual variety */
  protected avatarGradient(initials: string): string {
    const palettes = [
      'linear-gradient(135deg, #1f3fea, #1c2a85)',
      'linear-gradient(135deg, #f59e0b, #b45309)',
      'linear-gradient(135deg, #10b981, #059669)',
      'linear-gradient(135deg, #ef4444, #b91c1c)',
      'linear-gradient(135deg, #8b5cf6, #6d28d9)',
      'linear-gradient(135deg, #ec4899, #be185d)',
    ];
    const code = initials.charCodeAt(0) + initials.charCodeAt(1 % initials.length);
    return palettes[code % palettes.length]!;
  }
}
