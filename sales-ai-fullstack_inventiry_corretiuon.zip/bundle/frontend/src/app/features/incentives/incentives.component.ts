import {
  ChangeDetectionStrategy,
  Component,
  computed,
  inject,
  signal,
} from '@angular/core';
import { CommonModule } from '@angular/common';
import { firstValueFrom } from 'rxjs';

import {
  ApiService,
  IncentiveDashboard,
} from '../../core/services/api.service';

@Component({
  selector: 'app-incentives',
  standalone: true,
  imports: [CommonModule],
  changeDetection: ChangeDetectionStrategy.OnPush,
  templateUrl: './incentives.component.html',
})
export class IncentivesComponent {
  private readonly api = inject(ApiService);

  protected readonly dashboard = signal<IncentiveDashboard | null>(null);
  protected readonly loading = signal(false);
  protected readonly error = signal<string | null>(null);

  constructor() { void this.load(); }

  private async load(): Promise<void> {
    this.loading.set(true);
    this.error.set(null);
    try {
      this.dashboard.set(await firstValueFrom(this.api.incentiveDashboard()));
    } catch (err) {
      this.error.set(err instanceof Error ? err.message : 'Failed to load dashboard');
    } finally {
      this.loading.set(false);
    }
  }

  protected retry(): void { void this.load(); }

  // ───── Formatters ─────

  protected formatInr(amount: number): string {
    if (amount >= 1_00_00_000) return `₹${(amount / 1_00_00_000).toFixed(2)} Cr`;
    if (amount >= 1_00_000)    return `₹${(amount / 1_00_000).toFixed(2)} L`;
    if (amount >= 1_000)       return `₹${(amount / 1_000).toFixed(1)} K`;
    return `₹${amount.toLocaleString('en-IN', { maximumFractionDigits: 0 })}`;
  }

  /** Compact full-amount (₹4,12,500) for places where the L/Cr summary isn't enough. */
  protected formatInrFull(amount: number): string {
    return `₹${Math.round(amount).toLocaleString('en-IN')}`;
  }

  /**
   * Achievement-percentage colour band — mirrors the threshold tiers.
   * <75 = danger (red), 75-89 = warn (amber), 90-99 = brand (blue),
   * 100+ = success (green).
   */
  protected achievementClass(pct: number): {
    bar: string; text: string; bg: string;
  } {
    if (pct >= 100) return { bar: 'bg-success-500', text: 'text-success-600', bg: 'bg-success-50' };
    if (pct >= 90)  return { bar: 'bg-brand-500',   text: 'text-brand-700',   bg: 'bg-brand-50'  };
    if (pct >= 75)  return { bar: 'bg-warn-500',    text: 'text-warn-600',    bg: 'bg-warn-50'   };
    return                  { bar: 'bg-danger-500', text: 'text-danger-600', bg: 'bg-danger-50' };
  }

  /** Bar segment style for a given threshold percentage. */
  protected thresholdClass(pct: number): { bar: string; text: string } {
    if (pct === 100) return { bar: 'bg-success-500', text: 'text-success-600' };
    if (pct >= 90)   return { bar: 'bg-brand-500',   text: 'text-brand-700' };
    if (pct >= 80)   return { bar: 'bg-warn-500',    text: 'text-warn-600' };
    return                   { bar: 'bg-orange-500', text: 'text-orange-600' };
  }

  /** Width of the achievement bar inside a 100% threshold scale (capped at 100). */
  protected widthPct(pct: number): number {
    return Math.min(100, Math.max(0, pct));
  }
}
