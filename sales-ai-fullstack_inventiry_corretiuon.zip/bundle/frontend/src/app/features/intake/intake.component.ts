import { ChangeDetectionStrategy, Component, computed, inject, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { Router } from '@angular/router';

import {
  FinancialGoal,
  IntakeProfile,
  Occupation,
} from '../../core/services/api.service';
import { ChatSessionsService } from '../../core/services/chat-sessions.service';

@Component({
  selector: 'app-intake',
  standalone: true,
  imports: [CommonModule, FormsModule],
  changeDetection: ChangeDetectionStrategy.OnPush,
  templateUrl: './intake.component.html',
})
export class IntakeComponent {
  private readonly router = inject(Router);
  protected readonly sessionsSvc = inject(ChatSessionsService);

  protected readonly financialGoals: FinancialGoal[] = [
    'Term',
    'Guaranteed Return',
    'Retirement',
    'Investment',
    'Annuity',
    'Education',
    'Wealth Creation',
  ];

  protected readonly occupations: Occupation[] = ['Salaried', 'Self-employed'];

  // Reactive form state via signals (no FormBuilder needed — keeps deps lean)
  protected readonly financialGoal = signal<FinancialGoal | ''>('');
  protected readonly age = signal<number | null>(null);
  protected readonly annualIncomeLakhs = signal<number | null>(null);
  protected readonly occupation = signal<Occupation | ''>('');
  protected readonly dependents = signal<number | null>(null);
  protected readonly tobaccoUse = signal<boolean | null>(null);

  /** True when financial goal is Term — drives visibility of the tobacco question. */
  protected readonly showTobaccoQuestion = computed(
    () => this.financialGoal() === 'Term'
  );

  protected readonly submitting = signal(false);
  protected readonly submitError = signal<string | null>(null);

  /** Form is valid when every required field is set (and tobacco when goal=Term). */
  protected readonly isValid = computed<boolean>(() => {
    const goal = this.financialGoal();
    const age = this.age();
    const income = this.annualIncomeLakhs();
    const occ = this.occupation();
    const deps = this.dependents();

    if (!goal || !occ) return false;
    if (age === null || age < 0 || age > 99) return false;
    if (income === null || income <= 0) return false;
    if (deps === null || deps < 0) return false;
    if (goal === 'Term' && this.tobaccoUse() === null) return false;
    return true;
  });

  /** True when at least one previous session exists — shows "Continue" shortcut. */
  protected readonly hasExistingSessions = computed(
    () => this.sessionsSvc.sessions().length > 0
  );

  protected onGoalChange(value: string): void {
    this.financialGoal.set(value as FinancialGoal);
    // Reset tobacco when goal switches away from Term
    if (value !== 'Term') this.tobaccoUse.set(null);
  }

  protected setTobacco(v: boolean): void {
    this.tobaccoUse.set(v);
  }

  protected continuePrevious(): void {
    void this.router.navigate(['/assistant/chat']);
  }

  protected async submit(): Promise<void> {
    if (!this.isValid() || this.submitting()) return;

    const intake: IntakeProfile = {
      financialGoal: this.financialGoal() as FinancialGoal,
      age: this.age()!,
      annualIncomeLakhs: this.annualIncomeLakhs()!,
      occupation: this.occupation() as Occupation,
      dependents: this.dependents()!,
      tobaccoUse: this.financialGoal() === 'Term' ? this.tobaccoUse() : null,
    };

    this.submitting.set(true);
    this.submitError.set(null);
    const created = await this.sessionsSvc.startNewSession(intake);
    this.submitting.set(false);

    if (created) {
      void this.router.navigate(['/assistant/chat']);
    } else {
      this.submitError.set(
        this.sessionsSvc.error() ?? 'Could not start a new session. Try again.'
      );
    }
  }
}
