# Sales AI Assistant — Life Insurance (Angular 18 + Tailwind v4)

A mobile-first sales-assistant app for life-insurance agents: AI chat for product comparison and underwriting checklists, a sales inventory view, an incentives dashboard, and a leads pipeline.

## Tech stack

| Layer            | Choice                                                |
| ---------------- | ----------------------------------------------------- |
| Framework        | **Angular 18** — standalone components + signals      |
| Styling          | **Tailwind CSS 4** — CSS-first config in `styles.css` |
| Routing          | Angular Router with lazy-loaded routes                |
| Change detection | `OnPush` everywhere                                   |
| Fonts            | Plus Jakarta Sans + Fraunces (Google Fonts)           |

## Why Tailwind v4 here

This project uses Tailwind **v4.1+**, which is a complete rewrite from v3:

- **No `tailwind.config.js`** — design tokens live in CSS inside an `@theme {}` block
- **Single import** — `@import "tailwindcss"` replaces the three `@tailwind` directives
- **New PostCSS plugin** — `@tailwindcss/postcss` (separate package)
- **Native CSS variables** — every token in `@theme` is exposed as a CSS variable (e.g. `var(--color-brand-600)`) and as a utility (`bg-brand-600`)
- **Automatic content detection** — no `content: [...]` array; v4 scans your project. The `@source` directive in `styles.css` is belt-and-braces for Angular's inline `.ts` templates
- **`@utility` directive** for custom helpers (used for `no-scrollbar`, `safe-top`, `safe-bottom`)
- **No `autoprefixer` needed** — built in

Where v4 differs from v3 in code:

- **`@apply` cannot reference other component classes** — each `.btn-*` variant restates its full chain
- **Default border color is `currentColor`** — `styles.css` restores the v3 default (`--color-ink-100`) globally so a bare `border` doesn't accidentally inherit text color
- **`outline-none` → `outline-hidden`** for the old "transparent outline" pattern; `outline-none` now truly removes the outline

## Project layout

```
.
├── .postcssrc.json               # @tailwindcss/postcss plugin registration
├── .npmrc                        # legacy-peer-deps=true (Angular CLI 18 peer-dep workaround)
├── angular.json                  # CLI workspace (font inlining disabled in prod by default)
├── package.json                  # No tailwind.config.js needed
└── src/
    ├── styles.css                # ★ All design tokens, base, components, utilities (v4 CSS-first)
    ├── index.html                # Fonts + viewport meta
    ├── main.ts                   # bootstrap
    └── app/
        ├── app.component.ts      # Root layout (topbar + sidebar + outlet)
        ├── app.config.ts         # Providers (router, animations)
        ├── app.routes.ts         # Lazy routes for all 4 sections
        ├── core/
        │   ├── models/chat.model.ts
        │   └── services/nav.service.ts
        ├── layout/
        │   ├── topbar/topbar.component.ts
        │   └── sidebar/sidebar.component.ts   # Overlay drawer (always)
        └── features/
            ├── chat/chat.component.ts         # Default route — AI assistant
            ├── inventory/inventory.component.ts
            ├── incentives/incentives.component.ts
            └── leads/leads.component.ts
```

## Getting started

```bash
# 1. Install dependencies
npm install

# 2. Run dev server (auto-opens browser)
npm start
#   → http://localhost:4200

# 3. Production build
npm run build
```

> Requires Node.js **18.19+** or **20.11+** (Angular 18 requirement).

## Design system at a glance

All defined in `src/styles.css` under `@theme {}`:

| Token group   | Example utility           | CSS variable                |
| ------------- | ------------------------- | --------------------------- |
| Brand (navy)  | `bg-brand-600`            | `--color-brand-600`         |
| Accent (gold) | `text-accent-500`         | `--color-accent-500`        |
| Ink (neutral) | `border-ink-100`          | `--color-ink-100`           |
| Surface       | `bg-surface-alt`          | `--color-surface-alt`       |
| Display font  | `font-display`            | `--font-display` (Fraunces) |
| Shadow        | `shadow-pop`              | `--shadow-pop`              |
| Animation     | `animate-slide-in-left`   | `--animate-slide-in-left`   |

Custom component classes (`.btn-primary`, `.card`, `.bubble-bot`, `.pill`, `.bg-grid`) are defined in `@layer components` and use `@apply` chains. Custom utilities (`.no-scrollbar`, `.safe-top`, `.safe-bottom`) use the new `@utility` directive.

## Mobile-first behaviour

- **Sidebar is an overlay drawer** on all viewports (per spec); hamburger toggles it, backdrop click + `Esc` close it
- **Chat composer** sticks to the bottom with horizontally scrollable quick-action chips above; safe-area padding for iOS notches
- **Inventory** table collapses to cards under 640 px
- **Lead avatars** use deterministic gradients (no images needed)

## Replacing mock data with a real API

The chat uses an in-memory `respond()` method in `chat.component.ts`. Swap it for an HTTP call:

```ts
import { inject } from '@angular/core';
import { HttpClient } from '@angular/common/http';

private http = inject(HttpClient);

private respond(prompt: string) {
  this.isTyping.set(true);
  this.http.post<ChatMessage>('/api/chat', { prompt }).subscribe((reply) => {
    this.isTyping.set(false);
    this.messages.update((all) => [...all, reply]);
  });
}
```

Add `provideHttpClient()` to `app.config.ts` and you're done.

## Adding a new sidebar section

1. Create a new standalone component under `src/app/features/<name>/`
2. Add a lazy route in `app.routes.ts`
3. Append a new entry to the `items` array in `nav.service.ts` (label, SVG path, route)

The sidebar renders dynamically from that array — no other changes needed.

## Production build notes

Font inlining is **disabled** in `angular.json` so the build doesn't fail in offline/CI environments that can't reach `fonts.googleapis.com`. Re-enable it by setting:

```jsonc
"optimization": { "fonts": { "inline": true } }
```

For local dev or any environment with internet access, font inlining is recommended for the small render-blocking penalty saved.
