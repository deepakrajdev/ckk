"""Service layer — chat engine, data store, seed data."""
