"""Incentives / earnings — targets vs achievement dashboard."""

from enum import Enum
from pydantic import Field
from .chat import Base


# ────────────────────────────────────────────────────────────────
# Threshold-tier shortfall — one tier per 75/80/85/90/95/100%
# ────────────────────────────────────────────────────────────────

class ShortfallTier(Base):
    """Distance from a specific achievement threshold."""
    threshold_pct: int          # 75, 80, 85, 90, 95, 100
    threshold_amount: float     # absolute amount needed to hit this threshold
    shortfall: float            # how much more to go (0 once reached)
    reached: bool               # True if current achievement >= threshold


# ────────────────────────────────────────────────────────────────
# Per-bucket KPIs
# ────────────────────────────────────────────────────────────────

class NewBusinessKPI(Base):
    target: float
    net_achievement: float
    achieved_pct: float
    shortfalls: list[ShortfallTier]


class FYRenewalKPI(Base):
    """First-Year Renewal collection."""
    collectible: float
    collection: float
    collection_pct: float
    shortfalls: list[ShortfallTier]


class NOPKPI(Base):
    """Number of Policies."""
    target: int
    net_nop: int
    achieved_pct: float


# ────────────────────────────────────────────────────────────────
# Incentive breakdown — the formula
# ────────────────────────────────────────────────────────────────

class IncentiveBreakdown(Base):
    """
    Final incentive computation:
        base_nb_incentive_amount
        * persistency_incentive_multiplier
        + final_nop_booster_amount
        - sqm_deduction
        = final_incentive_with_sqm
    """
    base_nb_incentive: float
    persistency_multiplier: float = Field(ge=0)
    final_nop_booster: float
    sqm_deduction: float
    final_incentive_with_sqm: float     # ★ hero figure


# ────────────────────────────────────────────────────────────────
# Top-level dashboard payload
# ────────────────────────────────────────────────────────────────

class IncentiveDashboard(Base):
    """Everything the Incentives screen needs, in one fetch."""
    period_label: str                   # e.g. "Q2 FY26"
    final_incentive: float              # mirrors breakdown.final_incentive_with_sqm
    new_business: NewBusinessKPI
    fy_renewal: FYRenewalKPI
    nop: NOPKPI
    breakdown: IncentiveBreakdown


# ────────────────────────────────────────────────────────────────
# Legacy types (kept so existing chat/seed/old endpoints still work)
# ────────────────────────────────────────────────────────────────

class IncentiveTag(str, Enum):
    active = "Active"
    closing_soon = "Closing soon"
    stretch = "Stretch"


class Incentive(Base):
    id: str
    title: str
    reward: str
    progress: int = Field(ge=0, le=100)
    current: str
    target: str
    deadline: str
    tag: IncentiveTag


class EarningsSummary(Base):
    period_label: str
    amount: str
    delta_pct: float
    delta_up: bool
    next_tier_label: str
    next_tier_amount: str
    next_tier_remaining: str
    current_tier_label: str
    progress_pct: int = Field(ge=0, le=100)
