"""Library — knowledge-base PDFs the agent can browse and open."""

from datetime import datetime
from enum import Enum
from .chat import Base


class LibraryCategory(str, Enum):
    products = "Products"
    underwriting = "Underwriting"
    compliance = "Compliance"
    training = "Training"
    tax = "Tax & Regulations"


class LibraryDocument(Base):
    id: str
    title: str
    description: str
    category: LibraryCategory
    pages: int
    size_kb: int                  # for the "234 KB" badge
    updated_at: datetime
    download_url: str             # e.g. "/static/pdfs/uw-manual.pdf"
