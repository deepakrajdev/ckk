"""Authenticated-user profile model."""

from .chat import Base


class UserProfile(Base):
    id: str
    name: str
    initials: str
    role: str
    email: str
