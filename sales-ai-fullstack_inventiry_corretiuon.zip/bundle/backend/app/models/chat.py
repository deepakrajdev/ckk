"""Chat, sessions, products & underwriting models."""

from datetime import datetime
from enum import Enum
from typing import Annotated, Literal, Union

from pydantic import BaseModel, ConfigDict, Field


def _camel(name: str) -> str:
    """snake_case -> camelCase (e.g. created_at -> createdAt)."""
    head, *tail = name.split("_")
    return head + "".join(w.capitalize() for w in tail)


class Base(BaseModel):
    """Base config: emit camelCase JSON, accept either when parsing."""
    model_config = ConfigDict(
        alias_generator=_camel,
        populate_by_name=True,
        ser_json_timedelta="iso8601",
    )


class MessageAuthor(str, Enum):
    user = "user"
    bot = "bot"


class InsuranceProductType(str, Enum):
    term = "Term"
    whole_life = "Whole Life"
    ulip = "ULIP"
    endowment = "Endowment"
    pension = "Pension"


class InsuranceProduct(Base):
    id: str
    name: str
    carrier: str
    type: InsuranceProductType
    coverage: str          # e.g. "₹1 Cr"
    tenure: str            # e.g. "30 yrs"
    premium: str           # e.g. "₹12,400/yr"
    rating: int = Field(ge=0, le=5)
    highlights: list[str]
    recommended: bool = False


class UnderwritingDoc(Base):
    id: str
    name: str
    required: bool
    description: str


# --- Discriminated union for ChatAttachment ---------------------------

class ProductCardsAttachment(Base):
    kind: Literal["product-cards"] = "product-cards"
    products: list[InsuranceProduct]


class UnderwritingAttachment(Base):
    kind: Literal["underwriting"] = "underwriting"
    product: str
    documents: list[UnderwritingDoc]


ChatAttachment = Annotated[
    Union[ProductCardsAttachment, UnderwritingAttachment],
    Field(discriminator="kind"),
]


# --- Messages & sessions ---------------------------------------------

class ChatMessage(Base):
    id: str
    author: MessageAuthor
    content: str
    timestamp: datetime
    attachment: ChatAttachment | None = None


class SessionSummary(Base):
    """Lightweight session row for the sessions list (no messages)."""
    id: str
    title: str
    created_at: datetime
    updated_at: datetime
    message_count: int
    last_message_preview: str


class ChatSession(Base):
    id: str
    title: str
    created_at: datetime
    updated_at: datetime
    messages: list[ChatMessage]


# --- Request / response bodies ---------------------------------------

class NewSessionRequest(Base):
    title: str | None = None  # if omitted, server auto-titles
    # When set, the backend uses it to seed the first user message and
    # immediately runs the chat engine on it for a contextual bot reply.
    # Forward-referenced as a string so this file stays free of cycles.
    intake: "IntakeProfile | None" = None


class NewMessageRequest(Base):
    content: str = Field(min_length=1, max_length=4000)


class NewMessageResponse(Base):
    """Returns BOTH the persisted user msg and the bot reply in one round-trip."""
    user_message: ChatMessage
    bot_message: ChatMessage


class QuickAction(Base):
    id: str
    label: str
    icon: str | None = None
    prompt: str


# Late import + rebuild to resolve the forward reference on NewSessionRequest.
from .intake import IntakeProfile  # noqa: E402

NewSessionRequest.model_rebuild()
