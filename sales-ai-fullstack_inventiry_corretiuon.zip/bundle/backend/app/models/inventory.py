"""Sales inventory — policy pipeline tracking."""

from enum import Enum
from .chat import Base


# ────────────────────────────────────────────────────────────────
# Status codes (the 6 buckets shown on the Policy Overview tiles)
# ────────────────────────────────────────────────────────────────

class PolicyStatus(str, Enum):
    fresh_business = "Fresh Business"
    new_business   = "New Business"
    pending_uw     = "Pending UW"
    pfr            = "PFR"
    rfi            = "RFI"
    na             = "NA"


# ────────────────────────────────────────────────────────────────
# User hierarchy — CBM / CBH / ZBH manage multiple FLS
# ────────────────────────────────────────────────────────────────

class UserType(str, Enum):
    fls = "FLS"   # Front-Line Sales (individual agent)
    cbm = "CBM"   # Cluster Business Manager
    cbh = "CBH"   # Cluster Business Head
    zbh = "ZBH"   # Zonal Business Head


# ────────────────────────────────────────────────────────────────
# Inventory counts — per FLS or aggregate
# ────────────────────────────────────────────────────────────────

class FlsInventoryCounts(Base):
    """
    Status counts for one FLS (or aggregate sum across all FLS).
    Keys mirror the JSON contract: fresh_business, new_business,
    pending_uw, pfr, rfi, na.
    """
    fls_id: str
    fls_name: str = ""              # display name (empty for the aggregate row)
    fresh_business: int = 0
    new_business: int = 0
    pending_uw: int = 0
    pfr: int = 0
    rfi: int = 0
    na: int = 0


class InventoryOverviewResponse(Base):
    """
    Full Policy-Overview payload.

    For FLS users:   inventory_details contains exactly 1 entry (themselves).
    For CBM/CBH/ZBH: inventory_details lists every FLS under them, and
                    `aggregate` is the sum across all of them.
    """
    user_id: str
    user_type: UserType
    user_manager_id: str = ""
    period_label: str = ""
    aggregate: FlsInventoryCounts            # sums across all FLS
    inventory_details: list[FlsInventoryCounts]


# ────────────────────────────────────────────────────────────────
# Policy lookup — flat-row search results
# ────────────────────────────────────────────────────────────────

class PolicyLookupRow(Base):
    """One row of the Policy Lookup search results."""
    proposal_application_id: str        # Proposal Number OR Application ID
    customer_name: str
    plan_name: str
    login_date: str                     # display, e.g. "20 Jul 2026"
    process_status: PolicyStatus
    pending_requirement: str            # pure text — what's blocking the next step


class PolicyLookupResponse(Base):
    query: str
    results: list[PolicyLookupRow]


# ────────────────────────────────────────────────────────────────
# Legacy types — kept so chat attachments / older seed still work
# ────────────────────────────────────────────────────────────────

class UnderwritingStage(str, Enum):
    submitted = "Submitted"
    medical = "Medical"
    in_review = "In Review"
    approved = "Approved"
    issued = "Issued"
    declined = "Declined"


class InventoryRow(Base):
    """Legacy FLS row — used by chat attachments & older seed paths."""
    id: str
    fls_id: str
    nop: int
    pfr: str
    underwriting_stage: UnderwritingStage
    submission: int
    issuance: int
    total_nop: int


class InventoryStat(Base):
    label: str
    value: str
    delta: str
    delta_up: bool
