"""
Underwriting Checks — MongoDB-collection-shaped models.

Each document represents one (product_type, request_type, occupation_type)
tuple with its list of SUC entries — matches the user's JSON:

    {
      "product_type": "I Select 360",
      "request_type": "Financial",
      "occupation_type": "Salaried",
      "financial_suc": [
        { "age_limit": "0-1Cr",
          "financial_requirement": [],
          "document_list": ["Doc1", "Doc2"] }
      ]
    }
"""

from typing import Literal
from .chat import Base


# Four tabs supported in the UI
RequestType = Literal[
    "Financial",
    "Medical-Non Disclosure",
    "Medical-Disclosure",
    "Non-Medical",
]


class FinancialSucEntry(Base):
    """One row inside a document's financial_suc array."""
    age_limit: str                       # e.g. "0-1Cr"
    financial_requirement: list[str]     # list of requirement notes (often empty)
    document_list: list[str]


class UnderwritingRecord(Base):
    """One document in the underwriting collection (MongoDB shape)."""
    product_type: str
    request_type: RequestType
    occupation_type: str
    financial_suc: list[FinancialSucEntry]


# ============================================================
# REST endpoint response shapes (one per dropdown level)
# ============================================================

class ProductsResponse(Base):
    """A/B: Plan-name dropdown — optionally filtered by request_type (tab)."""
    request_type: RequestType | None = None
    products: list[str]


class OccupationsResponse(Base):
    """C: Occupation dropdown for the chosen product+tab."""
    product_type: str
    request_type: RequestType
    occupations: list[str]


class SucResponse(Base):
    """D: Final response — financial_suc array for product+request+occupation."""
    product_type: str
    request_type: RequestType
    occupation_type: str
    financial_suc: list[FinancialSucEntry]


# Legacy bundle kept for backward compat (no longer used by the UI)
class UnderwritingChecksBundle(Base):
    """Flat list of every document in the collection."""
    documents: list[UnderwritingRecord]
