"""Leads / pipeline models."""

from enum import Enum
from .chat import Base


class LeadStage(str, Enum):
    new = "New"
    contacted = "Contacted"
    quoted = "Quoted"
    negotiating = "Negotiating"
    closed = "Closed"


class Lead(Base):
    id: str
    initials: str
    name: str
    city: str
    interest: str
    potential: str
    stage: LeadStage
    next_action: str
    hot: bool = False


class LeadCreate(Base):
    name: str
    city: str
    interest: str
    potential: str
    stage: LeadStage = LeadStage.new
    next_action: str = "First contact · today"
    hot: bool = False


class LeadUpdate(Base):
    stage: LeadStage | None = None
    next_action: str | None = None
    hot: bool | None = None
