"""
Prospect intake — submitted from the Product Recommendation entry form.

Captured once, then converted into the opening message of the chat session so
the engine can immediately recommend products tuned to the profile.
"""

from enum import Enum
from typing import Annotated

from pydantic import Field

from .chat import Base


class FinancialGoal(str, Enum):
    term = "Term"
    guaranteed_return = "Guaranteed Return"
    retirement = "Retirement"
    investment = "Investment"
    annuity = "Annuity"
    education = "Education"
    wealth_creation = "Wealth Creation"


class Occupation(str, Enum):
    salaried = "Salaried"
    self_employed = "Self-employed"


class IntakeProfile(Base):
    financial_goal: FinancialGoal
    age: Annotated[int, Field(ge=0, le=99)]
    annual_income_lakhs: Annotated[float, Field(gt=0, le=10_000)]   # in lakhs
    occupation: Occupation
    dependents: Annotated[int, Field(ge=0, le=20)]

    # Only set when financial_goal == Term.
    tobacco_use: bool | None = None
