"""Library endpoint — lists PDFs the agent can browse and open."""

from fastapi import APIRouter, Depends, HTTPException, Query, status

from app.models import LibraryCategory, LibraryDocument
from app.services.store import Store, get_store

router = APIRouter(prefix="/api/library", tags=["library"])


@router.get("", response_model=list[LibraryDocument])
async def list_documents(
    category: LibraryCategory | None = Query(None, description="Filter by category"),
    q: str | None = Query(None, description="Search across title and description"),
    store: Store = Depends(get_store),
) -> list[LibraryDocument]:
    """Returns library documents, optionally filtered."""
    return await store.list_library(category=category, q=q)


@router.get("/{document_id}", response_model=LibraryDocument)
async def get_document(
    document_id: str, store: Store = Depends(get_store)
) -> LibraryDocument:
    """Single document — useful if the frontend wants metadata before opening."""
    doc = await store.get_library(document_id)
    if doc is None:
        raise HTTPException(status.HTTP_404_NOT_FOUND, "Document not found")
    return doc
