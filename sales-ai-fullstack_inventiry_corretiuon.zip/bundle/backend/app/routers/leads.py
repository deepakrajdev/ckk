"""Leads / pipeline endpoints."""

from fastapi import APIRouter, Depends, HTTPException, Query, Response, status

from app.models import Lead, LeadCreate, LeadStage, LeadUpdate
from app.services.store import Store, get_store

router = APIRouter(prefix="/api/leads", tags=["leads"])


@router.get("", response_model=list[Lead])
async def list_leads(
    stage: LeadStage | None = Query(None, description="Filter by pipeline stage"),
    store: Store = Depends(get_store),
) -> list[Lead]:
    """Leads list, optionally filtered by stage."""
    return await store.list_leads(stage=stage)


@router.get("/counts", response_model=dict[str, int])
async def lead_counts(store: Store = Depends(get_store)) -> dict[str, int]:
    """Per-stage counts plus 'All' — drives the badge in each filter pill."""
    return await store.lead_counts()


@router.post(
    "",
    response_model=Lead,
    status_code=status.HTTP_201_CREATED,
)
async def create_lead(
    body: LeadCreate, store: Store = Depends(get_store)
) -> Lead:
    """Add a new lead (used by the 'Add lead' button on the leads screen)."""
    return await store.create_lead(body)


@router.patch("/{lead_id}", response_model=Lead)
async def update_lead(
    lead_id: str, body: LeadUpdate, store: Store = Depends(get_store)
) -> Lead:
    """Partial update — typically used to advance the pipeline stage."""
    lead = await store.update_lead(lead_id, body)
    if lead is None:
        raise HTTPException(status.HTTP_404_NOT_FOUND, "Lead not found")
    return lead


@router.delete("/{lead_id}", status_code=status.HTTP_204_NO_CONTENT)
async def delete_lead(
    lead_id: str, store: Store = Depends(get_store)
) -> Response:
    if not await store.delete_lead(lead_id):
        raise HTTPException(status.HTTP_404_NOT_FOUND, "Lead not found")
    return Response(status_code=status.HTTP_204_NO_CONTENT)
