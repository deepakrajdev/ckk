"""Incentives — targets vs achievement dashboard endpoints."""

from fastapi import APIRouter, Depends, Query

from app.models import (
    EarningsSummary,
    Incentive,
    IncentiveDashboard,
    IncentiveTag,
)
from app.services.store import Store, get_store

router = APIRouter(prefix="/api/incentives", tags=["incentives"])


# ============================================================
# ★ NEW — Targets / achievement / breakdown dashboard
# ============================================================

@router.get("/dashboard", response_model=IncentiveDashboard)
async def get_dashboard(
    store: Store = Depends(get_store),
) -> IncentiveDashboard:
    """
    Full Incentives screen payload:
      - New Business KPI with shortfall tiers at 75/80/85/90/95/100%
      - First-Year Renewal KPI with same tier ladder
      - NOP KPI
      - Breakdown: Base NB → × Persistency Multiplier → + NOP Booster
        → − SQM Deduction → Final Incentive Amount with SQM Penalty
    """
    return await store.incentive_dashboard()


# ============================================================
# Legacy endpoints — kept for backward compat
# ============================================================

@router.get("/summary", response_model=EarningsSummary)
async def earnings_summary(
    store: Store = Depends(get_store),
) -> EarningsSummary:
    return await store.earnings_summary()


@router.get("/contests", response_model=list[Incentive])
async def list_incentives(
    tag: IncentiveTag | None = Query(None),
    store: Store = Depends(get_store),
) -> list[Incentive]:
    return await store.list_incentives(tag=tag)
