"""Inventory — Policy Overview (FLS hierarchy) + Policy Lookup endpoints."""

from fastapi import APIRouter, Depends, Query

from app.models import (
    InventoryOverviewResponse,
    InventoryRow,
    InventoryStat,
    PolicyLookupResponse,
    UnderwritingStage,
)
from app.services.store import Store, get_store

router = APIRouter(prefix="/api/inventory", tags=["inventory"])


# ============================================================
# ★ Policy Overview tab (Flavor 1)
# ============================================================

@router.get("/overview", response_model=InventoryOverviewResponse)
async def get_overview(
    store: Store = Depends(get_store),
) -> InventoryOverviewResponse:
    """
    Returns the salesperson's policy overview:
      * aggregate counts (Fresh Business / New Business / Pending UW /
        PFR / RFI / NA) across every FLS reporting to the user, AND
      * the per-FLS breakdown so the user can drill down.

    For an FLS-type user, inventory_details has exactly 1 entry
    (themselves). For CBM / CBH / ZBH it contains every reporting FLS.
    """
    return await store.inventory_overview()


# ============================================================
# ★ Policy Lookup tab (Flavor 2)
# ============================================================

@router.get("/policy-lookup", response_model=PolicyLookupResponse)
async def policy_lookup(
    q: str = Query(
        ..., min_length=1,
        description="Proposal Number or Application ID (also matches customer/plan name)",
    ),
    store: Store = Depends(get_store),
) -> PolicyLookupResponse:
    """
    Search across the salesperson's pipeline by Proposal Number or
    Application ID and return rows with current status + the pending
    requirement text the agent needs to act on.
    """
    rows = await store.policy_lookup(q)
    return PolicyLookupResponse(query=q, results=rows)


# ============================================================
# Legacy endpoints — kept for chat-attachment / older UI calls
# ============================================================

@router.get("", response_model=list[InventoryRow])
async def list_inventory(
    stage: UnderwritingStage | None = Query(None),
    q: str | None = Query(None),
    store: Store = Depends(get_store),
) -> list[InventoryRow]:
    return await store.list_inventory(stage=stage, q=q)


@router.get("/stats", response_model=list[InventoryStat])
async def inventory_stats(
    store: Store = Depends(get_store),
) -> list[InventoryStat]:
    return await store.inventory_stats()
