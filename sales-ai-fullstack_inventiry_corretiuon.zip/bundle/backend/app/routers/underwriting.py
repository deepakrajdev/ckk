"""Underwriting Checks — REST endpoints backed by the MongoDB-shaped store.

Three endpoints support the cascading UI; each dropdown change in the UI
triggers a fresh server call (no client-side filtering of bulk data).
"""

from fastapi import APIRouter, Depends, Query

from app.models import (
    OccupationsResponse,
    ProductsResponse,
    RequestType,
    SucResponse,
    UnderwritingChecksBundle,
)
from app.services.store import Store, get_store

router = APIRouter(prefix="/api/underwriting", tags=["underwriting"])


# ============================================================
# A / B  ·  Products dropdown
#   - With no requestType: every distinct product in the collection
#   - With requestType:    only products that have documents for that tab
# ============================================================

@router.get("/products", response_model=ProductsResponse)
async def list_products(
    request_type: RequestType | None = Query(
        None,
        alias="requestType",
        description="Filter to products that have a doc for this tab",
    ),
    store: Store = Depends(get_store),
) -> ProductsResponse:
    products = await store.list_products(request_type=request_type)
    return ProductsResponse(request_type=request_type, products=products)


# ============================================================
# C  ·  Occupation dropdown — fired when the user picks a plan
# ============================================================

@router.get("/occupations", response_model=OccupationsResponse)
async def list_occupations(
    product_type: str = Query(..., alias="productType"),
    request_type: RequestType = Query(..., alias="requestType"),
    store: Store = Depends(get_store),
) -> OccupationsResponse:
    occupations = await store.list_occupations(
        product_type=product_type, request_type=request_type
    )
    return OccupationsResponse(
        product_type=product_type,
        request_type=request_type,
        occupations=occupations,
    )


# ============================================================
# D  ·  SUC + requirements + documents — fired when occupation is picked
# ============================================================

@router.get("/suc", response_model=SucResponse)
async def get_suc(
    product_type: str = Query(..., alias="productType"),
    request_type: RequestType = Query(..., alias="requestType"),
    occupation_type: str = Query(..., alias="occupationType"),
    store: Store = Depends(get_store),
) -> SucResponse:
    return await store.get_suc(
        product_type=product_type,
        request_type=request_type,
        occupation_type=occupation_type,
    )


# ============================================================
# Backward-compat — entire collection in one payload
# ============================================================

@router.get("/checks", response_model=UnderwritingChecksBundle)
async def get_checks(store: Store = Depends(get_store)) -> UnderwritingChecksBundle:
    return await store.underwriting_checks()
