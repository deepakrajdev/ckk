"""Sessions & chat-message endpoints."""

import asyncio
import uuid
from datetime import datetime, timezone

from fastapi import APIRouter, Depends, HTTPException, Response, status

from app.config import get_settings
from app.models import (
    ChatMessage,
    ChatSession,
    MessageAuthor,
    NewMessageRequest,
    NewMessageResponse,
    NewSessionRequest,
    SessionSummary,
)
from app.services.chat_engine import generate_reply
from app.services.store import Store, get_store

router = APIRouter(prefix="/api/sessions", tags=["sessions"])


@router.get("", response_model=list[SessionSummary])
async def list_sessions(store: Store = Depends(get_store)) -> list[SessionSummary]:
    """List the user's recent sessions (newest first, capped at MAX_SESSIONS)."""
    return await store.list_sessions()


@router.get("/{session_id}", response_model=ChatSession)
async def get_session(
    session_id: str, store: Store = Depends(get_store)
) -> ChatSession:
    """Full session with every message — used when the user taps a session row."""
    session = await store.get_session(session_id)
    if session is None:
        raise HTTPException(status.HTTP_404_NOT_FOUND, "Session not found")
    return session


@router.post(
    "",
    response_model=ChatSession,
    status_code=status.HTTP_201_CREATED,
)
async def create_session(
    body: NewSessionRequest, store: Store = Depends(get_store)
) -> ChatSession:
    """
    Start a new conversation. Returns the seeded session.

    If ``body.intake`` is present (from the Product Recommendation form),
    the session is preloaded with:
      • a user message restating the prospect profile
      • a bot reply produced by the chat engine — typically product cards
        for Term / ULIP / Pension goals, or a guiding question for others.
    Otherwise it gets the standard welcome bot message only.
    """
    title = body.title or (
        f"{body.intake.financial_goal.value} · {body.intake.age}y · "
        f"{body.intake.occupation.value}"
        if body.intake else None
    )
    session = await store.create_session(title=title)

    if body.intake is not None:
        from app.services.chat_engine import prompt_from_intake
        prompt = prompt_from_intake(body.intake)

        user_msg = ChatMessage(
            id=str(uuid.uuid4()),
            author=MessageAuthor.user,
            timestamp=datetime.now(timezone.utc),
            content=prompt,
        )
        await store.append_message(session.id, user_msg)

        bot_msg = generate_reply(prompt)
        updated = await store.append_message(session.id, bot_msg)
        if updated is not None:
            return updated

    return session


@router.delete("/{session_id}", status_code=status.HTTP_204_NO_CONTENT)
async def delete_session(
    session_id: str, store: Store = Depends(get_store)
) -> Response:
    deleted = await store.delete_session(session_id)
    if not deleted:
        raise HTTPException(status.HTTP_404_NOT_FOUND, "Session not found")
    return Response(status_code=status.HTTP_204_NO_CONTENT)


@router.post(
    "/{session_id}/messages",
    response_model=NewMessageResponse,
    status_code=status.HTTP_201_CREATED,
)
async def post_message(
    session_id: str,
    body: NewMessageRequest,
    store: Store = Depends(get_store),
) -> NewMessageResponse:
    """
    The core chat call:
      1. Persist the user message
      2. Run the chat engine
      3. Persist the bot reply
      4. Return both in a single payload
    """
    session = await store.get_session(session_id)
    if session is None:
        raise HTTPException(status.HTTP_404_NOT_FOUND, "Session not found")

    # 1. user message
    user_msg = ChatMessage(
        id=str(uuid.uuid4()),
        author=MessageAuthor.user,
        timestamp=datetime.now(timezone.utc),
        content=body.content,
    )
    await store.append_message(session_id, user_msg)

    # 2 & 3. simulated typing delay + bot reply
    settings = get_settings()
    if settings.response_delay_ms > 0:
        await asyncio.sleep(settings.response_delay_ms / 1000)

    bot_msg = generate_reply(body.content)
    await store.append_message(session_id, bot_msg)

    # 4. response
    return NewMessageResponse(user_message=user_msg, bot_message=bot_msg)
