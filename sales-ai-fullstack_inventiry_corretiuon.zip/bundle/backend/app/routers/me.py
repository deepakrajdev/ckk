"""Authenticated-user profile endpoint."""

from fastapi import APIRouter, Depends

from app.models import UserProfile
from app.services.store import Store, get_store

router = APIRouter(prefix="/api/me", tags=["me"])


@router.get("", response_model=UserProfile)
async def get_me(store: Store = Depends(get_store)) -> UserProfile:
    """Returns the signed-in advisor's profile (used by sidebar + topbar)."""
    return await store.me()
