"""FastAPI application entry-point."""

from pathlib import Path

from fastapi import FastAPI, HTTPException, status
from fastapi.middleware.cors import CORSMiddleware
from fastapi.staticfiles import StaticFiles

from app import __version__
from app.config import get_settings
from app.routers import (
    incentives,
    inventory,
    leads,
    library,
    me,
    sessions,
    underwriting,
)

settings = get_settings()

app = FastAPI(
    title="Sales AI Assistant API",
    version=__version__,
    description=(
        "Backend for the Sales AI Assistant (life-insurance). Pairs 1:1 with "
        "the Angular frontend: sessions/chat, inventory, incentives, leads, "
        "underwriting reference tables, library PDFs and user profile."
    ),
)

# -------- CORS --------------------------------------------------------

app.add_middleware(
    CORSMiddleware,
    allow_origins=settings.origins_list,
    allow_credentials=True,
    allow_methods=["GET", "POST", "PATCH", "PUT", "DELETE", "OPTIONS"],
    allow_headers=["*"],
)


# -------- Optional API-key middleware ---------------------------------

@app.middleware("http")
async def api_key_check(request, call_next):
    """If API_KEY is configured, require X-API-Key on /api/* (not /static/*)."""
    if (
        settings.api_key
        and request.url.path.startswith("/api/")
        and request.method != "OPTIONS"
    ):
        provided = request.headers.get("x-api-key")
        if provided != settings.api_key:
            raise HTTPException(
                status_code=status.HTTP_401_UNAUTHORIZED,
                detail="Missing or invalid X-API-Key",
            )
    return await call_next(request)


# -------- Static files (library PDFs) ---------------------------------

STATIC_DIR = Path(__file__).resolve().parent / "static"
if STATIC_DIR.exists():
    app.mount("/static", StaticFiles(directory=STATIC_DIR), name="static")


# -------- Health ------------------------------------------------------

@app.get("/health", tags=["meta"])
async def health() -> dict[str, str]:
    return {"status": "ok", "version": __version__}


# -------- Routers -----------------------------------------------------

app.include_router(sessions.router)
app.include_router(inventory.router)
app.include_router(incentives.router)
app.include_router(leads.router)
app.include_router(underwriting.router)
app.include_router(library.router)
app.include_router(me.router)
