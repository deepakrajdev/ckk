# Sales AI Assistant — FastAPI Backend

Companion backend for the Angular + Tailwind frontend. One endpoint per
frontend action, identical data shapes, ready to plug a real LLM and a real
database into.

## Tech stack

| Layer       | Choice                                               |
|-------------|------------------------------------------------------|
| Framework   | **FastAPI** (async, Python 3.11+)                    |
| Validation  | **Pydantic 2** with camelCase aliases                |
| Server      | **uvicorn** with auto-reload in dev                  |
| Persistence | In-memory `Store` class — swap for SQLAlchemy/Postgres in one file |

## What's in the box

```
app/
├── main.py                  # FastAPI app, CORS, optional API-key auth, router includes
├── config.py                # env-driven settings (pydantic-settings)
├── models/                  # Pydantic schemas matching the frontend types exactly
│   ├── chat.py              # ChatMessage, ChatSession, InsuranceProduct, UnderwritingDoc, ...
│   ├── inventory.py
│   ├── incentives.py
│   ├── leads.py
│   └── me.py
├── routers/                 # one file per resource
│   ├── sessions.py          # GET/POST/DELETE /api/sessions[/...]; POST /messages
│   ├── inventory.py
│   ├── incentives.py
│   ├── leads.py
│   └── me.py
└── services/
    ├── chat_engine.py       # bot-reply generator (mirrors the frontend mock)
    ├── store.py             # in-memory data layer (the swap point)
    └── seed.py              # initial demo data — same content as the frontend
```

## API surface — every frontend action

| Frontend interaction                                     | Method | Path                                  | Response                  |
|----------------------------------------------------------|--------|---------------------------------------|---------------------------|
| Topbar/sidebar reading the signed-in user                | GET    | `/api/me`                             | `UserProfile`             |
| Loading the sessions strip (chat screen, max 5)          | GET    | `/api/sessions`                       | `SessionSummary[]`        |
| User clicks a session → loads its full message history   | GET    | `/api/sessions/{id}`                  | `ChatSession`             |
| "+ New" / `New chat` button                              | POST   | `/api/sessions`                       | `ChatSession`             |
| (Optional) Delete a session                              | DELETE | `/api/sessions/{id}`                  | 204                       |
| User sends a message OR taps a quick-action chip         | POST   | `/api/sessions/{id}/messages`         | `{userMessage, botMessage}` |
| Inventory screen — filterable table                      | GET    | `/api/inventory?type=&status=&q=`     | `InventoryRow[]`          |
| Inventory KPI tiles                                      | GET    | `/api/inventory/stats`                | `InventoryStat[]`         |
| Incentives hero earnings card                            | GET    | `/api/incentives/summary`             | `EarningsSummary`         |
| Incentives contests grid                                 | GET    | `/api/incentives/contests?tag=`       | `Incentive[]`             |
| Leads list with stage filter                             | GET    | `/api/leads?stage=`                   | `Lead[]`                  |
| Stage filter pill counts                                 | GET    | `/api/leads/counts`                   | `{All:7, New:1, …}`       |
| "Add lead" button                                        | POST   | `/api/leads`                          | `Lead`                    |
| Advancing a lead's stage                                 | PATCH  | `/api/leads/{id}`                     | `Lead`                    |
| Removing a lead                                          | DELETE | `/api/leads/{id}`                     | 204                       |
| Health probe                                             | GET    | `/health`                             | `{status, version}`       |

OpenAPI docs auto-served at **/docs** (Swagger UI) and **/redoc**.

## Quickstart

```bash
# 1. Create & activate a virtualenv
python -m venv .venv
source .venv/bin/activate          # Windows: .venv\Scripts\activate

# 2. Install
pip install -r requirements.txt
#   or, if you prefer pyproject:  pip install -e .

# 3. (Optional) configure
cp .env.example .env               # tweak ALLOWED_ORIGINS, API_KEY, etc.

# 4. Run
uvicorn app.main:app --reload --port 8000

# → http://localhost:8000          API
# → http://localhost:8000/docs     Swagger UI
```

Make a quick call:

```bash
curl http://localhost:8000/api/sessions | jq
curl -X POST http://localhost:8000/api/sessions/sess-1/messages \
  -H 'Content-Type: application/json' \
  -d '{"content":"compare term plans"}' | jq
```

## Wiring the Angular frontend

The bundled frontend zip ships with an `ApiService` and is already wired to
`http://localhost:8000`. Start the backend, then the frontend — done.

To point the frontend at a different host (e.g. a deployed backend), set a
single global in `src/index.html` before the `<app-root>` tag:

```html
<script>window.__API_BASE_URL__ = 'https://api.example.com';</script>
```

`ApiService` reads that at bootstrap and falls back to `http://localhost:8000`.

## CORS

`ALLOWED_ORIGINS` in `.env` is a comma-separated list. The default permits
the Angular dev server on `http://localhost:4200` and `http://127.0.0.1:4200`.
Add your production origin before deploying.

## Optional API-key auth

Set `API_KEY` in `.env` to anything non-empty. Every `/api/*` request must
then carry `X-API-Key: <value>`. Leave blank for local dev. For real auth,
swap this middleware for OAuth2 / JWT — FastAPI has first-class support.

## Plugging in a real LLM

Open `app/services/chat_engine.py`. The `generate_reply(prompt)` function is
the only thing you replace. Return a fully-formed `ChatMessage` with an
optional `ProductCardsAttachment` or `UnderwritingAttachment` and every
router and frontend binding works unchanged.

Example sketch:

```python
from anthropic import Anthropic
client = Anthropic()

def generate_reply(prompt: str) -> ChatMessage:
    response = client.messages.create(
        model="claude-sonnet-4-5",
        max_tokens=2048,
        system="You are a life-insurance sales co-pilot...",
        messages=[{"role": "user", "content": prompt}],
    )
    text = response.content[0].text
    # ...optionally inspect text for product/underwriting intents and attach
    # rich payloads built from your product catalogue & underwriting rules
    return ChatMessage(
        id=str(uuid.uuid4()),
        author=MessageAuthor.bot,
        timestamp=datetime.now(timezone.utc),
        content=text,
    )
```

## Plugging in a real database

`app/services/store.py` is the only file to rewrite. Keep the `Store` class
signature (`async def list_sessions(...)`, `async def append_message(...)`,
etc.) and swap the dict bodies for SQLAlchemy / asyncpg queries. Every
router stays untouched because they only depend on the `Store` interface.

Suggested stack for production:

- **SQLAlchemy 2 + asyncpg** for Postgres
- **Alembic** for migrations
- **TimescaleDB** if you want metrics on top of the chat data
- **Redis** for session caching if `/api/sessions` becomes a hot path

## Running tests

```bash
pip install -e ".[dev]"
pytest
```

Add tests under `tests/`. The store-as-class design makes substituting a
fake store trivial via FastAPI's `app.dependency_overrides`.

## Production checklist

- [ ] Set `ALLOWED_ORIGINS` to your actual frontend URL(s)
- [ ] Set `API_KEY` and require it (or replace the middleware with proper auth)
- [ ] Swap `Store` for a real DB
- [ ] Swap `chat_engine.generate_reply` for an LLM call with retry/timeout
- [ ] Run uvicorn behind gunicorn: `gunicorn app.main:app -k uvicorn.workers.UvicornWorker -w 4`
- [ ] Put a reverse proxy (Caddy/nginx) in front for TLS + gzip
- [ ] Wire `/health` to your load balancer
