"""
PDF thumbnail generation.

Renders page 1 of each PDF to a JPG suitable for use as a library tile preview.
Run by `ensure_thumbnails()` at FastAPI startup — generates only missing files,
so it's cheap on subsequent boots and supports dropping in new PDFs.
"""

from __future__ import annotations

import logging
from pathlib import Path

log = logging.getLogger(__name__)

# Thumbnail dimensions — render width controls source resolution.
THUMB_WIDTH_PX = 480              # source render width (crisp on retina @ 240 CSS-px display)
THUMB_JPEG_QUALITY = 82           # good visual quality, ~25-40 KB per thumb
THUMB_SUFFIX = ".jpg"


def generate_thumbnail(pdf_path: Path, output_path: Path) -> bool:
    """
    Render page 1 of *pdf_path* to a JPG at *output_path*.
    Returns True on success, False on any failure (e.g. corrupt PDF, missing deps).
    """
    try:
        import pypdfium2 as pdfium                      # type: ignore[import-not-found]
        from PIL import Image                           # type: ignore[import-not-found]
    except ImportError:
        log.warning("Thumbnail deps (pypdfium2 / Pillow) not installed — skipping %s", pdf_path.name)
        return False

    try:
        pdf = pdfium.PdfDocument(str(pdf_path))
        if len(pdf) == 0:
            return False
        page = pdf[0]

        # Scale so the rendered width matches our target.
        page_w_pts, _ = page.get_size()
        scale = THUMB_WIDTH_PX / float(page_w_pts)
        bitmap = page.render(scale=scale)
        pil_image: Image.Image = bitmap.to_pil()

        # Flatten any alpha against white — JPG doesn't support transparency.
        if pil_image.mode in ("RGBA", "LA"):
            bg = Image.new("RGB", pil_image.size, (255, 255, 255))
            bg.paste(pil_image, mask=pil_image.split()[-1])
            pil_image = bg
        elif pil_image.mode != "RGB":
            pil_image = pil_image.convert("RGB")

        output_path.parent.mkdir(parents=True, exist_ok=True)
        pil_image.save(
            output_path,
            format="JPEG",
            quality=THUMB_JPEG_QUALITY,
            optimize=True,
            progressive=True,
        )
        page.close()
        pdf.close()
        return True
    except Exception as exc:
        log.warning("Failed to generate thumbnail for %s: %s", pdf_path.name, exc)
        return False


def ensure_thumbnails(static_dir: Path) -> dict[str, int]:
    """
    Walk *static_dir*/pdfs and generate thumbnails for any PDF that doesn't
    yet have a sibling at *static_dir*/thumbs/<stem>.jpg.

    Returns a small report {generated, skipped, failed} for startup logging.
    """
    pdf_dir = static_dir / "pdfs"
    thumb_dir = static_dir / "thumbs"
    if not pdf_dir.exists():
        return {"generated": 0, "skipped": 0, "failed": 0}

    thumb_dir.mkdir(parents=True, exist_ok=True)

    generated = skipped = failed = 0
    for pdf_path in sorted(pdf_dir.glob("*.pdf")):
        thumb_path = thumb_dir / f"{pdf_path.stem}{THUMB_SUFFIX}"

        # Skip if thumb already exists AND is newer than the source PDF
        if thumb_path.exists() and thumb_path.stat().st_mtime >= pdf_path.stat().st_mtime:
            skipped += 1
            continue

        if generate_thumbnail(pdf_path, thumb_path):
            generated += 1
        else:
            failed += 1

    if generated or failed:
        log.info("Thumbnails: %d generated, %d skipped, %d failed", generated, skipped, failed)
    return {"generated": generated, "skipped": skipped, "failed": failed}


def thumbnail_url_for(pdf_filename: str) -> str:
    """Helper for seed/store: given 'foo.pdf' return '/static/thumbs/foo.jpg'."""
    stem = Path(pdf_filename).stem
    return f"/static/thumbs/{stem}{THUMB_SUFFIX}"
