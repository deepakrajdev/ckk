# Sales AI Assistant — Full Stack

Angular 18 + Tailwind v4 frontend, FastAPI + Pydantic 2 backend.

## Run both

```bash
# Terminal 1 — backend
cd backend
python -m venv .venv && source .venv/bin/activate     # Windows: .venv\Scripts\activate
pip install -r requirements.txt
uvicorn app.main:app --reload --port 8000

# Terminal 2 — frontend
cd frontend
npm install
npm start                                              # opens http://localhost:4200
```

## Six screens

1. **Product Recommendation & Comparison** — chat with 5 recent sessions
2. **Sales Inventory** — FLS pipeline (FLS ID · NOP · PFR · Stage · Submission · Issuance · Total NOP)
3. **Incentives** — earnings + contests
4. **Leads** — pipeline by stage
5. **Underwriting Checks** — four reference tables, all using consistent pill-chip lists in their requirement columns
6. **Library** — PDF tiles with auto-generated first-page thumbnails

## Underwriting Checks — uniform pill columns

All four tables now share the same visual language for their requirement columns:

| Table | Pill column |
|---|---|
| Financial | `documentsList` — e.g. `KYC`, `ITR (2 yrs)`, `Bank statement 6m` |
| Medical · Non-Disclosure | `medicalRequirements` — e.g. `MER`, `ECG`, `FBS`, `HbA1c` |
| Medical · Disclosure | `medicalRequirements` — e.g. `Full medicals`, `TMT`, `Condition-specific report` |
| Non-Medical | `vmerRequirements` — e.g. `VMER required`, `Tele-MER follow-up` |

Each test/document/condition renders as an individual brand-tinted pill chip, making it easy to scan and compare across rows.
