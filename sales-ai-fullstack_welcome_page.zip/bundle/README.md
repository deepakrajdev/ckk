# Sales AI Assistant — Full Stack

Angular 18 + Tailwind v4 frontend, FastAPI + Pydantic 2 backend.

## Run both

```bash
# Terminal 1 — backend
cd backend
python -m venv .venv && source .venv/bin/activate     # Windows: .venv\Scripts\activate
pip install -r requirements.txt
uvicorn app.main:app --reload --port 8000

# Terminal 2 — frontend
cd frontend
npm install
npm start                                              # opens http://localhost:4200
```

## User journey

1. **Welcome page** (`/`) — intro + clickable tiles for every module.
2. Click **Product Recommendation & Comparison** → **Intake form** (`/assistant`):
   - Primary Financial Goal (Term / Guaranteed Return / Retirement / Investment / Annuity / Education / Wealth Creation)
   - Age (0–99)
   - Annual Income (₹ LPA)
   - Occupation (Salaried / Self-employed)
   - Number of dependents
   - **Conditional:** when goal = Term, an extra "Do you smoke or chew tobacco?" question appears
3. Submit → backend creates a session preloaded with the intake-derived user message + a contextual bot reply (typically product cards).
4. Frontend navigates to **Chat** (`/assistant/chat`) — full conversational journey continues as before.

Returning users see a **"Continue previous sessions"** shortcut on the form when sessions exist.

## Other workspaces

Sales Inventory, Incentives, Underwriting Checks, Library, Leads — all reachable from the sidebar drawer (top-left hamburger) and from the Welcome tiles.
