"""
Query Intent Classifier API
============================
FastAPI service that classifies user queries into:
  - product_recommendation
  - product_comparison
  - product_information
  - underwriting_document
  - other

Powered by Google Gemini Flash 2.0 via REST API.
"""

import os
import json
import httpx
from fastapi import FastAPI, HTTPException, Request
from fastapi.responses import JSONResponse
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel, Field
from dotenv import load_dotenv
import logging

# ---------------------------------------------------------------------------
# Config & Logging
# ---------------------------------------------------------------------------
load_dotenv()
logging.basicConfig(level=logging.INFO, format="%(asctime)s | %(levelname)s | %(message)s")
logger = logging.getLogger(__name__)

GEMINI_API_KEY = os.getenv("GEMINI_API_KEY", "")
GEMINI_REST_URL = (
    "https://generativelanguage.googleapis.com/v1beta/models/"
    "gemini-2.0-flash:generateContent"
)

# ---------------------------------------------------------------------------
# Categories & system prompt
# ---------------------------------------------------------------------------
CATEGORIES = {
    "product_recommendation": "User wants suggestions / recommendations for a product.",
    "product_comparison":     "User wants to compare two or more products.",
    "product_information":    "User wants details, specs, or facts about a specific product.",
    "underwriting_document":  "Query is about underwriting documents, insurance policies, risk assessment, or related paperwork.",
    "other":                  "None of the above categories fit.",
}

SYSTEM_PROMPT = """You are a query-intent classifier.

Your only job is to read the user query and return a JSON object — nothing else.

Classify the query into EXACTLY ONE of these categories:
{categories}

Return ONLY valid JSON in this exact format (no markdown, no explanation):
{{
  "category": "<category_key>",
  "confidence": <float between 0.0 and 1.0>,
  "reasoning": "<one short sentence explaining why>"
}}
""".format(
    categories="\n".join(f'  - "{k}": {v}' for k, v in CATEGORIES.items())
)

# ---------------------------------------------------------------------------
# Pydantic schemas
# ---------------------------------------------------------------------------
class QueryRequest(BaseModel):
    query: str = Field(..., min_length=1, max_length=2000, description="User input text to classify")

class ClassificationResult(BaseModel):
    query: str
    category: str
    confidence: float
    reasoning: str
    category_description: str

class ErrorResponse(BaseModel):
    error: str
    detail: str

# ---------------------------------------------------------------------------
# Gemini REST call
# ---------------------------------------------------------------------------
async def call_gemini(user_query: str) -> dict:
    """
    Calls Gemini Flash 2.0 via REST and returns parsed classification JSON.
    """
    if not GEMINI_API_KEY:
        raise HTTPException(status_code=500, detail="GEMINI_API_KEY is not configured.")

    payload = {
        "system_instruction": {
            "parts": [{"text": SYSTEM_PROMPT}]
        },
        "contents": [
            {
                "role": "user",
                "parts": [{"text": user_query}]
            }
        ],
        "generationConfig": {
            "temperature": 0.1,
            "maxOutputTokens": 256,
            "responseMimeType": "application/json"
        }
    }

    url = f"{GEMINI_REST_URL}?key={GEMINI_API_KEY}"

    async with httpx.AsyncClient(timeout=30.0) as client:
        response = await client.post(url, json=payload)

    if response.status_code != 200:
        logger.error("Gemini API error %s: %s", response.status_code, response.text)
        raise HTTPException(
            status_code=502,
            detail=f"Gemini API returned {response.status_code}: {response.text[:300]}"
        )

    raw = response.json()

    try:
        text_content = raw["candidates"][0]["content"]["parts"][0]["text"]
        result = json.loads(text_content)
    except (KeyError, IndexError, json.JSONDecodeError) as exc:
        logger.error("Failed to parse Gemini response: %s | raw: %s", exc, raw)
        raise HTTPException(status_code=502, detail=f"Could not parse Gemini response: {exc}")

    # Validate returned category
    if result.get("category") not in CATEGORIES:
        result["category"] = "other"

    return result

# ---------------------------------------------------------------------------
# FastAPI app
# ---------------------------------------------------------------------------
app = FastAPI(
    title="Query Intent Classifier",
    description="Classifies user queries into product/underwriting categories using Gemini Flash 2.0",
    version="1.0.0",
    docs_url="/docs",
    redoc_url="/redoc",
)

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_methods=["*"],
    allow_headers=["*"],
)

# ---------------------------------------------------------------------------
# Routes
# ---------------------------------------------------------------------------
@app.get("/", tags=["Health"])
async def root():
    return {"status": "ok", "service": "Query Intent Classifier", "version": "1.0.0"}


@app.get("/health", tags=["Health"])
async def health():
    return {"status": "healthy"}


@app.get("/categories", tags=["Info"])
async def list_categories():
    """Returns all supported classification categories with descriptions."""
    return {"categories": CATEGORIES}


@app.post(
    "/classify",
    response_model=ClassificationResult,
    tags=["Classification"],
    summary="Classify a user query",
    responses={
        200: {"description": "Successful classification"},
        400: {"model": ErrorResponse, "description": "Invalid input"},
        502: {"model": ErrorResponse, "description": "Upstream LLM error"},
    },
)
async def classify_query(request: QueryRequest):
    """
    Accepts a plain-text query and returns its classified intent.

    **Categories:**
    - `product_recommendation` – user wants product suggestions
    - `product_comparison` – user wants to compare products
    - `product_information` – user wants product details/specs
    - `underwriting_document` – insurance/underwriting/risk doc queries
    - `other` – anything that doesn't fit above
    """
    logger.info("Classifying query: %s", request.query[:80])

    result = await call_gemini(request.query)

    return ClassificationResult(
        query=request.query,
        category=result["category"],
        confidence=float(result.get("confidence", 0.0)),
        reasoning=result.get("reasoning", ""),
        category_description=CATEGORIES[result["category"]],
    )


@app.post(
    "/classify/batch",
    tags=["Classification"],
    summary="Classify multiple queries at once",
)
async def classify_batch(queries: list[QueryRequest]):
    """
    Classify up to 20 queries in a single call.
    """
    if len(queries) > 20:
        raise HTTPException(status_code=400, detail="Maximum 20 queries per batch.")

    results = []
    for q in queries:
        try:
            result = await call_gemini(q.query)
            results.append(
                ClassificationResult(
                    query=q.query,
                    category=result["category"],
                    confidence=float(result.get("confidence", 0.0)),
                    reasoning=result.get("reasoning", ""),
                    category_description=CATEGORIES[result["category"]],
                )
            )
        except HTTPException as exc:
            results.append({"query": q.query, "error": exc.detail})

    return {"results": results, "total": len(results)}


# ---------------------------------------------------------------------------
# Global exception handler
# ---------------------------------------------------------------------------
@app.exception_handler(Exception)
async def global_exception_handler(request: Request, exc: Exception):
    logger.error("Unhandled exception: %s", exc)
    return JSONResponse(status_code=500, content={"error": "Internal server error", "detail": str(exc)})
