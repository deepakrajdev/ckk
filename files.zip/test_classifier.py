"""
test_classifier.py
------------------
Quick smoke-tests for the Query Intent Classifier API.
Run with: python test_classifier.py
Requires the server to be running on localhost:8000.
"""

import httpx
import json

BASE_URL = "http://localhost:8000"

TEST_CASES = [
    # (query, expected_category)
    ("Can you suggest the best laptop under 50000 rupees?",        "product_recommendation"),
    ("Compare iPhone 15 vs Samsung Galaxy S24",                    "product_comparison"),
    ("What are the specs of the Sony WH-1000XM5 headphones?",      "product_information"),
    ("I need to review the underwriting guidelines for life insurance policies", "underwriting_document"),
    ("What is the weather in Delhi today?",                         "other"),
    ("Which health insurance plan should I buy for my family?",     "product_recommendation"),
    ("Difference between term insurance and whole life insurance",  "product_comparison"),
    ("Tell me about the claims process in the policy document",     "underwriting_document"),
]


def print_result(label: str, data: dict):
    print(f"\n{'─'*60}")
    print(f"Query   : {data['query']}")
    print(f"Category: {data['category']}  (confidence: {data['confidence']:.2f})")
    print(f"Reason  : {data['reasoning']}")
    print(f"Expected: {label}")
    match = "✅" if data["category"] == label else "⚠️  MISMATCH"
    print(f"Match   : {match}")


def main():
    print("=" * 60)
    print("  Query Intent Classifier — Test Suite")
    print("=" * 60)

    # Health check
    r = httpx.get(f"{BASE_URL}/health")
    assert r.status_code == 200, "Health check failed!"
    print("\n✅ Health check passed")

    # Single classify
    for query, expected in TEST_CASES:
        r = httpx.post(f"{BASE_URL}/classify", json={"query": query}, timeout=30)
        assert r.status_code == 200, f"Error: {r.text}"
        print_result(expected, r.json())

    # Batch test
    print(f"\n{'─'*60}")
    print("Batch test (3 queries)...")
    batch_payload = [{"query": q} for q, _ in TEST_CASES[:3]]
    r = httpx.post(f"{BASE_URL}/classify/batch", json=batch_payload, timeout=60)
    assert r.status_code == 200
    data = r.json()
    print(f"✅ Batch returned {data['total']} results")

    print(f"\n{'='*60}")
    print("All tests completed.")


if __name__ == "__main__":
    main()
