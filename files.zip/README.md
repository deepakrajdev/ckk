# Query Intent Classifier API

A FastAPI microservice that classifies user queries into one of five intents using **Google Gemini Flash 2.0** via the REST API.

## Supported Categories

| Category | Description |
|---|---|
| `product_recommendation` | User wants product suggestions |
| `product_comparison` | User wants to compare products |
| `product_information` | User wants product details / specs |
| `underwriting_document` | Insurance / underwriting / risk queries |
| `other` | Anything outside the above |

---

## Setup

### 1. Install dependencies
```bash
pip install -r requirements.txt
```

### 2. Configure environment
```bash
cp .env.example .env
# Edit .env and add your Gemini API key
```
Get a free API key at: https://aistudio.google.com/app/apikey

### 3. Run the server
```bash
bash start.sh
# or directly:
uvicorn main:app --reload
```

Server starts at **http://localhost:8000**  
Swagger UI at **http://localhost:8000/docs**

---

## API Endpoints

### `POST /classify`
Classify a single query.

**Request:**
```json
{ "query": "Which laptop is best for a college student?" }
```

**Response:**
```json
{
  "query": "Which laptop is best for a college student?",
  "category": "product_recommendation",
  "confidence": 0.97,
  "reasoning": "The user is asking for a product suggestion based on a use-case.",
  "category_description": "User wants suggestions / recommendations for a product."
}
```

---

### `POST /classify/batch`
Classify up to 20 queries at once.

**Request:**
```json
[
  { "query": "Compare iPhone vs Samsung" },
  { "query": "Tell me about underwriting norms" }
]
```

**Response:**
```json
{
  "results": [ ... ],
  "total": 2
}
```

---

### `GET /categories`
Returns all categories and their descriptions.

### `GET /health`
Returns `{"status": "healthy"}`.

---

## Test
```bash
# Make sure the server is running first
python test_classifier.py
```

---

## Project Structure
```
query-classifier/
├── main.py            # FastAPI app & Gemini integration
├── requirements.txt
├── .env.example       # Copy to .env and fill in your key
├── start.sh           # Convenience startup script
├── test_classifier.py # Smoke tests
└── README.md
```
