#!/bin/bash
# -----------------------------------------------
# Start the Query Intent Classifier API
# -----------------------------------------------
set -e

# Load .env if it exists
if [ -f .env ]; then
  export $(grep -v '^#' .env | xargs)
fi

HOST=${HOST:-0.0.0.0}
PORT=${PORT:-8000}

echo "============================================"
echo "  Query Intent Classifier API"
echo "  http://${HOST}:${PORT}"
echo "  Swagger docs: http://${HOST}:${PORT}/docs"
echo "============================================"

uvicorn main:app --host "$HOST" --port "$PORT" --reload
