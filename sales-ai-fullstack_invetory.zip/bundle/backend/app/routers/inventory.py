"""Sales-inventory — policy pipeline tracking endpoints."""

from fastapi import APIRouter, Depends, HTTPException, Query, status as http_status

from app.models import (
    InventoryRow,
    InventoryStat,
    PipelineSummary,
    PolicyRecord,
    PolicyStatus,
    UnderwritingStage,
)
from app.services.store import Store, get_store

router = APIRouter(prefix="/api/inventory", tags=["inventory"])


# ============================================================
# ★ NEW — Flavor 1: aggregate dashboard
# ============================================================

@router.get("/pipeline-summary", response_model=PipelineSummary)
async def get_pipeline_summary(
    store: Store = Depends(get_store),
) -> PipelineSummary:
    """
    Aggregate counts / premium / sum-assured per status. Powers the
    salesperson's pipeline-overview dashboard with one tile per status:
    Fresh Business, New Business, PENDING UW, PFR, RFI, NA.
    """
    return await store.pipeline_summary()


# ============================================================
# ★ NEW — Policy list (with optional status filter + search)
# ============================================================

@router.get("/policies", response_model=list[PolicyRecord])
async def list_policies(
    status: PolicyStatus | None = Query(
        None, description="Filter by current policy status"
    ),
    q: str | None = Query(
        None, description="Search across policy/application ID and customer name"
    ),
    store: Store = Depends(get_store),
) -> list[PolicyRecord]:
    """Drill-down list — filter by status and/or search."""
    return await store.list_policies(status=status, q=q)


# ============================================================
# ★ NEW — Flavor 2: full policy detail with status history
# ============================================================

@router.get("/policies/{identifier}", response_model=PolicyRecord)
async def get_policy(
    identifier: str,
    store: Store = Depends(get_store),
) -> PolicyRecord:
    """
    Single policy with the full status timeline + comments + required
    documents at each step. Lookup works by internal id, policy_id
    (e.g. POL-2026-04812) or application_id (e.g. APP-78521-Q2).
    """
    rec = await store.get_policy(identifier)
    if rec is None:
        raise HTTPException(
            status_code=http_status.HTTP_404_NOT_FOUND,
            detail=f"No policy found for '{identifier}'",
        )
    return rec


# ============================================================
# Legacy endpoints — kept so older UI calls still work
# ============================================================

@router.get("", response_model=list[InventoryRow])
async def list_inventory(
    stage: UnderwritingStage | None = Query(None),
    q: str | None = Query(None),
    store: Store = Depends(get_store),
) -> list[InventoryRow]:
    return await store.list_inventory(stage=stage, q=q)


@router.get("/stats", response_model=list[InventoryStat])
async def inventory_stats(
    store: Store = Depends(get_store),
) -> list[InventoryStat]:
    return await store.inventory_stats()
