"""
Initial demo data — same content the frontend ships with.
"""

from datetime import datetime, timedelta, timezone

from datetime import datetime, timedelta

from app.models import (
    ChatMessage,
    ChatSession,
    EarningsSummary,
    FYRenewalKPI,
    Incentive,
    IncentiveBreakdown,
    IncentiveDashboard,
    IncentiveTag,
    InsuranceProduct,
    InsuranceProductType,
    InventoryRow,
    InventoryStat,
    Lead,
    LeadStage,
    LibraryCategory,
    LibraryDocument,
    MessageAuthor,
    NewBusinessKPI,
    NOPKPI,
    PipelineSummary,
    PolicyRecord,
    PolicyStatus,
    ProductCardsAttachment,
    ShortfallTier,
    StatusBucket,
    StatusHistoryEntry,
    UnderwritingAttachment,
    UnderwritingChecksBundle,
    UnderwritingDoc,
    UnderwritingRecord,
    FinancialSucEntry,
    UnderwritingStage,
    UserProfile,
)


def _now() -> datetime:
    return datetime.now(timezone.utc)


def me() -> UserProfile:
    return UserProfile(
        id="48201",
        name="Rohan Sharma",
        initials="RS",
        role="Senior Advisor",
        email="rohan.sharma@aegis.example",
    )


# ---------------- Sessions ----------------

def _term_products() -> list[InsuranceProduct]:
    return [
        InsuranceProduct(
            id="p-secure", name="SecureLife Elite Term", carrier="HDFC Life",
            type=InsuranceProductType.term,
            coverage="₹1 Cr", tenure="30 yrs", premium="₹12,400/yr",
            rating=5, recommended=True,
            highlights=[
                "99.4% claim settlement ratio",
                "Free annual health check-up",
                "Critical illness rider available",
            ],
        ),
        InsuranceProduct(
            id="p-iprotect", name="iProtect Smart", carrier="ICICI Pru",
            type=InsuranceProductType.term,
            coverage="₹1 Cr", tenure="30 yrs", premium="₹13,100/yr",
            rating=4,
            highlights=[
                "Return-of-premium option",
                "Terminal illness benefit",
                "Spouse cover add-on",
            ],
        ),
    ]


def sessions() -> list[ChatSession]:
    now = _now()
    mins = lambda n: now - timedelta(minutes=n)
    hrs  = lambda n: now - timedelta(hours=n)
    days = lambda n: now - timedelta(days=n)

    term = _term_products()

    return [
        ChatSession(
            id="sess-1",
            title="Term plan · 35yo non-smoker · ₹1 Cr",
            created_at=mins(8), updated_at=mins(2),
            messages=[
                ChatMessage(id="m1-1", author=MessageAuthor.bot, timestamp=mins(8),
                    content="👋 Hi Rohan — I'm your sales co-pilot. Share the prospect's profile and I'll match products and pull underwriting docs."),
                ChatMessage(id="m1-2", author=MessageAuthor.user, timestamp=mins(7),
                    content="Prospect: 35-year-old, non-smoker, salaried (₹18 LPA), 2 dependents. Wants ₹1 Cr cover for 30 years. Suggest term plans."),
                ChatMessage(id="m1-3", author=MessageAuthor.bot, timestamp=mins(2),
                    content="Strong matches — ranked by claim-settlement ratio, premium efficiency and rider flexibility:",
                    attachment=ProductCardsAttachment(products=term)),
            ],
        ),
        ChatSession(
            id="sess-2",
            title="ULIP wealth creation · ₹50k/mo",
            created_at=hrs(3), updated_at=hrs(2),
            messages=[
                ChatMessage(id="m2-1", author=MessageAuthor.user, timestamp=hrs(3),
                    content="Client wants long-term wealth creation with insurance cover. Premium budget ₹50k/month. Recommend ULIPs."),
                ChatMessage(id="m2-2", author=MessageAuthor.bot, timestamp=hrs(2),
                    content="Two ULIPs that have consistently outperformed their benchmark over 5 years for this ticket size:",
                    attachment=ProductCardsAttachment(products=[
                        InsuranceProduct(
                            id="u-wealth", name="Wealth Plus ULIP", carrier="Max Life",
                            type=InsuranceProductType.ulip,
                            coverage="₹1 Cr", tenure="20 yrs", premium="₹50,000/yr",
                            rating=5, recommended=True,
                            highlights=[
                                "11.8% 5-yr CAGR (Balanced fund)",
                                "Loyalty additions from year 6",
                                "Unlimited fund switches",
                            ],
                        ),
                        InsuranceProduct(
                            id="u-smart", name="Smart Wealth Builder", carrier="TATA AIA",
                            type=InsuranceProductType.ulip,
                            coverage="₹1 Cr", tenure="20 yrs", premium="₹50,000/yr",
                            rating=4,
                            highlights=[
                                "Top-ranked Multi-Cap fund",
                                "Wealth-boosters from year 10",
                                "Zero allocation charges",
                            ],
                        ),
                    ])),
            ],
        ),
        ChatSession(
            id="sess-3",
            title="Underwriting · ₹2 Cr term plan",
            created_at=hrs(20), updated_at=hrs(19),
            messages=[
                ChatMessage(id="m3-1", author=MessageAuthor.user, timestamp=hrs(20),
                    content="What documents are required for underwriting a ₹2 Cr term plan? Self-employed prospect."),
                ChatMessage(id="m3-2", author=MessageAuthor.bot, timestamp=hrs(19),
                    content="For a ₹2 Cr term plan on a self-employed prospect, the carrier will require:",
                    attachment=UnderwritingAttachment(
                        product="Term Plan · ₹2 Cr",
                        documents=[
                            UnderwritingDoc(id="d1", name="KYC — PAN + Aadhaar",   required=True,
                                            description="Self-attested copies; e-KYC accepted via DigiLocker."),
                            UnderwritingDoc(id="d2", name="Income proof",          required=True,
                                            description="ITR for last 3 years + audited financials for self-employed."),
                            UnderwritingDoc(id="d3", name="Medical examination",   required=True,
                                            description="Full medicals — mandatory for SA > ₹75 L."),
                            UnderwritingDoc(id="d4", name="Financial questionnaire", required=False,
                                            description="Triggered when SA exceeds 25× annual income."),
                        ],
                    )),
            ],
        ),
        ChatSession(
            id="sess-4",
            title="Pension plans · 45yo prospect",
            created_at=days(2), updated_at=days(2),
            messages=[
                ChatMessage(id="m4-1", author=MessageAuthor.user, timestamp=days(2),
                    content="Recommend pension plans for a 45-year-old looking for guaranteed income at 60."),
                ChatMessage(id="m4-2", author=MessageAuthor.bot, timestamp=days(2),
                    content=("For guaranteed income at 60 with a 15-year accumulation window, I usually shortlist three options: "
                             "deferred annuity plans from LIC and HDFC, and a ULIP-pension hybrid from ICICI. I can pull a "
                             "side-by-side comparison if you confirm the premium budget and whether the client prefers monthly or annual payouts.")),
            ],
        ),
        ChatSession(
            id="sess-5",
            title="Critical illness rider explainer",
            created_at=days(4), updated_at=days(4),
            messages=[
                ChatMessage(id="m5-1", author=MessageAuthor.user, timestamp=days(4),
                    content="Quick explainer on critical illness vs accidental death riders for a prospect."),
                ChatMessage(id="m5-2", author=MessageAuthor.bot, timestamp=days(4),
                    content=("Critical Illness (CI) rider pays a lump sum on diagnosis of any covered illness (typically 30-60 conditions: "
                             "cancer, stroke, heart attack, kidney failure, major organ transplant). Payout is independent of the base sum "
                             "assured. Accidental Death Benefit (ADB) doubles the sum assured if death is caused by an accident within 90 days. "
                             "Together they cost roughly 8-15% of base premium and meaningfully widen the protection envelope - recommend "
                             "CI for prospects with family history of lifestyle disease, ADB for anyone with significant road exposure.")),
            ],
        ),
    ]


# ---------------- Inventory (FLS pipeline) ----------------

def inventory() -> list[InventoryRow]:
    """FLS pipeline records for the inventory screen."""
    return [
        InventoryRow(id="i1", fls_id="FLS-48201-Q2-0142", nop=12, pfr="₹12,40,000",
                     underwriting_stage=UnderwritingStage.issued,    submission=12, issuance=12, total_nop=156),
        InventoryRow(id="i2", fls_id="FLS-48201-Q2-0143", nop=8,  pfr="₹6,80,000",
                     underwriting_stage=UnderwritingStage.medical,   submission=8,  issuance=0,  total_nop=156),
        InventoryRow(id="i3", fls_id="FLS-48201-Q2-0144", nop=15, pfr="₹18,50,000",
                     underwriting_stage=UnderwritingStage.in_review, submission=15, issuance=11, total_nop=156),
        InventoryRow(id="i4", fls_id="FLS-48201-Q2-0145", nop=6,  pfr="₹4,20,000",
                     underwriting_stage=UnderwritingStage.submitted, submission=6,  issuance=0,  total_nop=156),
        InventoryRow(id="i5", fls_id="FLS-48201-Q2-0146", nop=22, pfr="₹26,40,000",
                     underwriting_stage=UnderwritingStage.approved,  submission=22, issuance=18, total_nop=156),
        InventoryRow(id="i6", fls_id="FLS-48201-Q2-0147", nop=4,  pfr="₹3,20,000",
                     underwriting_stage=UnderwritingStage.declined,  submission=4,  issuance=0,  total_nop=156),
        InventoryRow(id="i7", fls_id="FLS-48201-Q2-0148", nop=10, pfr="₹9,60,000",
                     underwriting_stage=UnderwritingStage.issued,    submission=10, issuance=10, total_nop=156),
        InventoryRow(id="i8", fls_id="FLS-48201-Q2-0149", nop=18, pfr="₹21,80,000",
                     underwriting_stage=UnderwritingStage.medical,   submission=18, issuance=5,  total_nop=156),
    ]


def inventory_stats() -> list[InventoryStat]:
    return [
        InventoryStat(label="Total NOP",        value="156",     delta="14 this week", delta_up=True),
        InventoryStat(label="Submissions MTD",  value="95",      delta="12.4%",        delta_up=True),
        InventoryStat(label="Issuance rate",    value="74%",     delta="3.1%",         delta_up=True),
        InventoryStat(label="PFR (MTD)",        value="₹1.02 Cr", delta="8.9%",        delta_up=True),
    ]


# ---------------- Incentives ----------------

def earnings() -> EarningsSummary:
    return EarningsSummary(
        period_label="Q2 2026",
        amount="₹2,84,500",
        delta_pct=18.2,
        delta_up=True,
        next_tier_label="Gold tier",
        next_tier_amount="₹4,00,000",
        next_tier_remaining="₹1,15,500",
        current_tier_label="Silver tier",
        progress_pct=71,
    )


def incentives() -> list[Incentive]:
    return [
        Incentive(id="c1", title="Term Plan Champion",  reward="₹50,000",  progress=78,
                  current="23 policies",  target="30",       deadline="Jun 30", tag=IncentiveTag.closing_soon),
        Incentive(id="c2", title="ULIP Premium Push",   reward="₹40,000",  progress=52,
                  current="₹6.2 L premium", target="₹12 L",  deadline="Jul 31", tag=IncentiveTag.active),
        Incentive(id="c3", title="New Customer Drive",  reward="Bali Trip", progress=35,
                  current="14 new",       target="40 new",   deadline="Aug 15", tag=IncentiveTag.stretch),
        Incentive(id="c4", title="Renewal Hero",        reward="₹25,000",  progress=92,
                  current="184 renewals", target="200",      deadline="Jun 30", tag=IncentiveTag.closing_soon),
    ]


# ---------------- Leads ----------------

def leads() -> list[Lead]:
    return [
        Lead(id="l1", initials="AP", name="Anita Pillai",  city="Bengaluru", interest="Term ₹1 Cr",
             potential="₹14,800/yr",  stage=LeadStage.quoted,     next_action="Send revised quote · today", hot=True),
        Lead(id="l2", initials="KM", name="Karan Mehta",   city="Mumbai",    interest="ULIP ₹50k/mo",
             potential="₹6,00,000/yr", stage=LeadStage.negotiating, next_action="Schedule call · tomorrow 11 AM"),
        Lead(id="l3", initials="RS", name="Riya Sharma",   city="Delhi",     interest="Pension Plan",
             potential="₹1,20,000/yr", stage=LeadStage.contacted,  next_action="Follow-up email · Wednesday"),
        Lead(id="l4", initials="VG", name="Vikram Gupta",  city="Pune",      interest="Term ₹2 Cr",
             potential="₹26,400/yr",   stage=LeadStage.new,        next_action="First contact · today", hot=True),
        Lead(id="l5", initials="SN", name="Sneha Nair",    city="Kochi",     interest="Endowment",
             potential="₹48,000/yr",   stage=LeadStage.closed,     next_action="Policy issued · Jun 12"),
        Lead(id="l6", initials="AB", name="Arjun Bose",    city="Kolkata",   interest="Term + CI Rider",
             potential="₹18,200/yr",   stage=LeadStage.quoted,     next_action="Awaiting decision · 3 days"),
        Lead(id="l7", initials="MJ", name="Meera Joshi",   city="Ahmedabad", interest="Child Plan",
             potential="₹72,000/yr",   stage=LeadStage.contacted,  next_action="Send brochure · today"),
    ]


# ---------------- Underwriting Checks ----------------

def underwriting_checks() -> UnderwritingChecksBundle:
    """
    ★ Seed data matching the user's MongoDB collection shape exactly.

    Eight Financial/Medical documents come straight from the JSON the user
    supplied; four Non-Medical documents are added so the 4th tab works too.
    Field-name typos in the source ("Selef Employment", "Financial_Requirment")
    are normalised to standard spellings here.
    """

    # Doc1/Doc2/Doc3 placeholders — kept identical to the user's example
    docs_2 = ["Doc1", "Doc2"]
    docs_3 = ["Doc1", "Doc2", "Doc3"]

    def two_band_suc() -> list[FinancialSucEntry]:
        """Return the standard two-band SUC array the user used in every doc."""
        return [
            FinancialSucEntry(
                age_limit="0-1Cr",
                financial_requirement=[],
                document_list=docs_2,
            ),
            FinancialSucEntry(
                age_limit="1-2Cr",
                financial_requirement=[],
                document_list=docs_3,
            ),
        ]

    documents: list[UnderwritingRecord] = [
        # ===== Financial =====
        UnderwritingRecord(product_type="I Select 360",
                           request_type="Financial",
                           occupation_type="Self Employment",
                           financial_suc=two_band_suc()),
        UnderwritingRecord(product_type="I Select 360",
                           request_type="Financial",
                           occupation_type="Salaried",
                           financial_suc=two_band_suc()),
        UnderwritingRecord(product_type="Promise To Protect",
                           request_type="Financial",
                           occupation_type="Self Employment",
                           financial_suc=two_band_suc()),
        UnderwritingRecord(product_type="Promise To Protect",
                           request_type="Financial",
                           occupation_type="Salaried",
                           financial_suc=two_band_suc()),

        # ===== Medical-Non Disclosure =====
        UnderwritingRecord(product_type="I Select 360",
                           request_type="Medical-Non Disclosure",
                           occupation_type="Self Employment",
                           financial_suc=two_band_suc()),
        UnderwritingRecord(product_type="I Select 360",
                           request_type="Medical-Non Disclosure",
                           occupation_type="Salaried",
                           financial_suc=two_band_suc()),

        # ===== Medical-Disclosure =====
        UnderwritingRecord(product_type="Promise To Protect",
                           request_type="Medical-Disclosure",
                           occupation_type="Self Employment",
                           financial_suc=two_band_suc()),
        UnderwritingRecord(product_type="Promise To Protect",
                           request_type="Medical-Disclosure",
                           occupation_type="Salaried",
                           financial_suc=two_band_suc()),

        # ===== Non-Medical (added so the 4th tab works) =====
        UnderwritingRecord(product_type="I Select 360",
                           request_type="Non-Medical",
                           occupation_type="Self Employment",
                           financial_suc=two_band_suc()),
        UnderwritingRecord(product_type="I Select 360",
                           request_type="Non-Medical",
                           occupation_type="Salaried",
                           financial_suc=two_band_suc()),
        UnderwritingRecord(product_type="Promise To Protect",
                           request_type="Non-Medical",
                           occupation_type="Self Employment",
                           financial_suc=two_band_suc()),
        UnderwritingRecord(product_type="Promise To Protect",
                           request_type="Non-Medical",
                           occupation_type="Salaried",
                           financial_suc=two_band_suc()),
    ]

    return UnderwritingChecksBundle(documents=documents)


def library() -> list[LibraryDocument]:
    now = _now()
    return [
        LibraryDocument(
            id="lib1", title="Underwriting Manual v2.4",
            description="Risk classification, financial underwriting bands, medical requirement matrix and substandard-life loadings.",
            category=LibraryCategory.underwriting,
            pages=42, size_kb=2,
            updated_at=now - timedelta(days=3),
            download_url="/static/pdfs/underwriting-manual.pdf",
        ),
        LibraryDocument(
            id="lib2", title="Financial Underwriting Guide 2026",
            description="Income multiples by occupation, document matrix per sum-assured band, and NRI-specific rules.",
            category=LibraryCategory.underwriting,
            pages=18, size_kb=2,
            updated_at=now - timedelta(days=10),
            download_url="/static/pdfs/financial-uw-guide.pdf",
        ),
        LibraryDocument(
            id="lib3", title="Medical Requirements Matrix",
            description="Age × sum-assured × disclosure matrix for tele-UW, VMER and full medicals; empanelled centre list.",
            category=LibraryCategory.underwriting,
            pages=24, size_kb=2,
            updated_at=now - timedelta(days=21),
            download_url="/static/pdfs/medical-requirements.pdf",
        ),
        LibraryDocument(
            id="lib4", title="Term Product Handbook — Q2 2026",
            description="Side-by-side comparison of SecureLife Elite, iProtect Smart and Click 2 Protect Super.",
            category=LibraryCategory.products,
            pages=36, size_kb=2,
            updated_at=now - timedelta(days=7),
            download_url="/static/pdfs/product-handbook.pdf",
        ),
        LibraryDocument(
            id="lib5", title="IRDAI Compliance Checklist",
            description="Pre-sale disclosures, suitability assessment, free-look period and AML obligations.",
            category=LibraryCategory.compliance,
            pages=12, size_kb=2,
            updated_at=now - timedelta(days=45),
            download_url="/static/pdfs/compliance-checklist.pdf",
        ),
    ]


# ────────────────────────────────────────────────────────────────────
# ★ NEW — Policy pipeline (Inventory rich model)
# ────────────────────────────────────────────────────────────────────

def policies() -> list[PolicyRecord]:
    """
    Realistic pipeline of policies sold by the salesperson, each with a
    rich status history showing the journey through Fresh Business →
    New Business → underwriting stages.
    """
    now = datetime(2026, 6, 22, 9, 0)

    def days_ago(n: int) -> datetime:
        return now - timedelta(days=n)

    return [
        # ---- 1: Fresh Business (just submitted, awaiting NB conversion)
        PolicyRecord(
            id="p1",
            policy_id="POL-2026-04812",
            application_id="APP-78521-Q2",
            customer_name="Rajesh Kumar",
            plan_name="iProtect Smart (Term)",
            sum_assured=10_000_000,
            annual_premium=24_500,
            current_status=PolicyStatus.fresh_business,
            submitted_date=days_ago(2),
            last_updated=days_ago(2),
            history=[
                StatusHistoryEntry(
                    status=PolicyStatus.fresh_business,
                    entered_at=days_ago(2),
                    comment="Initial proposal submitted with full KYC. "
                            "Awaiting first-touch review.",
                    required_documents=["KYC verification"],
                    completed_at=None,
                ),
            ],
        ),

        # ---- 2: New Business
        PolicyRecord(
            id="p2",
            policy_id="POL-2026-04795",
            application_id="APP-78498-Q2",
            customer_name="Priya Sharma",
            plan_name="i Select 360 (ULIP)",
            sum_assured=5_000_000,
            annual_premium=120_000,
            current_status=PolicyStatus.new_business,
            submitted_date=days_ago(5),
            last_updated=days_ago(3),
            history=[
                StatusHistoryEntry(
                    status=PolicyStatus.fresh_business,
                    entered_at=days_ago(5),
                    comment="Proposal received with premium payment.",
                    required_documents=[],
                    completed_at=days_ago(4),
                ),
                StatusHistoryEntry(
                    status=PolicyStatus.new_business,
                    entered_at=days_ago(4),
                    comment="Confirmed as new business. Premium "
                            "credited and policy entered the pipeline.",
                    required_documents=[],
                    completed_at=None,
                ),
            ],
        ),

        # ---- 3: PENDING UW
        PolicyRecord(
            id="p3",
            policy_id="POL-2026-04702",
            application_id="APP-78321-Q2",
            customer_name="Amit Patel",
            plan_name="Promise To Protect (Term)",
            sum_assured=20_000_000,
            annual_premium=42_000,
            current_status=PolicyStatus.pending_uw,
            submitted_date=days_ago(8),
            last_updated=days_ago(1),
            history=[
                StatusHistoryEntry(
                    status=PolicyStatus.fresh_business,
                    entered_at=days_ago(8),
                    comment="Proposal received.",
                    required_documents=[],
                    completed_at=days_ago(7),
                ),
                StatusHistoryEntry(
                    status=PolicyStatus.new_business,
                    entered_at=days_ago(7),
                    comment="Entered as new business.",
                    required_documents=[],
                    completed_at=days_ago(5),
                ),
                StatusHistoryEntry(
                    status=PolicyStatus.pending_uw,
                    entered_at=days_ago(5),
                    comment="Sent for medical underwriting review. "
                            "Sum-assured > ₹1 Cr requires full medicals.",
                    required_documents=[
                        "Medical examination report",
                        "ECG",
                        "FBS + Lipid profile",
                        "HbA1c",
                    ],
                    completed_at=None,
                ),
            ],
        ),

        # ---- 4: PFR — Pending For Requirements (most common case to surface)
        PolicyRecord(
            id="p4",
            policy_id="POL-2026-04598",
            application_id="APP-78201-Q2",
            customer_name="Sunita Iyer",
            plan_name="iProtect Smart (Term)",
            sum_assured=15_000_000,
            annual_premium=38_500,
            current_status=PolicyStatus.pfr,
            submitted_date=days_ago(12),
            last_updated=days_ago(2),
            history=[
                StatusHistoryEntry(
                    status=PolicyStatus.fresh_business,
                    entered_at=days_ago(12),
                    comment="Proposal received.",
                    required_documents=[],
                    completed_at=days_ago(11),
                ),
                StatusHistoryEntry(
                    status=PolicyStatus.new_business,
                    entered_at=days_ago(11),
                    comment="Entered as new business.",
                    required_documents=[],
                    completed_at=days_ago(9),
                ),
                StatusHistoryEntry(
                    status=PolicyStatus.pending_uw,
                    entered_at=days_ago(9),
                    comment="Sent for underwriting review.",
                    required_documents=[],
                    completed_at=days_ago(6),
                ),
                StatusHistoryEntry(
                    status=PolicyStatus.pfr,
                    entered_at=days_ago(6),
                    comment="Income proof insufficient for the requested "
                            "SA band. Please collect & upload the listed "
                            "documents to clear PFR.",
                    required_documents=[
                        "ITR for last 2 years",
                        "Bank statement (last 12 months)",
                        "Form 16",
                        "Salary slips (last 3 months)",
                    ],
                    completed_at=None,
                ),
            ],
        ),

        # ---- 5: RFI — Request For Information
        PolicyRecord(
            id="p5",
            policy_id="POL-2026-04501",
            application_id="APP-77998-Q2",
            customer_name="Vikram Singh",
            plan_name="Promise To Protect (Term)",
            sum_assured=7_500_000,
            annual_premium=18_900,
            current_status=PolicyStatus.rfi,
            submitted_date=days_ago(15),
            last_updated=days_ago(3),
            history=[
                StatusHistoryEntry(
                    status=PolicyStatus.fresh_business,
                    entered_at=days_ago(15),
                    comment="Proposal received.",
                    required_documents=[],
                    completed_at=days_ago(14),
                ),
                StatusHistoryEntry(
                    status=PolicyStatus.new_business,
                    entered_at=days_ago(14),
                    comment="Entered as new business.",
                    required_documents=[],
                    completed_at=days_ago(12),
                ),
                StatusHistoryEntry(
                    status=PolicyStatus.pending_uw,
                    entered_at=days_ago(12),
                    comment="Sent for underwriting review.",
                    required_documents=[],
                    completed_at=days_ago(9),
                ),
                StatusHistoryEntry(
                    status=PolicyStatus.rfi,
                    entered_at=days_ago(9),
                    comment="UW has flagged inconsistent occupation "
                            "details on the proposal vs. KYC. Customer "
                            "clarification required before re-review.",
                    required_documents=[
                        "Employer letter confirming designation",
                        "Latest payslip with designation",
                        "Signed clarification letter",
                    ],
                    completed_at=None,
                ),
            ],
        ),

        # ---- 6: PFR (second one — common bucket)
        PolicyRecord(
            id="p6",
            policy_id="POL-2026-04477",
            application_id="APP-77821-Q2",
            customer_name="Nisha Verma",
            plan_name="i Select 360 (ULIP)",
            sum_assured=3_500_000,
            annual_premium=80_000,
            current_status=PolicyStatus.pfr,
            submitted_date=days_ago(11),
            last_updated=days_ago(4),
            history=[
                StatusHistoryEntry(
                    status=PolicyStatus.fresh_business,
                    entered_at=days_ago(11),
                    comment="Proposal received with first premium.",
                    required_documents=[],
                    completed_at=days_ago(10),
                ),
                StatusHistoryEntry(
                    status=PolicyStatus.new_business,
                    entered_at=days_ago(10),
                    comment="Entered as new business.",
                    required_documents=[],
                    completed_at=days_ago(8),
                ),
                StatusHistoryEntry(
                    status=PolicyStatus.pfr,
                    entered_at=days_ago(8),
                    comment="Address proof mismatched with KYC. Please "
                            "upload a fresh address proof matching the "
                            "proposal form details.",
                    required_documents=[
                        "Address proof (Aadhaar / passport / utility bill)",
                    ],
                    completed_at=None,
                ),
            ],
        ),

        # ---- 7: NA — Not Applicable (declined / withdrawn)
        PolicyRecord(
            id="p7",
            policy_id="POL-2026-04388",
            application_id="APP-77654-Q2",
            customer_name="Rohan Mehta",
            plan_name="Promise To Protect (Term)",
            sum_assured=25_000_000,
            annual_premium=55_000,
            current_status=PolicyStatus.na,
            submitted_date=days_ago(20),
            last_updated=days_ago(8),
            history=[
                StatusHistoryEntry(
                    status=PolicyStatus.fresh_business,
                    entered_at=days_ago(20),
                    comment="Proposal received.",
                    required_documents=[],
                    completed_at=days_ago(19),
                ),
                StatusHistoryEntry(
                    status=PolicyStatus.new_business,
                    entered_at=days_ago(19),
                    comment="Entered as new business.",
                    required_documents=[],
                    completed_at=days_ago(17),
                ),
                StatusHistoryEntry(
                    status=PolicyStatus.pending_uw,
                    entered_at=days_ago(17),
                    comment="Sent for underwriting review.",
                    required_documents=[],
                    completed_at=days_ago(10),
                ),
                StatusHistoryEntry(
                    status=PolicyStatus.na,
                    entered_at=days_ago(10),
                    comment="Declined by underwriting — adverse medical "
                            "findings (uncontrolled diabetes + cardiac risk). "
                            "Customer has been informed; refund initiated.",
                    required_documents=[],
                    completed_at=None,
                ),
            ],
        ),

        # ---- 8 & 9 — couple of New Business so the bucket has count > 1
        PolicyRecord(
            id="p8",
            policy_id="POL-2026-04903",
            application_id="APP-78621-Q2",
            customer_name="Anjali Reddy",
            plan_name="iProtect Smart (Term)",
            sum_assured=8_000_000,
            annual_premium=22_300,
            current_status=PolicyStatus.new_business,
            submitted_date=days_ago(6),
            last_updated=days_ago(4),
            history=[
                StatusHistoryEntry(
                    status=PolicyStatus.fresh_business,
                    entered_at=days_ago(6),
                    comment="Proposal received.",
                    required_documents=[],
                    completed_at=days_ago(5),
                ),
                StatusHistoryEntry(
                    status=PolicyStatus.new_business,
                    entered_at=days_ago(5),
                    comment="Entered as new business.",
                    required_documents=[],
                    completed_at=None,
                ),
            ],
        ),
        PolicyRecord(
            id="p9",
            policy_id="POL-2026-04866",
            application_id="APP-78589-Q2",
            customer_name="Karan Joshi",
            plan_name="i Select 360 (ULIP)",
            sum_assured=4_000_000,
            annual_premium=60_000,
            current_status=PolicyStatus.fresh_business,
            submitted_date=days_ago(1),
            last_updated=days_ago(1),
            history=[
                StatusHistoryEntry(
                    status=PolicyStatus.fresh_business,
                    entered_at=days_ago(1),
                    comment="Proposal received with first premium. "
                            "Awaiting first-touch review.",
                    required_documents=[],
                    completed_at=None,
                ),
            ],
        ),
    ]


def pipeline_summary(records: list[PolicyRecord]) -> PipelineSummary:
    """Aggregate counts/premium/SA per status — Flavor-1 dashboard payload."""
    by_status: dict[PolicyStatus, list[PolicyRecord]] = {s: [] for s in PolicyStatus}
    for r in records:
        by_status[r.current_status].append(r)

    total = len(records) or 1
    buckets = []
    for status in PolicyStatus:
        rows = by_status[status]
        n = len(rows)
        buckets.append(StatusBucket(
            status=status,
            count=n,
            total_premium=sum(r.annual_premium for r in rows),
            total_sum_assured=sum(r.sum_assured for r in rows),
            pct_of_total=round(100.0 * n / total, 1) if total else 0.0,
        ))

    return PipelineSummary(
        period_label="Q2 FY26",
        total_policies=len(records),
        total_premium=sum(r.annual_premium for r in records),
        total_sum_assured=sum(r.sum_assured for r in records),
        buckets=buckets,
    )


# ────────────────────────────────────────────────────────────────────
# ★ NEW — Incentive dashboard (targets / shortfalls / breakdown)
# ────────────────────────────────────────────────────────────────────

def _shortfall_tiers(target: float, achievement: float) -> list[ShortfallTier]:
    """Build the 75/80/85/90/95/100% threshold tiers for a target."""
    tiers = []
    for pct in (75, 80, 85, 90, 95, 100):
        amt = target * pct / 100
        shortfall = max(0.0, amt - achievement)
        tiers.append(ShortfallTier(
            threshold_pct=pct,
            threshold_amount=amt,
            shortfall=shortfall,
            reached=achievement >= amt,
        ))
    return tiers


def incentive_dashboard() -> IncentiveDashboard:
    """
    Synthetic but realistic Q2 FY26 dashboard. Tweak the inputs at the top
    and every downstream figure (%s, shortfalls, final amount) recomputes.
    """
    # ----- New Business -----
    nb_target = 50_00_000.0          # ₹50 L target
    nb_net    = 41_25_000.0          # ₹41.25 L achieved (~82.5%)
    nb_pct    = round(100.0 * nb_net / nb_target, 1)

    # ----- First-Year Renewal -----
    fyr_collectible = 28_00_000.0    # ₹28 L collectible
    fyr_collection  = 24_36_000.0    # ₹24.36 L collected (~87%)
    fyr_pct         = round(100.0 * fyr_collection / fyr_collectible, 1)

    # ----- NOP -----
    nop_target = 24                  # 24 policies
    nop_net    = 21
    nop_pct    = round(100.0 * nop_net / nop_target, 1)

    # ----- Incentive breakdown -----
    # Base NB incentive = 1.5% of NB net achievement (illustrative)
    base_nb = round(nb_net * 0.015, 2)
    # Persistency multiplier — 1.0 at 75% FYR, scales to 1.25 at 100%
    persistency_mult = round(
        1.0 + max(0.0, (fyr_pct - 75) / 25) * 0.25, 3
    )
    # NOP booster — flat 10k per policy past 75% of target
    nop_booster = max(0, nop_net - int(nop_target * 0.75)) * 10_000.0
    # SQM deduction — quality penalty (illustrative — 1.5% of base if FYR < 85%)
    sqm_deduction = round(base_nb * 0.015, 2) if fyr_pct < 85 else 0.0
    # Final incentive
    final = round(base_nb * persistency_mult + nop_booster - sqm_deduction, 2)

    return IncentiveDashboard(
        period_label="Q2 FY26",
        final_incentive=final,
        new_business=NewBusinessKPI(
            target=nb_target,
            net_achievement=nb_net,
            achieved_pct=nb_pct,
            shortfalls=_shortfall_tiers(nb_target, nb_net),
        ),
        fy_renewal=FYRenewalKPI(
            collectible=fyr_collectible,
            collection=fyr_collection,
            collection_pct=fyr_pct,
            shortfalls=_shortfall_tiers(fyr_collectible, fyr_collection),
        ),
        nop=NOPKPI(
            target=nop_target,
            net_nop=nop_net,
            achieved_pct=nop_pct,
        ),
        breakdown=IncentiveBreakdown(
            base_nb_incentive=base_nb,
            persistency_multiplier=persistency_mult,
            final_nop_booster=nop_booster,
            sqm_deduction=sqm_deduction,
            final_incentive_with_sqm=final,
        ),
    )

