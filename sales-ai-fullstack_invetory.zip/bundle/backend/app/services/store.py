"""In-memory data store. Replace this class to switch to a real DB."""

import asyncio
import uuid
from datetime import datetime, timezone

from app.config import get_settings
from app.models import (
    ChatMessage,
    ChatSession,
    EarningsSummary,
    Incentive,
    IncentiveDashboard,
    IncentiveTag,
    InventoryRow,
    InventoryStat,
    Lead,
    LeadCreate,
    LeadStage,
    LeadUpdate,
    LibraryCategory,
    LibraryDocument,
    MessageAuthor,
    PipelineSummary,
    PolicyRecord,
    PolicyStatus,
    SessionSummary,
    UnderwritingChecksBundle,
    UnderwritingStage,
    UserProfile,
)
from app.services import seed


class Store:
    """Single in-memory store."""

    def __init__(self) -> None:
        self._settings = get_settings()
        self._lock = asyncio.Lock()

        self._sessions: dict[str, ChatSession] = {s.id: s for s in seed.sessions()}
        self._inventory: list[InventoryRow] = seed.inventory()
        self._inventory_stats: list[InventoryStat] = seed.inventory_stats()
        self._earnings: EarningsSummary = seed.earnings()
        self._incentives: list[Incentive] = seed.incentives()
        self._leads: dict[str, Lead] = {l.id: l for l in seed.leads()}
        self._library: dict[str, LibraryDocument] = {d.id: d for d in seed.library()}
        self._underwriting_checks: UnderwritingChecksBundle = seed.underwriting_checks()
        self._me: UserProfile = seed.me()

        # ★ NEW — policy pipeline + incentive dashboard
        self._policies: list[PolicyRecord] = seed.policies()
        self._incentive_dashboard: IncentiveDashboard = seed.incentive_dashboard()

    # ---------------- Sessions / chat ----------------

    async def list_sessions(self) -> list[SessionSummary]:
        async with self._lock:
            ordered = sorted(
                self._sessions.values(),
                key=lambda s: s.updated_at,
                reverse=True,
            )[: self._settings.max_sessions]
            return [self._to_summary(s) for s in ordered]

    async def get_session(self, session_id: str) -> ChatSession | None:
        async with self._lock:
            return self._sessions.get(session_id)

    async def create_session(self, title: str | None = None) -> ChatSession:
        async with self._lock:
            now = datetime.now(timezone.utc)
            session = ChatSession(
                id=str(uuid.uuid4()),
                title=title or "New conversation",
                created_at=now, updated_at=now,
                messages=[
                    ChatMessage(
                        id=str(uuid.uuid4()),
                        author=MessageAuthor.bot,
                        timestamp=now,
                        content=("👋 New session started. Share the prospect's profile "
                                 "and I'll match products and pull underwriting requirements."),
                    )
                ],
            )
            self._sessions[session.id] = session
            self._enforce_cap()
            return session

    async def append_message(
        self, session_id: str, message: ChatMessage
    ) -> ChatSession | None:
        async with self._lock:
            session = self._sessions.get(session_id)
            if session is None:
                return None
            session.messages.append(message)
            session.updated_at = datetime.now(timezone.utc)
            if (
                session.title == "New conversation"
                and message.author == MessageAuthor.user
            ):
                session.title = self._title_from(message.content)
            return session

    async def delete_session(self, session_id: str) -> bool:
        async with self._lock:
            return self._sessions.pop(session_id, None) is not None

    # ---------------- Inventory (FLS pipeline) ----------------

    async def list_inventory(
        self,
        stage: UnderwritingStage | None = None,
        q: str | None = None,
    ) -> list[InventoryRow]:
        async with self._lock:
            rows = list(self._inventory)
        if stage is not None:
            rows = [r for r in rows if r.underwriting_stage == stage]
        if q:
            needle = q.lower()
            rows = [r for r in rows if needle in r.fls_id.lower()]
        return rows

    async def inventory_stats(self) -> list[InventoryStat]:
        async with self._lock:
            return list(self._inventory_stats)

    # ────────── ★ NEW — Policy pipeline (Inventory rich model) ──────────

    async def pipeline_summary(self) -> PipelineSummary:
        """Flavor-1: aggregate counts/premium/SA per status."""
        async with self._lock:
            policies = list(self._policies)
        return seed.pipeline_summary(policies)

    async def list_policies(
        self,
        status: PolicyStatus | None = None,
        q: str | None = None,
    ) -> list[PolicyRecord]:
        """Drill-down list. Optionally filter by status and/or search by ID."""
        async with self._lock:
            rows = list(self._policies)
        if status is not None:
            rows = [r for r in rows if r.current_status == status]
        if q:
            needle = q.lower().strip()
            rows = [
                r for r in rows
                if needle in r.policy_id.lower()
                or needle in r.application_id.lower()
                or needle in r.customer_name.lower()
            ]
        return rows

    async def get_policy(self, identifier: str) -> PolicyRecord | None:
        """Flavor-2: full policy by internal id OR policy_id OR application_id."""
        needle = identifier.lower().strip()
        async with self._lock:
            for r in self._policies:
                if (r.id == identifier
                        or r.policy_id.lower() == needle
                        or r.application_id.lower() == needle):
                    return r
        return None

    # ---------------- Incentives ----------------

    async def earnings_summary(self) -> EarningsSummary:
        async with self._lock:
            return self._earnings

    async def list_incentives(
        self, tag: IncentiveTag | None = None
    ) -> list[Incentive]:
        async with self._lock:
            rows = list(self._incentives)
        if tag is not None:
            rows = [i for i in rows if i.tag == tag]
        return rows

    # ────────── ★ NEW — Incentive dashboard (targets + breakdown) ──────────

    async def incentive_dashboard(self) -> IncentiveDashboard:
        """Returns the full targets/achievement/breakdown payload."""
        async with self._lock:
            return self._incentive_dashboard

    # ---------------- Leads ----------------

    async def list_leads(self, stage: LeadStage | None = None) -> list[Lead]:
        async with self._lock:
            rows = list(self._leads.values())
        if stage is not None:
            rows = [l for l in rows if l.stage == stage]
        return rows

    async def lead_counts(self) -> dict[str, int]:
        async with self._lock:
            counts: dict[str, int] = {"All": len(self._leads)}
            for stage in LeadStage:
                counts[stage.value] = sum(
                    1 for l in self._leads.values() if l.stage == stage
                )
            return counts

    async def create_lead(self, data: LeadCreate) -> Lead:
        async with self._lock:
            lead = Lead(
                id=str(uuid.uuid4()),
                initials=self._initials_from(data.name),
                name=data.name, city=data.city,
                interest=data.interest, potential=data.potential,
                stage=data.stage, next_action=data.next_action, hot=data.hot,
            )
            self._leads[lead.id] = lead
            return lead

    async def update_lead(self, lead_id: str, patch: LeadUpdate) -> Lead | None:
        async with self._lock:
            lead = self._leads.get(lead_id)
            if lead is None:
                return None
            data = patch.model_dump(exclude_unset=True)
            updated = lead.model_copy(update=data)
            self._leads[lead_id] = updated
            return updated

    async def delete_lead(self, lead_id: str) -> bool:
        async with self._lock:
            return self._leads.pop(lead_id, None) is not None

    # ---------------- Library ----------------

    async def list_library(
        self,
        category: LibraryCategory | None = None,
        q: str | None = None,
    ) -> list[LibraryDocument]:
        async with self._lock:
            rows = list(self._library.values())
        if category is not None:
            rows = [d for d in rows if d.category == category]
        if q:
            needle = q.lower()
            rows = [
                d for d in rows
                if needle in d.title.lower() or needle in d.description.lower()
            ]
        # Newest first
        return sorted(rows, key=lambda d: d.updated_at, reverse=True)

    async def get_library(self, document_id: str) -> LibraryDocument | None:
        async with self._lock:
            return self._library.get(document_id)

    # ---------------- Underwriting Checks ----------------
    #
    # ★ The methods below model the MongoDB collection the user maintains.
    # They are intentionally written to look like Mongo `find()` calls so
    # swapping to motor/pymongo later is a one-line change per method.

    async def list_products(self, request_type: str | None = None) -> list[str]:
        """
        A/B: Distinct product_types in the collection.
        Optionally filter by request_type so each tab only sees products
        that actually have a document for that request_type.

        MongoDB equivalent:
            await db.underwriting.distinct(
                "product_type",
                {"request_type": request_type} if request_type else {}
            )
        """
        async with self._lock:
            docs = list(self._underwriting_checks.documents)
        seen: list[str] = []
        for d in docs:
            if request_type and d.request_type != request_type:
                continue
            if d.product_type not in seen:
                seen.append(d.product_type)
        return seen

    async def list_occupations(
        self, product_type: str, request_type: str,
    ) -> list[str]:
        """
        C: Distinct occupation_types for the chosen product + request_type.

        MongoDB equivalent:
            await db.underwriting.distinct(
                "occupation_type",
                {"product_type": product_type, "request_type": request_type}
            )
        """
        async with self._lock:
            docs = list(self._underwriting_checks.documents)
        seen: list[str] = []
        for d in docs:
            if d.product_type == product_type and d.request_type == request_type:
                if d.occupation_type not in seen:
                    seen.append(d.occupation_type)
        return seen

    async def get_suc(
        self, product_type: str, request_type: str, occupation_type: str,
    ):
        """
        D: The matching document's `financial_suc` array.

        MongoDB equivalent:
            doc = await db.underwriting.find_one({
                "product_type":    product_type,
                "request_type":    request_type,
                "occupation_type": occupation_type,
            })
        """
        from app.models import SucResponse
        async with self._lock:
            docs = list(self._underwriting_checks.documents)
        for d in docs:
            if (d.product_type == product_type
                    and d.request_type == request_type
                    and d.occupation_type == occupation_type):
                return SucResponse(
                    product_type=d.product_type,
                    request_type=d.request_type,
                    occupation_type=d.occupation_type,
                    financial_suc=list(d.financial_suc),
                )
        # No match — return empty SUC array (still a valid response)
        return SucResponse(
            product_type=product_type,
            request_type=request_type,  # type: ignore[arg-type]
            occupation_type=occupation_type,
            financial_suc=[],
        )

    # Backward-compat — kept for any code still calling the bundle endpoint
    async def underwriting_checks(self):
        async with self._lock:
            return self._underwriting_checks

    # ---------------- Me ----------------

    async def me(self) -> UserProfile:
        return self._me

    # ---------------- Helpers ----------------

    def _enforce_cap(self) -> None:
        cap = self._settings.max_sessions
        if len(self._sessions) <= cap:
            return
        ordered = sorted(
            self._sessions.values(), key=lambda s: s.updated_at, reverse=True
        )
        keep_ids = {s.id for s in ordered[:cap]}
        for sid in list(self._sessions.keys()):
            if sid not in keep_ids:
                self._sessions.pop(sid, None)

    @staticmethod
    def _to_summary(session: ChatSession) -> SessionSummary:
        last = next(
            (m for m in reversed(session.messages) if (m.content or "").strip()),
            None,
        )
        preview = "No messages yet"
        if last is not None:
            preview = " ".join(last.content.split())
            preview = preview if len(preview) <= 70 else preview[:67] + "…"
        return SessionSummary(
            id=session.id, title=session.title,
            created_at=session.created_at, updated_at=session.updated_at,
            message_count=len(session.messages), last_message_preview=preview,
        )

    @staticmethod
    def _title_from(content: str) -> str:
        clean = " ".join(content.split())
        return clean if len(clean) <= 48 else clean[:45].rstrip() + "…"

    @staticmethod
    def _initials_from(name: str) -> str:
        parts = [p for p in name.split() if p]
        if not parts: return "?"
        if len(parts) == 1: return parts[0][:2].upper()
        return (parts[0][0] + parts[-1][0]).upper()


_store: Store | None = None


def get_store() -> Store:
    global _store
    if _store is None:
        _store = Store()
    return _store
