"""Sales inventory — policy pipeline tracking."""

from datetime import datetime
from enum import Enum
from .chat import Base


# ────────────────────────────────────────────────────────────────
# Status codes — the 6 stages a policy can be in
# ────────────────────────────────────────────────────────────────

class PolicyStatus(str, Enum):
    fresh_business = "Fresh Business"   # Initial entry, just submitted
    new_business   = "New Business"     # Confirmed entry into pipeline
    pending_uw     = "PENDING UW"       # Under underwriting review
    pfr            = "PFR"              # Pending For Requirements (docs needed)
    rfi            = "RFI"              # Request For Information (clarifications)
    na             = "NA"               # Not Applicable / declined / withdrawn


class UnderwritingStage(str, Enum):
    """Legacy stage enum used by older FLS rows."""
    submitted = "Submitted"
    medical = "Medical"
    in_review = "In Review"
    approved = "Approved"
    issued = "Issued"
    declined = "Declined"


# ────────────────────────────────────────────────────────────────
# Status history — every change a policy went through
# ────────────────────────────────────────────────────────────────

class StatusHistoryEntry(Base):
    """One row of a policy's status timeline."""
    status: PolicyStatus
    entered_at: datetime
    comment: str                        # Why it entered this status
    required_documents: list[str]       # Docs needed to clear this status
    completed_at: datetime | None = None # None = still at this status


# ────────────────────────────────────────────────────────────────
# Policy record — one row of the salesperson's pipeline
# ────────────────────────────────────────────────────────────────

class PolicyRecord(Base):
    id: str
    policy_id: str                  # Display ID, e.g. "POL-2026-04812"
    application_id: str             # Application ID, e.g. "APP-78521-Q2"
    customer_name: str
    plan_name: str
    sum_assured: float              # in INR
    annual_premium: float           # in INR
    current_status: PolicyStatus
    submitted_date: datetime
    last_updated: datetime
    history: list[StatusHistoryEntry]


# ────────────────────────────────────────────────────────────────
# Pipeline summary — Flavor 1 (aggregate dashboard)
# ────────────────────────────────────────────────────────────────

class StatusBucket(Base):
    """Aggregate stats for a single status bucket."""
    status: PolicyStatus
    count: int
    total_premium: float            # sum of annual premiums in this bucket
    total_sum_assured: float        # sum of sum-assured in this bucket
    pct_of_total: float             # 0..100 — share of total policies


class PipelineSummary(Base):
    """Full Flavor-1 payload — every bucket plus grand totals."""
    period_label: str               # e.g. "Q2 FY26"
    total_policies: int
    total_premium: float
    total_sum_assured: float
    buckets: list[StatusBucket]


# ────────────────────────────────────────────────────────────────
# Legacy types kept so existing chat-engine / seed imports keep working
# ────────────────────────────────────────────────────────────────

class InventoryRow(Base):
    """Legacy FLS row — used by chat attachments & old seed paths."""
    id: str
    fls_id: str
    nop: int
    pfr: str
    underwriting_stage: UnderwritingStage
    submission: int
    issuance: int
    total_nop: int


class InventoryStat(Base):
    label: str
    value: str
    delta: str
    delta_up: bool
