"""Pydantic models — public exports."""

from .chat import (
    ChatAttachment,
    ChatMessage,
    ChatSession,
    InsuranceProduct,
    InsuranceProductType,
    MessageAuthor,
    NewMessageRequest,
    NewMessageResponse,
    NewSessionRequest,
    ProductCardsAttachment,
    QuickAction,
    SessionSummary,
    UnderwritingAttachment,
    UnderwritingDoc,        # legacy — used by chat attachment
)
from .incentives import (
    EarningsSummary,
    FYRenewalKPI,
    Incentive,
    IncentiveBreakdown,
    IncentiveDashboard,
    IncentiveTag,
    NewBusinessKPI,
    NOPKPI,
    ShortfallTier,
)
from .intake import FinancialGoal, IntakeProfile, Occupation
from .inventory import (
    InventoryRow,
    InventoryStat,
    PipelineSummary,
    PolicyRecord,
    PolicyStatus,
    StatusBucket,
    StatusHistoryEntry,
    UnderwritingStage,
)
from .leads import Lead, LeadCreate, LeadStage, LeadUpdate
from .library import LibraryCategory, LibraryDocument
from .me import UserProfile
from .underwriting import (
    FinancialSucEntry,
    OccupationsResponse,
    ProductsResponse,
    RequestType,
    SucResponse,
    UnderwritingChecksBundle,
    UnderwritingRecord,
)

__all__ = [
    "ChatAttachment", "ChatMessage", "ChatSession", "InsuranceProduct",
    "InsuranceProductType", "MessageAuthor", "NewMessageRequest",
    "NewMessageResponse", "NewSessionRequest", "ProductCardsAttachment",
    "QuickAction", "SessionSummary", "UnderwritingAttachment",
    "UnderwritingDoc",
    "EarningsSummary", "FYRenewalKPI", "Incentive", "IncentiveBreakdown",
    "IncentiveDashboard", "IncentiveTag", "NewBusinessKPI", "NOPKPI",
    "ShortfallTier",
    "FinancialGoal", "IntakeProfile", "Occupation",
    "InventoryRow", "InventoryStat", "PipelineSummary", "PolicyRecord",
    "PolicyStatus", "StatusBucket", "StatusHistoryEntry", "UnderwritingStage",
    "Lead", "LeadCreate", "LeadStage", "LeadUpdate",
    "LibraryCategory", "LibraryDocument",
    "UserProfile",
    "FinancialSucEntry", "OccupationsResponse", "ProductsResponse",
    "RequestType", "SucResponse", "UnderwritingChecksBundle",
    "UnderwritingRecord",
]
