import { Injectable, inject } from '@angular/core';
import { HttpClient, HttpParams } from '@angular/common/http';
import { Observable } from 'rxjs';

import {
  ChatMessage,
  ChatSession,
  InsuranceProduct,
} from '../models/chat.model';

// =========================
//  Backend response shapes
// =========================

export interface SessionSummary {
  id: string;
  title: string;
  createdAt: string;        // ISO
  updatedAt: string;        // ISO
  messageCount: number;
  lastMessagePreview: string;
}

export interface NewMessageResponse {
  userMessage: ChatMessage;
  botMessage: ChatMessage;
}

export interface InventoryRow {
  id: string;
  flsId: string;
  nop: number;
  pfr: string;
  underwritingStage:
    | 'Submitted' | 'Medical' | 'In Review'
    | 'Approved'  | 'Issued'  | 'Declined';
  submission: number;
  issuance: number;
  totalNop: number;
}

export type UnderwritingStage = InventoryRow['underwritingStage'];

export interface InventoryStat {
  label: string; value: string; delta: string; deltaUp: boolean;
}

// ★ ──────────── Policy pipeline (new) ────────────

export type PolicyStatus =
  | 'Fresh Business' | 'New Business' | 'PENDING UW'
  | 'PFR' | 'RFI' | 'NA';

export interface StatusHistoryEntry {
  status: PolicyStatus;
  enteredAt: string;              // ISO timestamp
  comment: string;
  requiredDocuments: string[];
  completedAt: string | null;     // null = still at this status
}

export interface PolicyRecord {
  id: string;
  policyId: string;               // e.g. "POL-2026-04812"
  applicationId: string;          // e.g. "APP-78521-Q2"
  customerName: string;
  planName: string;
  sumAssured: number;
  annualPremium: number;
  currentStatus: PolicyStatus;
  submittedDate: string;
  lastUpdated: string;
  history: StatusHistoryEntry[];
}

export interface StatusBucket {
  status: PolicyStatus;
  count: number;
  totalPremium: number;
  totalSumAssured: number;
  pctOfTotal: number;
}

export interface PipelineSummary {
  periodLabel: string;
  totalPolicies: number;
  totalPremium: number;
  totalSumAssured: number;
  buckets: StatusBucket[];
}

// ---- Underwriting checks ----

/** ★ Four supported tabs / request_type values. */
export type RequestType =
  | 'Financial'
  | 'Medical-Non Disclosure'
  | 'Medical-Disclosure'
  | 'Non-Medical';

/** One entry in the MongoDB document's financial_suc array. */
export interface FinancialSucEntry {
  ageLimit: string;                // e.g. "0-1Cr"
  financialRequirement: string[];  // list of requirement notes (often empty)
  documentList: string[];
}

/** A/B — Plan dropdown payload */
export interface ProductsResponse {
  requestType: RequestType | null;
  products: string[];
}

/** C — Occupation dropdown payload */
export interface OccupationsResponse {
  productType: string;
  requestType: RequestType;
  occupations: string[];
}

/** D — Final SUC + requirements + documents response */
export interface SucResponse {
  productType: string;
  requestType: RequestType;
  occupationType: string;
  financialSuc: FinancialSucEntry[];
}

/** Legacy combined bundle (unused by the UI but kept for /checks endpoint) */
export interface UnderwritingRecord {
  productType: string;
  requestType: RequestType;
  occupationType: string;
  financialSuc: FinancialSucEntry[];
}
export interface UnderwritingChecksBundle {
  documents: UnderwritingRecord[];
}

// ---- Library ----

export type LibraryCategory =
  | 'Products' | 'Underwriting' | 'Compliance' | 'Training' | 'Tax & Regulations';

export interface LibraryDocument {
  id: string;
  title: string;
  description: string;
  category: LibraryCategory;
  pages: number;
  sizeKb: number;
  updatedAt: string;     // ISO
  downloadUrl: string;   // relative to API base
}

export interface EarningsSummary {
  periodLabel: string; amount: string;
  deltaPct: number; deltaUp: boolean;
  nextTierLabel: string; nextTierAmount: string; nextTierRemaining: string;
  currentTierLabel: string; progressPct: number;
}

export interface Incentive {
  id: string; title: string; reward: string;
  progress: number; current: string; target: string;
  deadline: string; tag: 'Active' | 'Closing soon' | 'Stretch';
}

// ★ ──────────── Incentive dashboard (new) ────────────

export interface ShortfallTier {
  thresholdPct: number;          // 75, 80, 85, 90, 95, 100
  thresholdAmount: number;       // absolute amount needed to hit threshold
  shortfall: number;             // 0 if reached
  reached: boolean;
}

export interface NewBusinessKPI {
  target: number;
  netAchievement: number;
  achievedPct: number;
  shortfalls: ShortfallTier[];
}

export interface FYRenewalKPI {
  collectible: number;
  collection: number;
  collectionPct: number;
  shortfalls: ShortfallTier[];
}

export interface NOPKPI {
  target: number;
  netNop: number;
  achievedPct: number;
}

export interface IncentiveBreakdown {
  baseNbIncentive: number;
  persistencyMultiplier: number;
  finalNopBooster: number;
  sqmDeduction: number;
  finalIncentiveWithSqm: number; // hero figure
}

export interface IncentiveDashboard {
  periodLabel: string;
  finalIncentive: number;
  newBusiness: NewBusinessKPI;
  fyRenewal: FYRenewalKPI;
  nop: NOPKPI;
  breakdown: IncentiveBreakdown;
}

export type LeadStage = 'New' | 'Contacted' | 'Quoted' | 'Negotiating' | 'Closed';

export interface Lead {
  id: string; initials: string; name: string; city: string;
  interest: string; potential: string;
  stage: LeadStage; nextAction: string; hot: boolean;
}

export interface LeadCreate {
  name: string; city: string; interest: string; potential: string;
  stage?: LeadStage; nextAction?: string; hot?: boolean;
}

export interface LeadUpdate {
  stage?: LeadStage; nextAction?: string; hot?: boolean;
}

// ---- Intake (Product Recommendation entry form) ----

export type FinancialGoal =
  | 'Term' | 'Guaranteed Return' | 'Retirement'
  | 'Investment' | 'Annuity' | 'Education' | 'Wealth Creation';

export type Occupation = 'Salaried' | 'Self-employed';

export interface IntakeProfile {
  financialGoal: FinancialGoal;
  age: number;
  annualIncomeLakhs: number;
  occupation: Occupation;
  dependents: number;
  /** Only set when financialGoal === 'Term' */
  tobaccoUse?: boolean | null;
}

export interface UserProfile {
  id: string; name: string; initials: string; role: string; email: string;
}

/**
 * Thin HTTP wrapper around the FastAPI backend.
 * Base URL is read from window.__API_BASE_URL__ if present, else falls back to localhost:8000.
 * Override at runtime by setting `<script>window.__API_BASE_URL__='...'</script>` in index.html.
 */
@Injectable({ providedIn: 'root' })
export class ApiService {
  private readonly http = inject(HttpClient);

  private readonly base = (window as any).__API_BASE_URL__
    ?? 'http://localhost:8000';

  private url(path: string): string {
    return `${this.base}${path}`;
  }

  // ---------- Me ----------
  getMe(): Observable<UserProfile> {
    return this.http.get<UserProfile>(this.url('/api/me'));
  }

  // ---------- Sessions ----------
  listSessions(): Observable<SessionSummary[]> {
    return this.http.get<SessionSummary[]>(this.url('/api/sessions'));
  }

  getSession(id: string): Observable<ChatSession> {
    return this.http.get<ChatSession>(this.url(`/api/sessions/${id}`));
  }

  createSession(opts?: { title?: string; intake?: IntakeProfile }): Observable<ChatSession> {
    return this.http.post<ChatSession>(this.url('/api/sessions'), {
      title: opts?.title,
      intake: opts?.intake,
    });
  }

  deleteSession(id: string): Observable<void> {
    return this.http.delete<void>(this.url(`/api/sessions/${id}`));
  }

  sendMessage(sessionId: string, content: string): Observable<NewMessageResponse> {
    return this.http.post<NewMessageResponse>(
      this.url(`/api/sessions/${sessionId}/messages`),
      { content }
    );
  }

  // ---------- Inventory ----------
  listInventory(filters?: {
    stage?: UnderwritingStage; q?: string;
  }): Observable<InventoryRow[]> {
    let params = new HttpParams();
    if (filters?.stage) params = params.set('stage', filters.stage);
    if (filters?.q)     params = params.set('q', filters.q);
    return this.http.get<InventoryRow[]>(this.url('/api/inventory'), { params });
  }

  inventoryStats(): Observable<InventoryStat[]> {
    return this.http.get<InventoryStat[]>(this.url('/api/inventory/stats'));
  }

  // ★ ──────────── Pipeline (Flavor 1 — aggregate dashboard) ────────────
  pipelineSummary(): Observable<PipelineSummary> {
    return this.http.get<PipelineSummary>(this.url('/api/inventory/pipeline-summary'));
  }

  // ★ ──────────── Policies list (drill-down + search) ────────────
  listPolicies(filters?: {
    status?: PolicyStatus; q?: string;
  }): Observable<PolicyRecord[]> {
    let params = new HttpParams();
    if (filters?.status) params = params.set('status', filters.status);
    if (filters?.q)      params = params.set('q', filters.q);
    return this.http.get<PolicyRecord[]>(this.url('/api/inventory/policies'), { params });
  }

  // ★ ──────────── Policy detail (Flavor 2 — full timeline) ────────────
  getPolicy(identifier: string): Observable<PolicyRecord> {
    return this.http.get<PolicyRecord>(this.url(`/api/inventory/policies/${encodeURIComponent(identifier)}`));
  }

  // ---------- Underwriting checks ----------
  underwritingChecks(): Observable<UnderwritingChecksBundle> {
    return this.http.get<UnderwritingChecksBundle>(this.url('/api/underwriting/checks'));
  }

  /**
   * ★ A/B — Plan-name dropdown. Pass requestType to get only products
   * that have at least one document for that tab.
   */
  listProducts(requestType?: RequestType): Observable<ProductsResponse> {
    let params = new HttpParams();
    if (requestType) params = params.set('requestType', requestType);
    return this.http.get<ProductsResponse>(this.url('/api/underwriting/products'), { params });
  }

  /** ★ C — Occupations for the selected plan + tab. */
  listOccupations(
    productType: string, requestType: RequestType,
  ): Observable<OccupationsResponse> {
    const params = new HttpParams()
      .set('productType', productType)
      .set('requestType', requestType);
    return this.http.get<OccupationsResponse>(this.url('/api/underwriting/occupations'), { params });
  }

  /** ★ D — SUC array (age limits + requirements + documents) for the full triple. */
  getSuc(
    productType: string, requestType: RequestType, occupationType: string,
  ): Observable<SucResponse> {
    const params = new HttpParams()
      .set('productType', productType)
      .set('requestType', requestType)
      .set('occupationType', occupationType);
    return this.http.get<SucResponse>(this.url('/api/underwriting/suc'), { params });
  }

  // ---------- Library ----------
  listLibrary(filters?: {
    category?: LibraryCategory; q?: string;
  }): Observable<LibraryDocument[]> {
    let params = new HttpParams();
    if (filters?.category) params = params.set('category', filters.category);
    if (filters?.q)        params = params.set('q', filters.q);
    return this.http.get<LibraryDocument[]>(this.url('/api/library'), { params });
  }

  /** Resolves a backend-relative URL (e.g. /static/pdfs/foo.pdf) to absolute. */
  absoluteUrl(relative: string): string {
    if (!relative) return '';
    if (relative.startsWith('http://') || relative.startsWith('https://')) return relative;
    return `${this.base}${relative}`;
  }

  // ---------- Incentives ----------
  earningsSummary(): Observable<EarningsSummary> {
    return this.http.get<EarningsSummary>(this.url('/api/incentives/summary'));
  }

  listIncentives(tag?: string): Observable<Incentive[]> {
    let params = new HttpParams();
    if (tag) params = params.set('tag', tag);
    return this.http.get<Incentive[]>(this.url('/api/incentives/contests'), { params });
  }

  // ★ ──────────── Incentive dashboard (targets vs achievement) ────────────
  incentiveDashboard(): Observable<IncentiveDashboard> {
    return this.http.get<IncentiveDashboard>(this.url('/api/incentives/dashboard'));
  }

  // ---------- Leads ----------
  listLeads(stage?: LeadStage): Observable<Lead[]> {
    let params = new HttpParams();
    if (stage) params = params.set('stage', stage);
    return this.http.get<Lead[]>(this.url('/api/leads'), { params });
  }

  leadCounts(): Observable<Record<string, number>> {
    return this.http.get<Record<string, number>>(this.url('/api/leads/counts'));
  }

  createLead(body: LeadCreate): Observable<Lead> {
    return this.http.post<Lead>(this.url('/api/leads'), body);
  }

  updateLead(id: string, patch: LeadUpdate): Observable<Lead> {
    return this.http.patch<Lead>(this.url(`/api/leads/${id}`), patch);
  }

  deleteLead(id: string): Observable<void> {
    return this.http.delete<void>(this.url(`/api/leads/${id}`));
  }
}

/**
 * Helper to coerce server timestamps (ISO strings) into Date objects on
 * ChatMessage/ChatSession before they hit the UI bindings that use the
 * `date` pipe.
 */
export function rehydrateMessage(m: ChatMessage): ChatMessage {
  return { ...m, timestamp: new Date(m.timestamp as unknown as string) };
}

export function rehydrateSession(s: ChatSession): ChatSession {
  return {
    ...s,
    createdAt: new Date(s.createdAt as unknown as string),
    updatedAt: new Date(s.updatedAt as unknown as string),
    messages: s.messages.map(rehydrateMessage),
  };
}

/** Type-narrowed helper for product-cards attachment (used by callers). */
export function isProductCards(att: any): att is { kind: 'product-cards'; products: InsuranceProduct[] } {
  return att?.kind === 'product-cards';
}
