import {
  ChangeDetectionStrategy,
  Component,
  computed,
  inject,
  signal,
} from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { firstValueFrom } from 'rxjs';

import {
  ApiService,
  PipelineSummary,
  PolicyRecord,
  PolicyStatus,
  StatusBucket,
} from '../../core/services/api.service';

type ViewMode = 'overview' | 'lookup';

interface StatusStyle {
  bg: string;          // pill bg class
  text: string;        // pill text class
  ring: string;        // border ring class
  dot: string;         // small accent dot
  bar: string;         // segmented bar segment color
}

@Component({
  selector: 'app-inventory',
  standalone: true,
  imports: [CommonModule, FormsModule],
  changeDetection: ChangeDetectionStrategy.OnPush,
  templateUrl: './inventory.component.html',
})
export class InventoryComponent {
  private readonly api = inject(ApiService);

  // ───── View mode + shared state ─────
  protected readonly mode = signal<ViewMode>('overview');

  // ───── Overview (Flavor 1) ─────
  protected readonly summary = signal<PipelineSummary | null>(null);
  protected readonly summaryLoading = signal(false);
  protected readonly summaryError = signal<string | null>(null);

  /** When the user clicks a status tile we drill-down into the list. */
  protected readonly drillStatus = signal<PolicyStatus | null>(null);
  protected readonly drillPolicies = signal<PolicyRecord[]>([]);
  protected readonly drillLoading = signal(false);

  // ───── Lookup (Flavor 2) ─────
  protected readonly lookupQuery = signal<string>('');
  protected readonly lookupResults = signal<PolicyRecord[]>([]);
  protected readonly selectedPolicy = signal<PolicyRecord | null>(null);
  protected readonly lookupLoading = signal(false);
  protected readonly lookupError = signal<string | null>(null);
  protected readonly hasSearched = signal(false);

  // ───── Status → colour mapping ─────
  protected readonly STATUS_STYLE: Record<PolicyStatus, StatusStyle> = {
    'Fresh Business': { bg: 'bg-blue-50',   text: 'text-blue-700',   ring: 'border-blue-200',   dot: 'bg-blue-500',   bar: 'bg-blue-500'   },
    'New Business':   { bg: 'bg-violet-50', text: 'text-violet-700', ring: 'border-violet-200', dot: 'bg-violet-500', bar: 'bg-violet-500' },
    'PENDING UW':     { bg: 'bg-amber-50',  text: 'text-amber-700',  ring: 'border-amber-200',  dot: 'bg-amber-500',  bar: 'bg-amber-500'  },
    'PFR':            { bg: 'bg-orange-50', text: 'text-orange-700', ring: 'border-orange-200', dot: 'bg-orange-500', bar: 'bg-orange-500' },
    'RFI':            { bg: 'bg-rose-50',   text: 'text-rose-700',   ring: 'border-rose-200',   dot: 'bg-rose-500',   bar: 'bg-rose-500'   },
    'NA':             { bg: 'bg-ink-100',   text: 'text-ink-600',    ring: 'border-ink-200',    dot: 'bg-ink-400',    bar: 'bg-ink-400'    },
  };

  // ───── Init ─────
  constructor() { void this.loadSummary(); }

  protected styleFor(status: PolicyStatus): StatusStyle {
    return this.STATUS_STYLE[status];
  }

  // ╭─────────────────────────────────────────────────────╮
  // │ Overview                                            │
  // ╰─────────────────────────────────────────────────────╯

  private async loadSummary(): Promise<void> {
    this.summaryLoading.set(true);
    this.summaryError.set(null);
    try {
      this.summary.set(await firstValueFrom(this.api.pipelineSummary()));
    } catch (err) {
      this.summaryError.set(
        err instanceof Error ? err.message : 'Failed to load pipeline summary'
      );
    } finally {
      this.summaryLoading.set(false);
    }
  }

  protected async openDrillDown(status: PolicyStatus): Promise<void> {
    // Toggle off if same status clicked twice
    if (this.drillStatus() === status) {
      this.drillStatus.set(null);
      this.drillPolicies.set([]);
      return;
    }
    this.drillStatus.set(status);
    this.drillLoading.set(true);
    try {
      this.drillPolicies.set(
        await firstValueFrom(this.api.listPolicies({ status }))
      );
    } catch {
      this.drillPolicies.set([]);
    } finally {
      this.drillLoading.set(false);
    }
  }

  /** Jump from a drill-down row to the full lookup view. */
  protected async openInLookup(policy: PolicyRecord): Promise<void> {
    this.mode.set('lookup');
    this.lookupQuery.set(policy.policyId);
    this.lookupResults.set([policy]);
    this.selectedPolicy.set(policy);
    this.hasSearched.set(true);
  }

  // ╭─────────────────────────────────────────────────────╮
  // │ Lookup                                              │
  // ╰─────────────────────────────────────────────────────╯

  protected async runSearch(): Promise<void> {
    const q = this.lookupQuery().trim();
    if (!q) return;
    this.lookupLoading.set(true);
    this.lookupError.set(null);
    this.hasSearched.set(true);
    this.selectedPolicy.set(null);
    try {
      const results = await firstValueFrom(this.api.listPolicies({ q }));
      this.lookupResults.set(results);
      // If exactly one result, auto-select it
      if (results.length === 1) {
        this.selectedPolicy.set(results[0]);
      }
    } catch (err) {
      this.lookupError.set(err instanceof Error ? err.message : 'Search failed');
      this.lookupResults.set([]);
    } finally {
      this.lookupLoading.set(false);
    }
  }

  protected selectPolicy(policy: PolicyRecord): void {
    this.selectedPolicy.set(policy);
  }

  protected clearLookup(): void {
    this.lookupQuery.set('');
    this.lookupResults.set([]);
    this.selectedPolicy.set(null);
    this.hasSearched.set(false);
    this.lookupError.set(null);
  }

  // ╭─────────────────────────────────────────────────────╮
  // │ Formatters                                          │
  // ╰─────────────────────────────────────────────────────╯

  /** Format an INR amount as ₹X.YY L / ₹X.YY Cr (Indian numbering). */
  protected formatInr(amount: number): string {
    if (amount >= 1_00_00_000) return `₹${(amount / 1_00_00_000).toFixed(2)} Cr`;
    if (amount >= 1_00_000)    return `₹${(amount / 1_00_000).toFixed(2)} L`;
    if (amount >= 1_000)       return `₹${(amount / 1_000).toFixed(1)} K`;
    return `₹${amount.toFixed(0)}`;
  }

  protected formatDate(iso: string): string {
    const d = new Date(iso);
    return d.toLocaleDateString('en-IN', { day: '2-digit', month: 'short', year: 'numeric' });
  }
}
