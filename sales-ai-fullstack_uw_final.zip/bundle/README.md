# Sales AI Assistant — Full Stack

Angular 18 + Tailwind v4 frontend, FastAPI + Pydantic 2 backend.

## Run

```bash
# Terminal 1 — backend
cd backend && python -m venv .venv && source .venv/bin/activate
pip install -r requirements.txt
uvicorn app.main:app --reload --port 8000

# Terminal 2 — frontend
cd frontend && npm install && npm start
```

## Underwriting Checks — every tab is a workflow

All four tabs now follow the same Plan → narrowing → Requirements pattern:

| Tab | Step 1 inputs | Step 2 | Step 3 output |
|---|---|---|---|
| Financial | Plan + Occupation | Financial SUC | Table: [SUC, Requirement, Documents] |
| Medical · Non-Disclosure | Plan + Age Group | Medical SUC | Table: [SUC, Requirement pills] |
| Medical · Disclosure | Plan + Age Group | Medical SUC | Table: [SUC, Requirement pills] |
| Non-Medical (VMER) | Plan + Age Group | — | Card: [VMER Requirement pills] |

Each tab maintains independent state, so switching tabs preserves selections.

## API surface (underwriting)

| Endpoint | Purpose |
|---|---|
| `GET /api/underwriting/options` | Plans + occupations + age-limits — single fetch for every dropdown |
| `GET /api/underwriting/financial?plan=&occupation=&suc=` | Financial workflow filter |
| `GET /api/underwriting/medical-non-disclosure?plan=&ageLimit=&suc=` | Med. Non-Disclosure filter |
| `GET /api/underwriting/medical-disclosure?plan=&ageLimit=&suc=` | Med. Disclosure filter |
| `GET /api/underwriting/non-medical?plan=&ageLimit=` | Non-Medical (VMER) filter |
| `GET /api/underwriting/checks` | Backward-compat combined payload |
