import { Injectable, inject } from '@angular/core';
import { HttpClient, HttpParams } from '@angular/common/http';
import { Observable } from 'rxjs';

import {
  ChatMessage,
  ChatSession,
  InsuranceProduct,
} from '../models/chat.model';

// =========================
//  Backend response shapes
// =========================

export interface SessionSummary {
  id: string;
  title: string;
  createdAt: string;        // ISO
  updatedAt: string;        // ISO
  messageCount: number;
  lastMessagePreview: string;
}

export interface NewMessageResponse {
  userMessage: ChatMessage;
  botMessage: ChatMessage;
}

export interface InventoryRow {
  id: string;
  flsId: string;
  nop: number;
  pfr: string;
  underwritingStage:
    | 'Submitted' | 'Medical' | 'In Review'
    | 'Approved'  | 'Issued'  | 'Declined';
  submission: number;
  issuance: number;
  totalNop: number;
}

export type UnderwritingStage = InventoryRow['underwritingStage'];

export interface InventoryStat {
  label: string; value: string; delta: string; deltaUp: boolean;
}

// ---- Underwriting checks ----

export type PlanName =
  | 'Term' | 'ULIP' | 'Endowment' | 'Pension'
  | 'Whole Life' | 'Money Back' | 'Child Plan';

/** ★ Renamed from FinancialOptions — single options bundle for every tab. */
export interface UnderwritingOptions {
  plans: PlanName[];
  occupations: string[];          // used by Financial tab
  ageLimits: string[];            // used by Medical & Non-Medical tabs
}
// Backward-compat alias
export type FinancialOptions = UnderwritingOptions;

export interface FinancialCheck {
  id: string;
  planName: PlanName;
  financialSuc: string;
  occupationLifeType: string;
  financialRequirement: string;
  documentsList: string[];
}

export interface MedicalCheck {
  id: string;
  planName: PlanName;             // ★ NEW
  ageLimit: string;
  medicalSuc: string;
  medicalRequirements: string[];
}

export interface NonMedicalCheck {
  id: string;
  planName: PlanName;             // ★ NEW
  ageLimit: string;
  vmerRequirements: string[];
}

export interface UnderwritingChecksBundle {
  financial: FinancialCheck[];
  medicalNonDisclosure: MedicalCheck[];
  medicalDisclosure: MedicalCheck[];
  nonMedical: NonMedicalCheck[];
}

// ---- Library ----

export type LibraryCategory =
  | 'Products' | 'Underwriting' | 'Compliance' | 'Training' | 'Tax & Regulations';

export interface LibraryDocument {
  id: string;
  title: string;
  description: string;
  category: LibraryCategory;
  pages: number;
  sizeKb: number;
  updatedAt: string;     // ISO
  downloadUrl: string;   // relative to API base
}

export interface EarningsSummary {
  periodLabel: string; amount: string;
  deltaPct: number; deltaUp: boolean;
  nextTierLabel: string; nextTierAmount: string; nextTierRemaining: string;
  currentTierLabel: string; progressPct: number;
}

export interface Incentive {
  id: string; title: string; reward: string;
  progress: number; current: string; target: string;
  deadline: string; tag: 'Active' | 'Closing soon' | 'Stretch';
}

export type LeadStage = 'New' | 'Contacted' | 'Quoted' | 'Negotiating' | 'Closed';

export interface Lead {
  id: string; initials: string; name: string; city: string;
  interest: string; potential: string;
  stage: LeadStage; nextAction: string; hot: boolean;
}

export interface LeadCreate {
  name: string; city: string; interest: string; potential: string;
  stage?: LeadStage; nextAction?: string; hot?: boolean;
}

export interface LeadUpdate {
  stage?: LeadStage; nextAction?: string; hot?: boolean;
}

// ---- Intake (Product Recommendation entry form) ----

export type FinancialGoal =
  | 'Term' | 'Guaranteed Return' | 'Retirement'
  | 'Investment' | 'Annuity' | 'Education' | 'Wealth Creation';

export type Occupation = 'Salaried' | 'Self-employed';

export interface IntakeProfile {
  financialGoal: FinancialGoal;
  age: number;
  annualIncomeLakhs: number;
  occupation: Occupation;
  dependents: number;
  /** Only set when financialGoal === 'Term' */
  tobaccoUse?: boolean | null;
}

export interface UserProfile {
  id: string; name: string; initials: string; role: string; email: string;
}

/**
 * Thin HTTP wrapper around the FastAPI backend.
 * Base URL is read from window.__API_BASE_URL__ if present, else falls back to localhost:8000.
 * Override at runtime by setting `<script>window.__API_BASE_URL__='...'</script>` in index.html.
 */
@Injectable({ providedIn: 'root' })
export class ApiService {
  private readonly http = inject(HttpClient);

  private readonly base = (window as any).__API_BASE_URL__
    ?? 'http://localhost:8000';

  private url(path: string): string {
    return `${this.base}${path}`;
  }

  // ---------- Me ----------
  getMe(): Observable<UserProfile> {
    return this.http.get<UserProfile>(this.url('/api/me'));
  }

  // ---------- Sessions ----------
  listSessions(): Observable<SessionSummary[]> {
    return this.http.get<SessionSummary[]>(this.url('/api/sessions'));
  }

  getSession(id: string): Observable<ChatSession> {
    return this.http.get<ChatSession>(this.url(`/api/sessions/${id}`));
  }

  createSession(opts?: { title?: string; intake?: IntakeProfile }): Observable<ChatSession> {
    return this.http.post<ChatSession>(this.url('/api/sessions'), {
      title: opts?.title,
      intake: opts?.intake,
    });
  }

  deleteSession(id: string): Observable<void> {
    return this.http.delete<void>(this.url(`/api/sessions/${id}`));
  }

  sendMessage(sessionId: string, content: string): Observable<NewMessageResponse> {
    return this.http.post<NewMessageResponse>(
      this.url(`/api/sessions/${sessionId}/messages`),
      { content }
    );
  }

  // ---------- Inventory ----------
  listInventory(filters?: {
    stage?: UnderwritingStage; q?: string;
  }): Observable<InventoryRow[]> {
    let params = new HttpParams();
    if (filters?.stage) params = params.set('stage', filters.stage);
    if (filters?.q)     params = params.set('q', filters.q);
    return this.http.get<InventoryRow[]>(this.url('/api/inventory'), { params });
  }

  inventoryStats(): Observable<InventoryStat[]> {
    return this.http.get<InventoryStat[]>(this.url('/api/inventory/stats'));
  }

  // ---------- Underwriting checks ----------
  underwritingChecks(): Observable<UnderwritingChecksBundle> {
    return this.http.get<UnderwritingChecksBundle>(this.url('/api/underwriting/checks'));
  }

  /** ★ Single options endpoint serving every tab's first-step dropdowns. */
  underwritingOptions(): Observable<UnderwritingOptions> {
    return this.http.get<UnderwritingOptions>(this.url('/api/underwriting/options'));
  }

  // Backward-compat alias
  financialOptions(): Observable<UnderwritingOptions> {
    return this.underwritingOptions();
  }

  /** Financial — filter by Plan / Occupation / SUC */
  listFinancial(filters?: {
    plan?: PlanName; occupation?: string; suc?: string;
  }): Observable<FinancialCheck[]> {
    let params = new HttpParams();
    if (filters?.plan)       params = params.set('plan',       filters.plan);
    if (filters?.occupation) params = params.set('occupation', filters.occupation);
    if (filters?.suc)        params = params.set('suc',        filters.suc);
    return this.http.get<FinancialCheck[]>(this.url('/api/underwriting/financial'), { params });
  }

  /** ★ NEW — Medical Non-Disclosure: filter by Plan / AgeLimit / SUC */
  listMedicalNonDisclosure(filters?: {
    plan?: PlanName; ageLimit?: string; suc?: string;
  }): Observable<MedicalCheck[]> {
    let params = new HttpParams();
    if (filters?.plan)      params = params.set('plan',      filters.plan);
    if (filters?.ageLimit)  params = params.set('ageLimit',  filters.ageLimit);
    if (filters?.suc)       params = params.set('suc',       filters.suc);
    return this.http.get<MedicalCheck[]>(this.url('/api/underwriting/medical-non-disclosure'), { params });
  }

  /** ★ NEW — Medical Disclosure: filter by Plan / AgeLimit / SUC */
  listMedicalDisclosure(filters?: {
    plan?: PlanName; ageLimit?: string; suc?: string;
  }): Observable<MedicalCheck[]> {
    let params = new HttpParams();
    if (filters?.plan)      params = params.set('plan',      filters.plan);
    if (filters?.ageLimit)  params = params.set('ageLimit',  filters.ageLimit);
    if (filters?.suc)       params = params.set('suc',       filters.suc);
    return this.http.get<MedicalCheck[]>(this.url('/api/underwriting/medical-disclosure'), { params });
  }

  /** ★ NEW — Non-Medical (VMER): filter by Plan / AgeLimit */
  listNonMedical(filters?: {
    plan?: PlanName; ageLimit?: string;
  }): Observable<NonMedicalCheck[]> {
    let params = new HttpParams();
    if (filters?.plan)     params = params.set('plan',     filters.plan);
    if (filters?.ageLimit) params = params.set('ageLimit', filters.ageLimit);
    return this.http.get<NonMedicalCheck[]>(this.url('/api/underwriting/non-medical'), { params });
  }

  // ---------- Library ----------
  listLibrary(filters?: {
    category?: LibraryCategory; q?: string;
  }): Observable<LibraryDocument[]> {
    let params = new HttpParams();
    if (filters?.category) params = params.set('category', filters.category);
    if (filters?.q)        params = params.set('q', filters.q);
    return this.http.get<LibraryDocument[]>(this.url('/api/library'), { params });
  }

  /** Resolves a backend-relative URL (e.g. /static/pdfs/foo.pdf) to absolute. */
  absoluteUrl(relative: string): string {
    if (!relative) return '';
    if (relative.startsWith('http://') || relative.startsWith('https://')) return relative;
    return `${this.base}${relative}`;
  }

  // ---------- Incentives ----------
  earningsSummary(): Observable<EarningsSummary> {
    return this.http.get<EarningsSummary>(this.url('/api/incentives/summary'));
  }

  listIncentives(tag?: string): Observable<Incentive[]> {
    let params = new HttpParams();
    if (tag) params = params.set('tag', tag);
    return this.http.get<Incentive[]>(this.url('/api/incentives/contests'), { params });
  }

  // ---------- Leads ----------
  listLeads(stage?: LeadStage): Observable<Lead[]> {
    let params = new HttpParams();
    if (stage) params = params.set('stage', stage);
    return this.http.get<Lead[]>(this.url('/api/leads'), { params });
  }

  leadCounts(): Observable<Record<string, number>> {
    return this.http.get<Record<string, number>>(this.url('/api/leads/counts'));
  }

  createLead(body: LeadCreate): Observable<Lead> {
    return this.http.post<Lead>(this.url('/api/leads'), body);
  }

  updateLead(id: string, patch: LeadUpdate): Observable<Lead> {
    return this.http.patch<Lead>(this.url(`/api/leads/${id}`), patch);
  }

  deleteLead(id: string): Observable<void> {
    return this.http.delete<void>(this.url(`/api/leads/${id}`));
  }
}

/**
 * Helper to coerce server timestamps (ISO strings) into Date objects on
 * ChatMessage/ChatSession before they hit the UI bindings that use the
 * `date` pipe.
 */
export function rehydrateMessage(m: ChatMessage): ChatMessage {
  return { ...m, timestamp: new Date(m.timestamp as unknown as string) };
}

export function rehydrateSession(s: ChatSession): ChatSession {
  return {
    ...s,
    createdAt: new Date(s.createdAt as unknown as string),
    updatedAt: new Date(s.updatedAt as unknown as string),
    messages: s.messages.map(rehydrateMessage),
  };
}

/** Type-narrowed helper for product-cards attachment (used by callers). */
export function isProductCards(att: any): att is { kind: 'product-cards'; products: InsuranceProduct[] } {
  return att?.kind === 'product-cards';
}
