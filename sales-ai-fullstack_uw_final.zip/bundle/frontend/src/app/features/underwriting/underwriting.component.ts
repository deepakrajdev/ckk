import {
  ChangeDetectionStrategy,
  Component,
  computed,
  inject,
  signal,
} from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { firstValueFrom } from 'rxjs';

import {
  ApiService,
  FinancialCheck,
  MedicalCheck,
  NonMedicalCheck,
  PlanName,
  UnderwritingOptions,
} from '../../core/services/api.service';

type SectionId =
  | 'financial' | 'medicalNonDisclosure' | 'medicalDisclosure' | 'nonMedical';

@Component({
  selector: 'app-underwriting',
  standalone: true,
  imports: [CommonModule, FormsModule],
  changeDetection: ChangeDetectionStrategy.OnPush,
  templateUrl: './underwriting.component.html',
})
export class UnderwritingComponent {
  private readonly api = inject(ApiService);

  // ===== Shared =====
  protected readonly options = signal<UnderwritingOptions | null>(null);
  protected readonly optionsError = signal<string | null>(null);

  protected readonly activeSection = signal<SectionId>('financial');

  protected readonly sectionMeta = [
    { id: 'financial',            label: 'Financial',                short: 'Financial' },
    { id: 'medicalNonDisclosure', label: 'Medical · Non-Disclosure', short: 'Non-Disc.' },
    { id: 'medicalDisclosure',    label: 'Medical · Disclosure',     short: 'Disclosure' },
    { id: 'nonMedical',           label: 'Non-Medical',              short: 'Non-Med.' },
  ] as const;

  // ===========================================================
  // ★ FINANCIAL workflow state
  // ===========================================================
  protected readonly finPlan = signal<PlanName | ''>('');
  protected readonly finOccupation = signal<string>('');
  protected readonly finSuc = signal<string>('');
  protected readonly finRows = signal<FinancialCheck[]>([]);
  protected readonly finLoading = signal(false);
  protected readonly finError = signal<string | null>(null);

  protected readonly finSucs = computed<string[]>(() =>
    this.uniqueBy(this.finRows(), (r) => r.financialSuc)
  );
  protected readonly finStep1Complete = computed(
    () => this.finPlan() !== '' && this.finOccupation() !== ''
  );
  protected readonly finStep2Complete = computed(() => this.finSuc() !== '');
  protected readonly finVisibleRows = computed<FinancialCheck[]>(() =>
    this.finStep2Complete()
      ? this.finRows().filter((r) => r.financialSuc === this.finSuc())
      : []
  );

  // ===========================================================
  // ★ MEDICAL NON-DISCLOSURE workflow state
  // ===========================================================
  protected readonly mndPlan = signal<PlanName | ''>('');
  protected readonly mndAgeLimit = signal<string>('');
  protected readonly mndSuc = signal<string>('');
  protected readonly mndRows = signal<MedicalCheck[]>([]);
  protected readonly mndLoading = signal(false);
  protected readonly mndError = signal<string | null>(null);

  protected readonly mndSucs = computed<string[]>(() =>
    this.uniqueBy(this.mndRows(), (r) => r.medicalSuc)
  );
  protected readonly mndStep1Complete = computed(
    () => this.mndPlan() !== '' && this.mndAgeLimit() !== ''
  );
  protected readonly mndStep2Complete = computed(() => this.mndSuc() !== '');
  protected readonly mndVisibleRows = computed<MedicalCheck[]>(() =>
    this.mndStep2Complete()
      ? this.mndRows().filter((r) => r.medicalSuc === this.mndSuc())
      : []
  );

  // ===========================================================
  // ★ MEDICAL DISCLOSURE workflow state
  // ===========================================================
  protected readonly mdPlan = signal<PlanName | ''>('');
  protected readonly mdAgeLimit = signal<string>('');
  protected readonly mdSuc = signal<string>('');
  protected readonly mdRows = signal<MedicalCheck[]>([]);
  protected readonly mdLoading = signal(false);
  protected readonly mdError = signal<string | null>(null);

  protected readonly mdSucs = computed<string[]>(() =>
    this.uniqueBy(this.mdRows(), (r) => r.medicalSuc)
  );
  protected readonly mdStep1Complete = computed(
    () => this.mdPlan() !== '' && this.mdAgeLimit() !== ''
  );
  protected readonly mdStep2Complete = computed(() => this.mdSuc() !== '');
  protected readonly mdVisibleRows = computed<MedicalCheck[]>(() =>
    this.mdStep2Complete()
      ? this.mdRows().filter((r) => r.medicalSuc === this.mdSuc())
      : []
  );

  // ===========================================================
  // ★ NON-MEDICAL workflow state — 2 steps only (no SUC dimension)
  // ===========================================================
  protected readonly nmPlan = signal<PlanName | ''>('');
  protected readonly nmAgeLimit = signal<string>('');
  protected readonly nmRows = signal<NonMedicalCheck[]>([]);
  protected readonly nmLoading = signal(false);
  protected readonly nmError = signal<string | null>(null);

  protected readonly nmStep1Complete = computed(
    () => this.nmPlan() !== '' && this.nmAgeLimit() !== ''
  );

  // ===========================================================
  // Init
  // ===========================================================
  constructor() {
    void this.loadOptions();
  }

  private async loadOptions(): Promise<void> {
    try {
      this.options.set(await firstValueFrom(this.api.underwritingOptions()));
    } catch (err) {
      this.optionsError.set(
        err instanceof Error ? err.message : 'Failed to load options'
      );
    }
  }

  private uniqueBy<T>(arr: T[], pick: (r: T) => string): string[] {
    const seen = new Set<string>();
    const out: string[] = [];
    for (const r of arr) {
      const v = pick(r);
      if (!seen.has(v)) { seen.add(v); out.push(v); }
    }
    return out;
  }

  // ===========================================================
  // FINANCIAL handlers
  // ===========================================================
  protected onFinPlan(v: string): void {
    this.finPlan.set(v as PlanName);
    this.finSuc.set(''); this.finRows.set([]); this.finError.set(null);
    void this.fetchFin();
  }
  protected onFinOccupation(v: string): void {
    this.finOccupation.set(v);
    this.finSuc.set(''); this.finRows.set([]); this.finError.set(null);
    void this.fetchFin();
  }
  protected onFinSuc(v: string): void { this.finSuc.set(v); }
  protected resetFin(): void {
    this.finPlan.set(''); this.finOccupation.set(''); this.finSuc.set('');
    this.finRows.set([]); this.finError.set(null);
  }
  private async fetchFin(): Promise<void> {
    if (!this.finStep1Complete()) return;
    this.finLoading.set(true); this.finError.set(null);
    try {
      this.finRows.set(await firstValueFrom(
        this.api.listFinancial({
          plan: this.finPlan() as PlanName, occupation: this.finOccupation(),
        })
      ));
    } catch (err) {
      this.finError.set(err instanceof Error ? err.message : 'Fetch failed');
    } finally { this.finLoading.set(false); }
  }

  // ===========================================================
  // MEDICAL NON-DISCLOSURE handlers
  // ===========================================================
  protected onMndPlan(v: string): void {
    this.mndPlan.set(v as PlanName);
    this.mndSuc.set(''); this.mndRows.set([]); this.mndError.set(null);
    void this.fetchMnd();
  }
  protected onMndAge(v: string): void {
    this.mndAgeLimit.set(v);
    this.mndSuc.set(''); this.mndRows.set([]); this.mndError.set(null);
    void this.fetchMnd();
  }
  protected onMndSuc(v: string): void { this.mndSuc.set(v); }
  protected resetMnd(): void {
    this.mndPlan.set(''); this.mndAgeLimit.set(''); this.mndSuc.set('');
    this.mndRows.set([]); this.mndError.set(null);
  }
  private async fetchMnd(): Promise<void> {
    if (!this.mndStep1Complete()) return;
    this.mndLoading.set(true); this.mndError.set(null);
    try {
      this.mndRows.set(await firstValueFrom(
        this.api.listMedicalNonDisclosure({
          plan: this.mndPlan() as PlanName, ageLimit: this.mndAgeLimit(),
        })
      ));
    } catch (err) {
      this.mndError.set(err instanceof Error ? err.message : 'Fetch failed');
    } finally { this.mndLoading.set(false); }
  }

  // ===========================================================
  // MEDICAL DISCLOSURE handlers
  // ===========================================================
  protected onMdPlan(v: string): void {
    this.mdPlan.set(v as PlanName);
    this.mdSuc.set(''); this.mdRows.set([]); this.mdError.set(null);
    void this.fetchMd();
  }
  protected onMdAge(v: string): void {
    this.mdAgeLimit.set(v);
    this.mdSuc.set(''); this.mdRows.set([]); this.mdError.set(null);
    void this.fetchMd();
  }
  protected onMdSuc(v: string): void { this.mdSuc.set(v); }
  protected resetMd(): void {
    this.mdPlan.set(''); this.mdAgeLimit.set(''); this.mdSuc.set('');
    this.mdRows.set([]); this.mdError.set(null);
  }
  private async fetchMd(): Promise<void> {
    if (!this.mdStep1Complete()) return;
    this.mdLoading.set(true); this.mdError.set(null);
    try {
      this.mdRows.set(await firstValueFrom(
        this.api.listMedicalDisclosure({
          plan: this.mdPlan() as PlanName, ageLimit: this.mdAgeLimit(),
        })
      ));
    } catch (err) {
      this.mdError.set(err instanceof Error ? err.message : 'Fetch failed');
    } finally { this.mdLoading.set(false); }
  }

  // ===========================================================
  // NON-MEDICAL handlers
  // ===========================================================
  protected onNmPlan(v: string): void {
    this.nmPlan.set(v as PlanName);
    this.nmRows.set([]); this.nmError.set(null);
    void this.fetchNm();
  }
  protected onNmAge(v: string): void {
    this.nmAgeLimit.set(v);
    this.nmRows.set([]); this.nmError.set(null);
    void this.fetchNm();
  }
  protected resetNm(): void {
    this.nmPlan.set(''); this.nmAgeLimit.set('');
    this.nmRows.set([]); this.nmError.set(null);
  }
  private async fetchNm(): Promise<void> {
    if (!this.nmStep1Complete()) return;
    this.nmLoading.set(true); this.nmError.set(null);
    try {
      this.nmRows.set(await firstValueFrom(
        this.api.listNonMedical({
          plan: this.nmPlan() as PlanName, ageLimit: this.nmAgeLimit(),
        })
      ));
    } catch (err) {
      this.nmError.set(err instanceof Error ? err.message : 'Fetch failed');
    } finally { this.nmLoading.set(false); }
  }
}
