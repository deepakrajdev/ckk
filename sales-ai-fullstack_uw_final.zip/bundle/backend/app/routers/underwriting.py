"""Underwriting Checks endpoints — all tabs form-driven."""

from fastapi import APIRouter, Depends, Query

from app.models import (
    FinancialCheck,
    MedicalCheck,
    NonMedicalCheck,
    PlanName,
    UnderwritingChecksBundle,
    UnderwritingOptions,
)
from app.services.store import Store, get_store

router = APIRouter(prefix="/api/underwriting", tags=["underwriting"])


@router.get("/checks", response_model=UnderwritingChecksBundle)
async def get_checks(
    store: Store = Depends(get_store),
) -> UnderwritingChecksBundle:
    """Combined backward-compat payload — all four tables in one request."""
    return await store.underwriting_checks()


# ============================================================
# ★ Options endpoint — single source for every dropdown
# ============================================================

@router.get("/options", response_model=UnderwritingOptions)
async def options(store: Store = Depends(get_store)) -> UnderwritingOptions:
    """
    Plans + occupations + age-limits across all four UW datasets.
    Used by every tab's first-step form.
    """
    return await store.underwriting_options()


# Backward-compat alias — existing frontend code still calls financial-options
@router.get("/financial-options", response_model=UnderwritingOptions)
async def financial_options(store: Store = Depends(get_store)) -> UnderwritingOptions:
    return await store.underwriting_options()


# ============================================================
# ★ FINANCIAL workflow — Plan + Occupation → SUC dropdown → table
# ============================================================

@router.get("/financial", response_model=list[FinancialCheck])
async def list_financial(
    plan: PlanName | None = Query(None),
    occupation: str | None = Query(None),
    suc: str | None = Query(None),
    store: Store = Depends(get_store),
) -> list[FinancialCheck]:
    """Filter Financial-UW rows by any combination of plan / occupation / SUC."""
    return await store.list_financial(plan=plan, occupation=occupation, suc=suc)


# ============================================================
# ★ MEDICAL NON-DISCLOSURE workflow — Plan + Age → SUC → table
# ============================================================

@router.get("/medical-non-disclosure", response_model=list[MedicalCheck])
async def list_medical_non_disclosure(
    plan: PlanName | None = Query(None),
    age_limit: str | None = Query(None, alias="ageLimit"),
    suc: str | None = Query(None),
    store: Store = Depends(get_store),
) -> list[MedicalCheck]:
    """Filter Medical Non-Disclosure rows by plan / age limit / SUC."""
    return await store.list_medical(
        kind="non-disclosure", plan=plan, age_limit=age_limit, suc=suc,
    )


# ============================================================
# ★ MEDICAL DISCLOSURE workflow — same shape, different data
# ============================================================

@router.get("/medical-disclosure", response_model=list[MedicalCheck])
async def list_medical_disclosure(
    plan: PlanName | None = Query(None),
    age_limit: str | None = Query(None, alias="ageLimit"),
    suc: str | None = Query(None),
    store: Store = Depends(get_store),
) -> list[MedicalCheck]:
    """Filter Medical Disclosure rows by plan / age limit / SUC."""
    return await store.list_medical(
        kind="disclosure", plan=plan, age_limit=age_limit, suc=suc,
    )


# ============================================================
# ★ NON-MEDICAL workflow — Plan + Age → VMER card (no SUC step)
# ============================================================

@router.get("/non-medical", response_model=list[NonMedicalCheck])
async def list_non_medical(
    plan: PlanName | None = Query(None),
    age_limit: str | None = Query(None, alias="ageLimit"),
    store: Store = Depends(get_store),
) -> list[NonMedicalCheck]:
    """Filter Non-Medical (VMER) rows by plan / age limit."""
    return await store.list_non_medical(plan=plan, age_limit=age_limit)
