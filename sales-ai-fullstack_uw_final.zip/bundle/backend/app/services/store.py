"""In-memory data store. Replace this class to switch to a real DB."""

import asyncio
import uuid
from datetime import datetime, timezone

from app.config import get_settings
from app.models import (
    ChatMessage,
    ChatSession,
    EarningsSummary,
    Incentive,
    IncentiveTag,
    InventoryRow,
    InventoryStat,
    Lead,
    LeadCreate,
    LeadStage,
    LeadUpdate,
    LibraryCategory,
    LibraryDocument,
    MessageAuthor,
    SessionSummary,
    UnderwritingChecksBundle,
    UnderwritingStage,
    UserProfile,
)
from app.services import seed


class Store:
    """Single in-memory store."""

    def __init__(self) -> None:
        self._settings = get_settings()
        self._lock = asyncio.Lock()

        self._sessions: dict[str, ChatSession] = {s.id: s for s in seed.sessions()}
        self._inventory: list[InventoryRow] = seed.inventory()
        self._inventory_stats: list[InventoryStat] = seed.inventory_stats()
        self._earnings: EarningsSummary = seed.earnings()
        self._incentives: list[Incentive] = seed.incentives()
        self._leads: dict[str, Lead] = {l.id: l for l in seed.leads()}
        self._library: dict[str, LibraryDocument] = {d.id: d for d in seed.library()}
        self._underwriting_checks: UnderwritingChecksBundle = seed.underwriting_checks()
        self._me: UserProfile = seed.me()

    # ---------------- Sessions / chat ----------------

    async def list_sessions(self) -> list[SessionSummary]:
        async with self._lock:
            ordered = sorted(
                self._sessions.values(),
                key=lambda s: s.updated_at,
                reverse=True,
            )[: self._settings.max_sessions]
            return [self._to_summary(s) for s in ordered]

    async def get_session(self, session_id: str) -> ChatSession | None:
        async with self._lock:
            return self._sessions.get(session_id)

    async def create_session(self, title: str | None = None) -> ChatSession:
        async with self._lock:
            now = datetime.now(timezone.utc)
            session = ChatSession(
                id=str(uuid.uuid4()),
                title=title or "New conversation",
                created_at=now, updated_at=now,
                messages=[
                    ChatMessage(
                        id=str(uuid.uuid4()),
                        author=MessageAuthor.bot,
                        timestamp=now,
                        content=("👋 New session started. Share the prospect's profile "
                                 "and I'll match products and pull underwriting requirements."),
                    )
                ],
            )
            self._sessions[session.id] = session
            self._enforce_cap()
            return session

    async def append_message(
        self, session_id: str, message: ChatMessage
    ) -> ChatSession | None:
        async with self._lock:
            session = self._sessions.get(session_id)
            if session is None:
                return None
            session.messages.append(message)
            session.updated_at = datetime.now(timezone.utc)
            if (
                session.title == "New conversation"
                and message.author == MessageAuthor.user
            ):
                session.title = self._title_from(message.content)
            return session

    async def delete_session(self, session_id: str) -> bool:
        async with self._lock:
            return self._sessions.pop(session_id, None) is not None

    # ---------------- Inventory (FLS pipeline) ----------------

    async def list_inventory(
        self,
        stage: UnderwritingStage | None = None,
        q: str | None = None,
    ) -> list[InventoryRow]:
        async with self._lock:
            rows = list(self._inventory)
        if stage is not None:
            rows = [r for r in rows if r.underwriting_stage == stage]
        if q:
            needle = q.lower()
            rows = [r for r in rows if needle in r.fls_id.lower()]
        return rows

    async def inventory_stats(self) -> list[InventoryStat]:
        async with self._lock:
            return list(self._inventory_stats)

    # ---------------- Incentives ----------------

    async def earnings_summary(self) -> EarningsSummary:
        async with self._lock:
            return self._earnings

    async def list_incentives(
        self, tag: IncentiveTag | None = None
    ) -> list[Incentive]:
        async with self._lock:
            rows = list(self._incentives)
        if tag is not None:
            rows = [i for i in rows if i.tag == tag]
        return rows

    # ---------------- Leads ----------------

    async def list_leads(self, stage: LeadStage | None = None) -> list[Lead]:
        async with self._lock:
            rows = list(self._leads.values())
        if stage is not None:
            rows = [l for l in rows if l.stage == stage]
        return rows

    async def lead_counts(self) -> dict[str, int]:
        async with self._lock:
            counts: dict[str, int] = {"All": len(self._leads)}
            for stage in LeadStage:
                counts[stage.value] = sum(
                    1 for l in self._leads.values() if l.stage == stage
                )
            return counts

    async def create_lead(self, data: LeadCreate) -> Lead:
        async with self._lock:
            lead = Lead(
                id=str(uuid.uuid4()),
                initials=self._initials_from(data.name),
                name=data.name, city=data.city,
                interest=data.interest, potential=data.potential,
                stage=data.stage, next_action=data.next_action, hot=data.hot,
            )
            self._leads[lead.id] = lead
            return lead

    async def update_lead(self, lead_id: str, patch: LeadUpdate) -> Lead | None:
        async with self._lock:
            lead = self._leads.get(lead_id)
            if lead is None:
                return None
            data = patch.model_dump(exclude_unset=True)
            updated = lead.model_copy(update=data)
            self._leads[lead_id] = updated
            return updated

    async def delete_lead(self, lead_id: str) -> bool:
        async with self._lock:
            return self._leads.pop(lead_id, None) is not None

    # ---------------- Library ----------------

    async def list_library(
        self,
        category: LibraryCategory | None = None,
        q: str | None = None,
    ) -> list[LibraryDocument]:
        async with self._lock:
            rows = list(self._library.values())
        if category is not None:
            rows = [d for d in rows if d.category == category]
        if q:
            needle = q.lower()
            rows = [
                d for d in rows
                if needle in d.title.lower() or needle in d.description.lower()
            ]
        # Newest first
        return sorted(rows, key=lambda d: d.updated_at, reverse=True)

    async def get_library(self, document_id: str) -> LibraryDocument | None:
        async with self._lock:
            return self._library.get(document_id)

    # ---------------- Underwriting Checks ----------------

    async def underwriting_checks(self) -> UnderwritingChecksBundle:
        async with self._lock:
            return self._underwriting_checks

    async def list_financial(
        self,
        plan: "PlanName | None" = None,
        occupation: str | None = None,
        suc: str | None = None,
    ) -> list:
        """Filter Financial-UW rows by plan / occupation / SUC."""
        async with self._lock:
            rows = list(self._underwriting_checks.financial)
        if plan is not None:
            rows = [r for r in rows if r.plan_name == plan]
        if occupation:
            rows = [r for r in rows if r.occupation_life_type == occupation]
        if suc:
            rows = [r for r in rows if r.financial_suc == suc]
        return rows

    # ★ NEW — Medical (works for both disclosure / non-disclosure)
    async def list_medical(
        self,
        kind: str,                                # "non-disclosure" or "disclosure"
        plan: "PlanName | None" = None,
        age_limit: str | None = None,
        suc: str | None = None,
    ) -> list:
        async with self._lock:
            source = (
                self._underwriting_checks.medical_non_disclosure
                if kind == "non-disclosure"
                else self._underwriting_checks.medical_disclosure
            )
            rows = list(source)
        if plan is not None:
            rows = [r for r in rows if r.plan_name == plan]
        if age_limit:
            rows = [r for r in rows if r.age_limit == age_limit]
        if suc:
            rows = [r for r in rows if r.medical_suc == suc]
        return rows

    # ★ NEW — Non-Medical (VMER)
    async def list_non_medical(
        self,
        plan: "PlanName | None" = None,
        age_limit: str | None = None,
    ) -> list:
        async with self._lock:
            rows = list(self._underwriting_checks.non_medical)
        if plan is not None:
            rows = [r for r in rows if r.plan_name == plan]
        if age_limit:
            rows = [r for r in rows if r.age_limit == age_limit]
        return rows

    # ★ Renamed/expanded — now serves every tab's dropdowns
    async def underwriting_options(self) -> "UnderwritingOptions":
        """
        Unique plans + occupations + age limits across the whole UW dataset.
        Used by every tab's first-step form to populate dropdowns.
        """
        from app.models import PlanName, UnderwritingOptions

        async with self._lock:
            financial = list(self._underwriting_checks.financial)
            medical_nd = list(self._underwriting_checks.medical_non_disclosure)
            medical_d = list(self._underwriting_checks.medical_disclosure)
            non_medical = list(self._underwriting_checks.non_medical)

        # Plans — union across all four datasets, sorted by enum order
        seen_plans: dict[str, None] = {}
        for r in financial + medical_nd + medical_d + non_medical:
            seen_plans.setdefault(r.plan_name.value, None)
        plan_order = {p.value: i for i, p in enumerate(PlanName)}
        plans = sorted(seen_plans.keys(), key=lambda v: plan_order.get(v, 99))

        # Occupations — only from Financial
        seen_occ: dict[str, None] = {}
        for r in financial:
            seen_occ.setdefault(r.occupation_life_type, None)
        occupations = list(seen_occ.keys())

        # Age limits — union from Medical + Non-Medical, sorted by first digit
        seen_age: dict[str, None] = {}
        for r in medical_nd + medical_d + non_medical:
            seen_age.setdefault(r.age_limit, None)
        # Stable numeric sort: extract leading digits ("18-35" → 18)
        def _age_key(s: str) -> int:
            digits = ""
            for ch in s:
                if ch.isdigit(): digits += ch
                else: break
            return int(digits) if digits else 999
        age_limits = sorted(seen_age.keys(), key=_age_key)

        return UnderwritingOptions(
            plans=plans, occupations=occupations, age_limits=age_limits
        )

    # Backward-compat alias for the old endpoint
    async def financial_options(self) -> "UnderwritingOptions":
        return await self.underwriting_options()

    # ---------------- Me ----------------

    async def me(self) -> UserProfile:
        return self._me

    # ---------------- Helpers ----------------

    def _enforce_cap(self) -> None:
        cap = self._settings.max_sessions
        if len(self._sessions) <= cap:
            return
        ordered = sorted(
            self._sessions.values(), key=lambda s: s.updated_at, reverse=True
        )
        keep_ids = {s.id for s in ordered[:cap]}
        for sid in list(self._sessions.keys()):
            if sid not in keep_ids:
                self._sessions.pop(sid, None)

    @staticmethod
    def _to_summary(session: ChatSession) -> SessionSummary:
        last = next(
            (m for m in reversed(session.messages) if (m.content or "").strip()),
            None,
        )
        preview = "No messages yet"
        if last is not None:
            preview = " ".join(last.content.split())
            preview = preview if len(preview) <= 70 else preview[:67] + "…"
        return SessionSummary(
            id=session.id, title=session.title,
            created_at=session.created_at, updated_at=session.updated_at,
            message_count=len(session.messages), last_message_preview=preview,
        )

    @staticmethod
    def _title_from(content: str) -> str:
        clean = " ".join(content.split())
        return clean if len(clean) <= 48 else clean[:45].rstrip() + "…"

    @staticmethod
    def _initials_from(name: str) -> str:
        parts = [p for p in name.split() if p]
        if not parts: return "?"
        if len(parts) == 1: return parts[0][:2].upper()
        return (parts[0][0] + parts[-1][0]).upper()


_store: Store | None = None


def get_store() -> Store:
    global _store
    if _store is None:
        _store = Store()
    return _store
