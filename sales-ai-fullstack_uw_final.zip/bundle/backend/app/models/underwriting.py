"""Underwriting Checks — four reference tables surfaced by the UI."""

from enum import Enum
from .chat import Base


class PlanName(str, Enum):
    """Top-level life-insurance product categories used to filter UW rules."""
    term = "Term"
    ulip = "ULIP"
    endowment = "Endowment"
    pension = "Pension"
    whole_life = "Whole Life"
    money_back = "Money Back"
    child_plan = "Child Plan"


class FinancialCheck(Base):
    """One row of the Financial table."""
    id: str
    plan_name: PlanName       # drives the Underwriting form workflow
    financial_suc: str        # e.g. "Up to ₹50 L"
    occupation_life_type: str # e.g. "Salaried · Class I"
    financial_requirement: str
    documents_list: list[str]


class MedicalCheck(Base):
    """Shared shape for both Medical tables (disclosure / non-disclosure)."""
    id: str
    plan_name: PlanName               # ★ NEW — for the form workflow
    age_limit: str                    # e.g. "18-35"
    medical_suc: str                  # e.g. "Up to ₹50 L"
    medical_requirements: list[str]   # e.g. ["MER", "ECG", "FBS"]


class NonMedicalCheck(Base):
    id: str
    plan_name: PlanName               # ★ NEW — for the form workflow
    age_limit: str
    vmer_requirements: list[str]


class UnderwritingChecksBundle(Base):
    """Single payload — backward-compatible combined fetch."""
    financial: list[FinancialCheck]
    medical_non_disclosure: list[MedicalCheck]
    medical_disclosure: list[MedicalCheck]
    non_medical: list[NonMedicalCheck]


class UnderwritingOptions(Base):
    """
    Dropdown payload for ALL Underwriting form workflows.
    ★ Replaces FinancialOptions — single source for every tab's filters.
    """
    plans: list[str]
    occupations: list[str]            # used by Financial
    age_limits: list[str]             # used by Medical & Non-Medical


# Backward-compat alias so existing imports of FinancialOptions keep working.
FinancialOptions = UnderwritingOptions
